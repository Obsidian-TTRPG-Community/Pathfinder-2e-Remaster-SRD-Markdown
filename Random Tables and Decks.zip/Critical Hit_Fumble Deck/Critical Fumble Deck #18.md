---
title: "Critical Fumble Deck #18"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #18"
foundryId: JournalEntry.htZOATmfLiU6lJqe.JournalEntryPage.rZHd27zct5D3dN6w
tags:
  - JournalEntryPage
---
# Overextended

> You trigger reactions as if you had used a move action.

`Melee`

# Aching Back

> You are [[Fatigued]].

`Ranged`

# Upset Stomach

> You are [[Sickened 1|Sickened 2]].

`Unarmed`

# Critical Backlash

> You critically hit yourself instead of the target.

`Spell`