---
title: "Critical Fumble Deck #41"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #41"
foundryId: JournalEntry.12GDPGS0PoZwhpx0.JournalEntryPage.C0t1CYEnkINf6jhr
tags:
  - JournalEntryPage
---
# All or Nothing

> You take a [[Effect\_ -1 circumstance penalty to attack rolls until you score a critical hit|-1 circumstance penalty to attack rolls until you score a critical hit]].

`Melee`

# Close to the Ear

> You are [[Effect\_ Deafened until end of your next turn|Effect: Deafened until end of your next turn]].

`Ranged`

# Pins and Needles

> You are [[Sickened 1|Sickened 3]].

`Unarmed`

# Why Me?

> You provoke reactions as if you used a move action.

`Spell`