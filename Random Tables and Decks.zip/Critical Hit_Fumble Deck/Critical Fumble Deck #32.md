---
title: "Critical Fumble Deck #32"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #32"
foundryId: JournalEntry.Mq9RNG0cC23uMshO.JournalEntryPage.z1dQl3xXyLg6xakc
tags:
  - JournalEntryPage
---
# Bent

> Your weapon's current Hit Point are reduced to its Broken Threshold. if already broken, the weapon takes [[/r 3d6]] damage, ignoring Hardness.

`Melee`

# Double Miss

> If this attack uses ammunition, you use twice the amount of ammunition on this attack.

`Ranged`

# Caught your Attack

> This attack grants and triggers a [[Trip]] or [[Shove]] as a reaction by your enemy.

`Unarmed`

# Left Reeling

> You are [[Stunned 1]].

`Spell`