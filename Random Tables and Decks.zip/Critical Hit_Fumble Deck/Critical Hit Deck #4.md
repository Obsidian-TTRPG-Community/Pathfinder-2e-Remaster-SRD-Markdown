---
title: "Critical Hit Deck #4"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #4"
foundryId: JournalEntry.5XgWMAAhVEEYYvoG.JournalEntryPage.RksHFLAckI3WzZjx
tags:
  - JournalEntryPage
---
# Cracked Rib

> The target is [[Fatigued]].

`Bludgeoning`

# Momentum

> You gain a [[Effect\_ +2 circumstance bonus to attack rolls|+2 circumstance bonus to attack rolls]] until the end of your next turn.

`Piercing`

# Gory

> The target is [[Sickened 1]].

`Slashing`

# Stunned

> Normal damage. The target is [[Stunned 1|Stunned 2]].

`Bomb or Spell`