---
title: "Critical Fumble Deck #21"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #21"
foundryId: JournalEntry.k0m2QRXXPQFs40dW.JournalEntryPage.RMK1WoNdESOAfpUW
tags:
  - JournalEntryPage
---
# Backswing

> You deal the attack's normal damage to yourself instead of the target.

`Melee`

# Wide Open

> You are [[Effect\_ Off-Guard until end of your next turn|Effect: Off-Guard until end of your next turn]] .

`Ranged`

# Tripped

> You fall [[Prone]].

`Unarmed`

# Tangled in your Gear

> You are [[Encumbered]] until you spend 2 [[Interact]] actions to free your self.

`Spell`