---
title: "Critical Hit Deck #1"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #1"
foundryId: JournalEntry.JUZfGj1vPy6gPwp3.JournalEntryPage.r9iBZ8NsIFSvgStR
tags:
  - JournalEntryPage
---
# Crunch

> **Crit Effect:** The target is [[Sickened 1|Sickened 3]].

`Bludgeoning`

# Forearm Piercing

> **Crit Effect:** The target drops one weapon it's holding (chosen randomly by the GM).

`Piercing`

# Surprise Opening

> **Crit Effect:** You gain 1 action that you can use before the end of your turn to use an attack action against the target.

`Slashing`

# Allergic reaction

> The target takes [[/r 1d8\[poison]]\] damage.

`Bomb or Spell`