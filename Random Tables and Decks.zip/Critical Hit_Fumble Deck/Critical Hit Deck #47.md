---
title: "Critical Hit Deck #47"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #47"
foundryId: JournalEntry.bhk9Goy5Se8YHU6X.JournalEntryPage.RYUmc3RaviKhGkaI
tags:
  - JournalEntryPage
---
# Back Breaker

> **Crit Effect:** Until healed, the target is [[Clumsy 1|Clumsy 2]] and [[Enfeebled 1|Enfeebled 2]].

`Bludgeoning`

# Deep Wound

> **Crit Effect:** The target is [[Sickened 1|Sickened 3]].

`Piercing`

# Brow Cut

> Normal damage. **Crit Effect:** The target takes [[/r 1d4\[bleed]]\]. Until the bleed ends, all creatures are [[Concealed]] to the target.

`Slashing`

# Mystical Thwart

> The target can't activate magic items, cast spells, or use Quick Alchemy until the end of its next turn.

`Bomb or Spell`