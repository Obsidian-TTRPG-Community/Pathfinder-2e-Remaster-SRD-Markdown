---
title: "Critical Fumble Deck #15"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #15"
foundryId: JournalEntry.udGbLblz176ryKmA.JournalEntryPage.1twrhbUvK9iTGLkw
tags:
  - JournalEntryPage
---
# Broken Weapon

> Your weapon's current Hit Point are reduced to its Broken Threshold. If already [[Broken]], the weapon takes [[/r 3d6]] damage, ignoring Hardness.

`Melee`

# My Spleeny Bits!

> You become [[Wounded 1]] or your wounded value increases by 1.

`Ranged`

# Frustration

> You take a [[Effect\_ -2 circumstance penalty to attack rolls|-2 circumstance penalty to attack rolls]] until the end of your next turn.

`Unarmed`

# Beastly Rift

> Your spell becomes a _[[Summon Animal]]_ spell of the same level. The animal attacks you.

`Spell`