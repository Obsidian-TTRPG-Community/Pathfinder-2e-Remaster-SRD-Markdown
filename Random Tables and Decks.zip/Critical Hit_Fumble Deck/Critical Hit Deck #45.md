---
title: "Critical Hit Deck #45"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #45"
foundryId: JournalEntry.qIHB04NmzU8IDPVi.JournalEntryPage.EkWqEdr5GVmYQOKx
tags:
  - JournalEntryPage
---
# Low Blow

> **Crit Effect:** The target is [[Sickened 1|Sickened 2]] and [[Slowed 1]] as long as it remains sickened.

`Bludgeoning`

# Hobbled

> **Crit Effect:** Until healed, the target is [[Clumsy 1|Clumsy 2]] and takes a [[Effect\_ -10-foot circumstance penalty to all Speeds|-10-foot circumstance penalty to all Speeds]].

`Piercing`

# Bad Parry

> **Crit Effect:** The target must succeed at a @Check\[type:reflex\] or drop one weapon it is holding (determined randomly by the GM).

`Slashing`

# Planar Rift

> If this is a spell, the target takes normal damage and must succeed at a @Check\[type:will\] or be sent to a random plane (determined by the GM).

`Bomb or Spell`