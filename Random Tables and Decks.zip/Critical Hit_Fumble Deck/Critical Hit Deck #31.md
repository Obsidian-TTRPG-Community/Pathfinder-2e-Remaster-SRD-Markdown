---
title: "Critical Hit Deck #31"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #31"
foundryId: JournalEntry.tuFVZwPfY5cXizqB.JournalEntryPage.DlZqvNFlAdXu740m
tags:
  - JournalEntryPage
---
# Dazing Thud

> The target is [[Stunned 1]].

`Bludgeoning`

# Cheek Pierced

> The target must succeed at a @Check\[type:flat|dc:5\] to cast spells with a verbal component until healed.

`Piercing`

# Across the Eyes

> Normal damage. **Crit Effect:** The target is [[Blinded]] until healed.

`Slashing`

# Slowed Down

> The target is [[Slowed 1|Slowed 2]] for 1 round.

`Bomb or Spell`