---
title: "Critical Fumble Deck #4"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #4"
foundryId: JournalEntry.V1yjLZuY0yWvIHBO.JournalEntryPage.dXEWEkV4N8QgAodD
tags:
  - JournalEntryPage
---
# Wait, What?

> You are [[Confused]]

`Melee`

# Don't hit Me!

> Until the end of your next turn, each time you miss with a ranged attack targeting enemy adjacent to any of your allies, you hit one of those adjacent allies instead (determined randomly by the GM).

`Ranged`

# Pinched Nerve

> Until healed, you take a [[Effect\_ -10-foot circumstance penalty to your land Speed|-10-foot circumstance penalty to your land Speed]] and are [[Clumsy 1]].

`Unarmed`

# Mental Slip

> You are [[Controlled]] by the target until the end of your next turn.

`Spell`