---
title: "Critical Fumble Deck #19"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #19"
foundryId: JournalEntry.5XX6AILNGOVq3FgY.JournalEntryPage.qJgQ0vw4mcqDyYVT
tags:
  - JournalEntryPage
---
# Awkward Attack

> You are [[Effect\_ Off-Guard until end of your next turn|Effect: Off-Guard until end of your next turn]] .

`Melee`

# Shot your eye Out

> You critically hit yourself instead of the target.

`Ranged`

# Tiring Attack

> You are [[Fatigued]].

`Unarmed`

# Acidic Backlash

> You take [[/r 2d6\[acid]]\] damage.

`Spell`