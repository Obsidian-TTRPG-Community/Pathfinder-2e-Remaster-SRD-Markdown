---
title: "Critical Fumble Deck #29"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #29"
foundryId: JournalEntry.IZtQ7SGZUOZpKWvF.JournalEntryPage.wVneA33rSDvAtNPZ
tags:
  - JournalEntryPage
---
# Catch your Breath

> You are [[Slowed 1|Slowed 2]] until the end of your next turn.

`Melee`

# Wrong Weapon

> If you made a thrown attack, you instead throw an object from your gear (determined randomly by the GM).

`Ranged`

# Got too Close

> This attack grants and triggers a [[Grapple]] or [[Grab]] as a reaction by your enemy.

`Unarmed`

# You made 'em Stronger

> The target gains a [[Effect\_ +2 status bonus to attack rolls|+2 status bonus to attack rolls]] until the end of its next turn.

`Spell`