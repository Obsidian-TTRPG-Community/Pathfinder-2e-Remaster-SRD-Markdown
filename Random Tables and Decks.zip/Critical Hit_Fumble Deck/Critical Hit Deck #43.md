---
title: "Critical Hit Deck #43"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #43"
foundryId: JournalEntry.Gvu96joUJ0eqK9Fw.JournalEntryPage.MuU2oRlPMEGf5SKT
tags:
  - JournalEntryPage
---
# My Teef!

> The target must succeed at a @Check\[type:flat|dc:5\] to cast spells with the verbal component until healed.

`Bludgeoning`

# Gusher

> The target takes [[/r 1d6\[bleed]]\].

`Piercing`

# Terrible Cut

> Triple damage.

`Slashing`

# Excruciating

> The target is [[Sickened 1|Sickened 3]].

`Bomb or Spell`