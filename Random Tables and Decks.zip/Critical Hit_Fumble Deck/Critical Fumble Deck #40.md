---
title: "Critical Fumble Deck #40"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #40"
foundryId: JournalEntry.ow6xEZUUegJZVljj.JournalEntryPage.5UIGH23EhwTfoNSM
tags:
  - JournalEntryPage
---
# Creeping Hesitation

> You are [[Effect\_ Off-Guard until end of your next turn|Effect: Off-Guard until end of your next turn]] .

`Melee`

# Insecure

> You take a [[Effect\_ -1 circumstance penalty to attack rolls until you score a critical hit|-1 circumstance penalty to attack rolls until you score a critical hit]].

`Ranged`

# Great Roar

> Until healed, you are [[Deafened]].

`Unarmed`

# Error!

> You deal the spell's normal damage to yourself instead of the target.

`Spell`