---
title: "Critical Hit Deck #22"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #22"
foundryId: JournalEntry.sHNOmE80yWU87LPS.JournalEntryPage.jy3B3GW2BfOzG0AZ
tags:
  - JournalEntryPage
---
# Bone Masher

> Normal damage. **Crit Effect:** Either the target is [[Clumsy 1|Clumsy 2]] and takes a [[Effect\_ -10-foot status penalty to your land Speed|-10-foot status penalty to your land Speed]] or is [[Clumsy 1|Clumsy 2]] and can't use one of its arms (your choice). Either effect last until healed.

`Bludgeoning`

# Punctured Lung

> **Crit Effect:** The target is Suffocating until subject to magical healing.

`Piercing`

# Pain and Simple

> Triple damage.

`Slashing`

# Hypnotic Link

> If this is a spell, the target takes normal damage and is [[Controlled]] by you until the end of its next turn.

`Bomb or Spell`