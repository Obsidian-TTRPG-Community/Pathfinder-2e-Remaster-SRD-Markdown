---
title: "Critical Hit Deck #53"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #53"
foundryId: JournalEntry.0dXU72ecfolwfl9Y.JournalEntryPage.4YX173FiGFHEW0YY
tags:
  - JournalEntryPage
---
# Roundhouse

> **Crit Effect:** Make one additional attack against a foe adjacent to the original target, using the same attack modifier as the original attack.

`Bludgeoning`

# Ragged Wound

> The target takes [[/r 1d6\[bleed]]\].

`Piercing`

# Delayed Wound

> Normal damage. **Crit Effect:** The target takes the same amount of damage at the end of its next two turns.

`Slashing`

# Concussive Blast

> The target is pushed up to 10 feet and knocked [[Prone]].

`Bomb or Spell`