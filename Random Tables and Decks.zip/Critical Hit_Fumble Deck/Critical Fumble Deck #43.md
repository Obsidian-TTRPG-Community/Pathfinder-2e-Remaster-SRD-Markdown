---
title: "Critical Fumble Deck #43"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #43"
foundryId: JournalEntry.jcCGIGeI8em4XRAZ.JournalEntryPage.CvQ1EVSIxYPukyF5
tags:
  - JournalEntryPage
---
# Shield Crash

> You deal the attack's normal damage to your shield, applying Hardness.

`Melee`

# Everything you Got

> You are [[Fatigued]].

`Ranged`

# Hard-edged Adversary

> You take [[/r 2d6\[piercing]]\] damage or [[/r 2d6\[slashing]]\] damage (determined by the GM).

`Unarmed`

# You made 'em Tougher

> The target gains [[Effect\_ Resistance 5 to all damage|Resistance 5 to all damage]] until the start of its next turn.

`Spell`