---
title: "Critical Fumble Deck #3"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #3"
foundryId: JournalEntry.4DxWGexpx8844jQj.JournalEntryPage.jCcFyy09k0lf4wEl
tags:
  - JournalEntryPage
---
# Bad Fall

> You fall [[Prone]] and are [[Slowed 1]] until the end of your next turn.

`Melee`

# Spraining Shot

> Until healed, you take a [[Effect\_ -10-foot circumstance penalty to your land Speed|-10-foot circumstance penalty to your land Speed]] and are [[Clumsy 1]].

`Ranged`

# Bad Jam

> You are [[Clumsy 1]] and [[Enfeebled 1|Enfeebled 2]].

`Unarmed`

# Exploding Skull

> You must attempt a @Check\[type:fortitude\] save. If you succeed, you take
> 
> [[/r 3d6\[mental]]\] damage. **If you fail, your head explodes and you die.**

`Spell`