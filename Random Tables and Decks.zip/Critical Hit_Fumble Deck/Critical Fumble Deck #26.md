---
title: "Critical Fumble Deck #26"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #26"
foundryId: JournalEntry.IO2EvAfDgeaVx7mQ.JournalEntryPage.KAnlflMVazFiPclF
tags:
  - JournalEntryPage
---
# I told you it's Sharp!

> You take [[/r 1d6\[bleed]]\].

`Melee`

# Klutz

> You drop the weapon you used.

`Ranged`

# Stop hitting Yourself

> You hit yourself instead of the target.

`Unarmed`

# Not me, you Fool!

> You hit the ally nearest to the target.

`Spell`