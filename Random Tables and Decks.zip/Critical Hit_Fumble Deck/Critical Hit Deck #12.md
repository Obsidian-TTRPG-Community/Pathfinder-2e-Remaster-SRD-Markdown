---
title: "Critical Hit Deck #12"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #12"
foundryId: JournalEntry.pCQZC6ndhQztVqOA.JournalEntryPage.Yw5SzkTazJSsn3db
tags:
  - JournalEntryPage
---
# Crushed Toe

> Normal damage. The target is [[Clumsy 1|Clumsy 2]] and takes a [[Effect\_ -10-foot status penalty to your land Speed|-10-foot status penalty to your land Speed]]. Both effects last until healed.

`Bludgeoning`

# Stinger

> Normal damage. The target is [[Sickened 1|Sickened 3]].

`Piercing`

# Missing Digits

> Normal damage. **Crit Effect:** The target loses [[/r 1d4#Lost Fingers]] fingers on one hand and becomes [[Clumsy 1]] until subject to a _[[Regenerate]]_ spell or similar effect.

`Slashing`

# Strange Goo

> Normal damage and the target is [[Restrained]], using your class DC as the DC to Escape.

`Bomb or Spell`