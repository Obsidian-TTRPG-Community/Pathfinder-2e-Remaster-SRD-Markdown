---
title: "Critical Fumble Deck #52"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #52"
foundryId: JournalEntry.dvKBzvEGJLUzY9Lz.JournalEntryPage.R9KUWluXi5sFMfii
tags:
  - JournalEntryPage
---
# Go for the Eyes

> You are [[Effect\_ Dazzled until end of your next turn|Effect: Dazzled until end of your next turn]].

`Melee`

# Pinch a Finger

> You take [[/r 1d6\[bleed]]\].

`Ranged`

# Winds of Change

> You can't attack the same target again until the end of your next turn.

`Unarmed`

# Now I see You...

> Your target becomes [[Invisible]] until the end of its next turn or uses a hostile action.

`Spell`