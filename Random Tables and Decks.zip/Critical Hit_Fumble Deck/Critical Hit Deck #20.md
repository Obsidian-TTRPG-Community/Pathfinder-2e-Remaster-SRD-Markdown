---
title: "Critical Hit Deck #20"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #20"
foundryId: JournalEntry.6imMqJC2aA3WYzss.JournalEntryPage.jU2mfBSZkV0Ek5gE
tags:
  - JournalEntryPage
---
# Brained

> The target is [[Stunned 1]].

`Bludgeoning`

# Kidney Piercing

> The target is [[Sickened 1|Sickened 2]].

`Piercing`

# Fingertipped

> Normal damage. Until healed, the target is [[Clumsy 1]] and can't use one of its hands (chosen randomly by the GM).

`Slashing`

# Eyeburn

> The target is [[Blinded]] until the end of its next turn.

`Bomb or Spell`