---
title: "Critical Hit Deck #33"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #33"
foundryId: JournalEntry.FhmNimubjJKsQyP1.JournalEntryPage.61SADGhFPc7Ra59P
tags:
  - JournalEntryPage
---
# Broken Ribs

> Normal damage. **Crit Effect:** The target is [[Slowed 1]] until healed.

`Bludgeoning`

# Spinal Tap

> Normal damage. **Crit Effect:** The target is [[Sickened 1|Sickened 3]].

`Piercing`

# Nerve Slice

> **Crit Effect:** The target is [[Slowed 1|Slowed 2]] for 1 round.

`Slashing`

# Forceful Blast

> The bomb or spell deals and additional [[/r 1d8\[force]]\] damage.

`Bomb or Spell`