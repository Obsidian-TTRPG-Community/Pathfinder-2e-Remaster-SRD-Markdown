---
title: "Critical Fumble Deck #45"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #45"
foundryId: JournalEntry.ZHY09a25SNeECQN0.JournalEntryPage.jE2DwXGkwsJABkA1
tags:
  - JournalEntryPage
---
# This is Bad

> You take [[/r 1d10\[bleed]]\].

`Melee`

# What are the Odds?

> If this is a thrown weapon attack and the target can hold the weapon, the target snatches the weapon out of the air and wields it.

`Ranged`

# Whirlwind of Shame

> You hit every creature adjacent to you except for the target.

`Unarmed`

# Jumbled Components

> You are [[Slowed 1|Slowed 2]] until the end of your next turn.

`Spell`