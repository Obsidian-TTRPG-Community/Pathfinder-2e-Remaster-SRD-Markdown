---
title: "Critical Hit Deck #27"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #27"
foundryId: JournalEntry.GwosjnugQpAVosco.JournalEntryPage.cAf08LJb1eMwAUR9
tags:
  - JournalEntryPage
---
# Crushed Trachea

> **Crit Effect:** The target is Suffocating until subject to magical healing. It can't speak while it is suffocating.

`Bludgeoning`

# Pierced Elbow

> The target drops one item it is holding (determined randomly by the GM).

`Piercing`

# Long Gash

> Normal damage. **Crit Effect:** The target takes [[/r 1d4\[bleed]]\]. The DC of the flat check to remove this bleed damage is 5 higher than normal.

`Slashing`

# Vulnerability

> The target gains weakness 5 to any damage types dealt by the bomb or spell for 1 minute.

`Bomb or Spell`