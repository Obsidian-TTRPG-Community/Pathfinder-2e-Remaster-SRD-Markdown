---
title: "Critical Fumble Deck #39"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #39"
foundryId: JournalEntry.h0D2sPshSNQXn8Yp.JournalEntryPage.klRXj66DUAy1d1V5
tags:
  - JournalEntryPage
---
# On the receiving End

> You deal damage to yourself instead of the target.

`Melee`

# In the line of Fire

> You critically hit your nearest ally.

`Ranged`

# Head, meet wall

> You are [[Stunned 1]].

`Unarmed`

# Can you hear me Now?

> Until healed, you are [[Deafened]].

`Spell`