---
title: "Critical Fumble Deck #53"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #53"
foundryId: JournalEntry.LsEjWoDhlNwNjTBz.JournalEntryPage.nAQt4JAeqobILZOF
tags:
  - JournalEntryPage
---
# Punt

> Your weapon files [[/r 1d4\*5]] feet in a random direction [[/r 1d8#1 equals North, going clockwise]] (determined by the GM).

`Melee`

# So much Blood

> You are [[Sickened 1|Sickened 3]].

`Ranged`

# Unintentional Move

> You are moved 10 feet in a random direction [[/r 1d8#1 equals North, going clockwise]] (determined by the GM). This movement triggers reactions.

`Unarmed`

# It's so Sparkly!

> You are [[Blinded]] until the end of your next turn.

`Spell`