---
title: "Critical Hit Deck #23"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #23"
foundryId: JournalEntry.swrSxFqmWvCMcZ39.JournalEntryPage.KAsdzGsp84DphbcZ
tags:
  - JournalEntryPage
---
# Overwhelming Smash

> Triple damage.

`Bludgeoning`

# Nicked an Artery

> Normal damage. **Crit Effect:** The target takes [[/r 2d6\[bleed]]\].

`Piercing`

# Care your Initials

> Normal damage. The target is so humiliated it can do nothing but attack you. At the end of each of its turns, it can attempt a @Check\[type:will\] to end this effect.

`Slashing`

# Distraction

> The target is [[Off-Guard]] until the end of its next turn.

`Bomb or Spell`