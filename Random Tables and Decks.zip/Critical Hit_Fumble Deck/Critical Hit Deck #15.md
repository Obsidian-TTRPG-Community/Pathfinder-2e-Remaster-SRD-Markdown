---
title: "Critical Hit Deck #15"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #15"
foundryId: JournalEntry.walcDPrbSuU4EUM2.JournalEntryPage.8catEKrHLlFFcnKK
tags:
  - JournalEntryPage
---
# Numbing Blow

> Normal damage. **Crit Effect:** The target is [[Clumsy 1]] for 1 minute and must succeed at a @Check\[type:reflex\] or drop one item it holds at random.

`Bludgeoning`

# Sucking chest Wound

> The target is [[Fatigued]].

`Piercing`

# Overhand Chop

> **Crit Effect:** 1d8 persistent bleed damage.

`Slashing`

# Knockback

> Push the target up to 10 feet.

`Bomb or Spell`