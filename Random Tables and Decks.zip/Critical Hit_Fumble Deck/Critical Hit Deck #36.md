---
title: "Critical Hit Deck #36"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #36"
foundryId: JournalEntry.HN5TQ30lQBVCVfqC.JournalEntryPage.qJaP33VzLsKefpSc
tags:
  - JournalEntryPage
---
# Box the Ears

> The target is [[Deafened]] until healed.

`Bludgeoning`

# Javelin Catcher

> Triple damage if the attack was ranged or thrown attack. Double damage for all other attacks.

`Piercing`

# Lip Cut

> The target must succeed at a @Check\[type:flat|dc:5\] to cast spells with a verbal component until healed.

`Slashing`

# Call of the Wild

> Triple damage to animals, beasts, and fey. Double damage to all other creatures.

`Bomb or Spell`