---
title: "Critical Hit Deck #39"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #39"
foundryId: JournalEntry.0g340WHZ9EfntzvP.JournalEntryPage.znDpd5Z0k6bq6WCr
tags:
  - JournalEntryPage
---
# Soul-Crushing Blow

> **Crit Effect:** The target is [[Doomed 1]] and is [[Stupefied 1]] for as long as it is doomed.

`Bludgeoning`

# Knockback

> The target is pushed 10 feet.

`Piercing`

# Armor Damage

> The target's armor also takes the damage (applying the armor's Hardness normally).

`Slashing`

# Draining Strike

> The target loses one random prepared spell or spell slot, as determined by the GM.

`Bomb or Spell`