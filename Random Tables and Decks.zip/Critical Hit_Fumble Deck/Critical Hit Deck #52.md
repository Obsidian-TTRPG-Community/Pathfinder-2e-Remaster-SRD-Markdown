---
title: "Critical Hit Deck #52"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #52"
foundryId: JournalEntry.NGEJx9HiSqdrsgXT.JournalEntryPage.E06pVpFdVXuRKgLT
tags:
  - JournalEntryPage
---
# Lights Out

> **Crit Effect:** The target is [[Blinded]] until the end of its next turn.

`Bludgeoning`

# Bicep Wound

> The target is [[Enfeebled 1]] until healed.

`Piercing`

# Bewildering Display

> The target is [[Off-Guard]] until the end of its next turn.

`Slashing`

# Roaring Blast

> The target is [[Deafened]] until healed.

`Bomb or Spell`