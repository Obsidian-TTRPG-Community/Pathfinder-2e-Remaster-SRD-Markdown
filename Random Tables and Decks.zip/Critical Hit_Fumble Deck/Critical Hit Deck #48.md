---
title: "Critical Hit Deck #48"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #48"
foundryId: JournalEntry.IUA4GHBwCNxRu7Xf.JournalEntryPage.EAYQXMZmvqXhDVKX
tags:
  - JournalEntryPage
---
# Earth Rumble

> Normal damage. **Crit Effect:** The target and each enemy adjacent to it must succeed at a @Check\[type:reflex\] of fall [[Prone]].

`Bludgeoning`

# Vulnerable Spot

> The target is [[Off-Guard]] until healed.

`Piercing`

# Shield Cleave

> Deal normal damage to the target's shield (apply Hardness normally).

`Slashing`

# Wild Surge

> Normal damage and then normal damage again of a random energy type (roll [[/r 1d4#1-acid; 2-cold; 3-fire; 4-electricity]]{1d4; 1-acid; 2-cold; 3-fire; 4-electricity}).

`Bomb or Spell`