---
title: "Critical Fumble Deck #14"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #14"
foundryId: JournalEntry.SIB5bH10OBsuoQQ3.JournalEntryPage.hRnoJuHZgvnm0y4Y
tags:
  - JournalEntryPage
---
# Notched

> Your weapon takes [[/r 1d6]] damage, ignoring Hardness.

`Melee`

# Notched Fingers

> You take [[/r 1d4\[bleed]]\].

`Ranged`

# Hit the Wall

> You are [[Fatigued]].

`Unarmed`

# Electrical Feedback

> You take [[/r 2d6\[electricity]]\] damage.

`Spell`