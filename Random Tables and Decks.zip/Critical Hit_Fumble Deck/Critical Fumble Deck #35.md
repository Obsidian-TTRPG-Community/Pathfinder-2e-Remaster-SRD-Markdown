---
title: "Critical Fumble Deck #35"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #35"
foundryId: JournalEntry.k8QCfJxSM4dEDHnp.JournalEntryPage.k7BzBti00xCRMnZq
tags:
  - JournalEntryPage
---
# Bonk!

> You are [[Stunned 1|Stunned 2]].

`Melee`

# Shot your Foot

> Until healed, you are [[Clumsy 1|Clumsy 2]] and take a [[Effect\_ -5-foot circumstance penalty to your land Speed|-5-foot circumstance penalty to your land speed]].

`Ranged`

# Overexertion

> You are [[Fatigued]].

`Unarmed`

# Side Effect

> You are [[Sickened 1]]. You are also [[Stupefied 1|Stupefied 2]] until healed.

`Spell`