---
title: "Critical Fumble Deck #38"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #38"
foundryId: JournalEntry.viv0mJa7CDl9iwCg.JournalEntryPage.qFcMTp2HirNwCf5g
tags:
  - JournalEntryPage
---
# Rang your own Bell

> Until healed, you are [[Deafened]].

`Melee`

# Lowered Guard

> You provoke reactions as if you used a move action.

`Ranged`

# Ferocious Fumble

> You critically hit an ally within your reach (determined randomly by the GM).

`Unarmed`

# The magic is Gone

> You take a [[Effect\_ -1 circumstance penalty to attack rolls until you score a critical hit|-1 circumstance penalty to attack rolls until you score a critical hit]].

`Spell`