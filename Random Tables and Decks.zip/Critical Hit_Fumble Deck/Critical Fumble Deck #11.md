---
title: "Critical Fumble Deck #11"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #11"
foundryId: JournalEntry.5Y6iVlgv6vn2MVVM.JournalEntryPage.DbGY1HRle0RP8yQZ
tags:
  - JournalEntryPage
---
# Slipped

> You fall [[Prone]].

`Melee`

# Backfire

> You hit yourself instead of the target.

`Ranged`

# Bruised Ego

> You can't attack another creature until the target is knocked out or the end of your next turn.

`Unarmed`

# Nosebleed

> You take @Localize\[PF2E.PersistentDamage.Bleed1.success\].

`Spell`