---
title: "Critical Hit Deck #11"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #11"
foundryId: JournalEntry.dVHpVqrbc8xqi6k8.JournalEntryPage.URrgkZ8uRkzt2Zhf
tags:
  - JournalEntryPage
---
# Broken Nose

> The target takes [[/r 1d4\[bleed]]\].

`Bludgeoning`

# Two in a Row

> **Crit Effect:** Deal normal damage to an additional target adjacent to the original target.

`Piercing`

# Weapon Strike

> **Crit Effect:** Deal normal damage to one of the target's weapons (applying Hardness normally).

`Slashing`

# Nerve Damage

> Normal damage. The target is [[Slowed 1]] until healed.

`Bomb or Spell`