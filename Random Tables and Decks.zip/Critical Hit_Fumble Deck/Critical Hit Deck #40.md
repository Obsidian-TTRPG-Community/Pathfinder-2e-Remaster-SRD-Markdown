---
title: "Critical Hit Deck #40"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #40"
foundryId: JournalEntry.qMsI5Luzda5eiQTJ.JournalEntryPage.KAlZA2xLfbcGEm4E
tags:
  - JournalEntryPage
---
# Breathless

> The target is [[Fatigued]].

`Bludgeoning`

# Spun Around

> The target is [[Off-Guard]] until the end of its next turn.

`Piercing`

# Sliced Hand

> Normal damage. Until healed, the target is [[Enfeebled 1]], [[Clumsy 1]], and can't used one of its hands (determined randomly by the GM).

`Slashing`

# Combustion

> If this is a fire bomb or spell, the target takes triple damage and [[/r 1d6\[persistent,fire]]\]. Any other bomb or spell deals double damage.

`Bomb or Spell`