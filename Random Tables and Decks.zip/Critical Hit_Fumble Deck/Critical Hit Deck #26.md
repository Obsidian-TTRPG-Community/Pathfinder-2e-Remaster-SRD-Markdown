---
title: "Critical Hit Deck #26"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #26"
foundryId: JournalEntry.e9xtIFpsqUmmQ4Q5.JournalEntryPage.tn6geVSwpDWKhMFC
tags:
  - JournalEntryPage
---
# Crushed Intestines

> Normal damage. **Crit Effect:** The target is [[Wounded 1|Wounded 2]] and [[Enfeebled 1|Enfeebled 2]] until it is no longer wounded.

`Bludgeoning`

# Lodged in the Bone

> **Crit Effect:** The target takes [[/r 1d6\[bleed]]\].

`Piercing`

# Severed Spine

> **Crit Effect:** The target must succeed at a @Check\[type:fortitude\] or be [[Paralyzed]] until healed.

`Slashing`

# Psychic Overflow

> The target takes [[/r 1d8\[mental]]\] damage.

`Bomb or Spell`