---
title: "Critical Hit Deck #51"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #51"
foundryId: JournalEntry.RhrKQ4gD5rMlps4E.JournalEntryPage.SVt7DN4eRBljHvWX
tags:
  - JournalEntryPage
---
# Foot Smash

> The target is [[Off-Guard]] until the end of its next turn.

`Bludgeoning`

# Organ Scramble

> Triple damage. **Crit Effect:** The target is [[Fatigued]].

`Piercing`

# Wing Tear

> The target loses any fly Speed until healed.

`Slashing`

# Energy Might

> If the bomb or spell deals acid, cold, electricity, fire or sonic damage, it deals triple damage. Any other bomb or spells deals double damage.

`Bomb or Spell`