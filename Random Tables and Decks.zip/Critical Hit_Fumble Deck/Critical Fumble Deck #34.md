---
title: "Critical Fumble Deck #34"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #34"
foundryId: JournalEntry.GER4GgsA6KEisgDX.JournalEntryPage.MAjmNAKgJd4UqEfQ
tags:
  - JournalEntryPage
---
# Weapon Tangle

> You can't use this weapon to attack until the end of your next turn.

`Melee`

# Amazing Miss

> You are [[Stunned 1]].

`Ranged`

# Bone Bruise

> You become [[Wounded 1]] or your wounded value increases by 1.

`Unarmed`

# You made 'em Bigger

> The target increases in size, with the effects of a 2nd level _[[Enlarge]]_ spell. [[Spell Effect\_ Enlarge|Spell Effect: Enlarge]]

`Spell`