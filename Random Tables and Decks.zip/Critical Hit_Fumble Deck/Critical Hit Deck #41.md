---
title: "Critical Hit Deck #41"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #41"
foundryId: JournalEntry.n3tKD8dGLKdyTNN0.JournalEntryPage.Okqxk51eZT2JWJnw
tags:
  - JournalEntryPage
---
# Broken Leg

> **Crit Effect:** The target takes a [[Effect\_ -15-foot status penalty to your land Speed|-15-foot circumstance penalty to your land Speed]] until healed.

`Bludgeoning`

# Grazing Hit

> Normal damage. **Crit Effect:** The target is [[Stunned 1|Stunned 3]].

`Piercing`

# Swing Through

> **Crit Effect:** Make an additional attack against a foe adjacent to the original target, using the same attack modifier as the original attack.

`Slashing`

# Maximum Effect

> Don't roll for damage. You deal the maximum possible critical hit damage with this attack.

`Bomb or Spell`