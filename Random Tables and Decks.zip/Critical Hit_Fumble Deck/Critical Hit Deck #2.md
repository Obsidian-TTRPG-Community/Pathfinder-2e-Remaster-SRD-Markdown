---
title: "Critical Hit Deck #2"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #2"
foundryId: JournalEntry.UPC6lybcPVPQOvoz.JournalEntryPage.Y3etmaTpdsMT3kKp
tags:
  - JournalEntryPage
---
# Where Am I?

> Normal damage. **Crit Effect:** The target is [[Stunned 1|Stunned 2]].

`Bludgeoning`

# Surprise Opening

> **Crit Effect:** You gain 1 action that you can use before the end of your turn to use an attack action against the target.

`Piercing`

# Missing Ear

> Normal damage. The target takes a -2 circumstance penalty to Perception check and Charisma-based check except Intimidation until healed.

`Slashing`

# Mind Cloud

> The target is [[Stupefied 1|Stupefied 2]] until healed.

`Bomb or Spell`