---
title: "Critical Fumble Deck #31"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #31"
foundryId: JournalEntry.iphVZiB77o0KUrwc.JournalEntryPage.AHnMn8nDzBU8XiDZ
tags:
  - JournalEntryPage
---
# Stuck

> Your weapon is lodged into a nearby surface or item. To free it, you must succeed at a @Check\[type:athletics|dc:20|name:Unlodge Weapon\] check made as and [[Interact]] action.

`Melee`

# Archer's Elbow

> Until healed, you take a -2 circumstance penalty to ranged attacks.

`Ranged`

# Off Balance

> You are [[Slowed 1|Slowed 2]] until the end of your next turn.

`Unarmed`

# Spell Shield

> The target gains a [[Effect\_ +2 status bonus to saving throws against spells for 1 min|+2 status bonus to saving throws against spells for 1 min]].

`Spell`