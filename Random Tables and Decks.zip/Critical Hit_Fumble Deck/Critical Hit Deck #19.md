---
title: "Critical Hit Deck #19"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #19"
foundryId: JournalEntry.mosuht29xyL9PHA6.JournalEntryPage.ymqdYEJyGiqAOijp
tags:
  - JournalEntryPage
---
# Nighty Night

> Normal damage. **Crit Effect:** The target falls [[Unconscious]] and can't wake up until the end of its next turn.

`Bludgeoning`

# Painful Poke

> The target is [[Stunned 1]].

`Piercing`

# That'll Leave a Mark!

> Normal damage. **Crit Effect:** The target takes [[/r 2d6\[bleed]]\].

`Slashing`

# Devastating Strike

> Triple damage. The target is [[Stunned 1]].

`Bomb or Spell`