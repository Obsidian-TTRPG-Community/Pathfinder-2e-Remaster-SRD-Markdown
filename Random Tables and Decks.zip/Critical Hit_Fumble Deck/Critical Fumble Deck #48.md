---
title: "Critical Fumble Deck #48"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #48"
foundryId: JournalEntry.DWh1hdRpyOkeWo4g.JournalEntryPage.hbbqXuMIjP1O5ivM
tags:
  - JournalEntryPage
---
# Catastrophic Failure

> You fall [[Unconscious]] until you awake up or the end of your next turn.

`Melee`

# Overthrow

> If the attack used a thrown weapon, the weapon travels three times its range increment in a random direction (determined by the GM).

`Ranged`

# Don't pick it It

> You become [[Wounded 1]] or your wounded value increases by 1.

`Unarmed`

# Magical Smackdown

> You automatically fail (but do not critically fail) your next saving throw.

`Spell`