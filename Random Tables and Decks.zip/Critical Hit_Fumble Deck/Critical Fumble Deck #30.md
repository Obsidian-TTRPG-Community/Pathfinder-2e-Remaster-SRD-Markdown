---
title: "Critical Fumble Deck #30"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #30"
foundryId: JournalEntry.bHkyQjWKbyoGF5J7.JournalEntryPage.d0OhvD2MJiKwDp6d
tags:
  - JournalEntryPage
---
# Grave Miscalculation

> You critically hit yourself with the attack.

`Melee`

# Kickback like a Mule

> You fall [[Prone]].

`Ranged`

# Can't find an Opening

> You can't use this attack until the end of your next turn.

`Unarmed`

# Drawing a Blank

> Until healed, you are [[Stupefied 1]].

`Spell`