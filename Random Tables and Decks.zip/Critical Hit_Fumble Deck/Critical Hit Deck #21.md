---
title: "Critical Hit Deck #21"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #21"
foundryId: JournalEntry.XNJnkf39v3lDnbap.JournalEntryPage.14krStxw1Eirik24
tags:
  - JournalEntryPage
---
# Collapsed Lung

> Normal damage. **Crit Effect:** Until healed, the target is [[Enfeebled 1|Enfeebled 2]] and [[Fatigued]].

`Bludgeoning`

# Never Cluster

> Normal damage. **Crit Effect:** The target is [[Stunned 1|Stunned 2]].

`Piercing`

# Rupture Abdominal Cavity

> Triple damage. The target is [[Fatigued]].

`Slashing`

# Transposition

> If this is a spell attack, you and the target switch places. This is a teleportation effect.

`Bomb or Spell`