---
title: "Critical Fumble Deck #42"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #42"
foundryId: JournalEntry.Ki20dtFjlqoE8QKx.JournalEntryPage.WBUwp076Zb1XZceP
tags:
  - JournalEntryPage
---
# Winded

> You are [[Fatigued]].

`Melee`

# Bad Alignment

> You take a [[Effect\_ -2 circumstance penalty to attack rolls with this weapon|-2 circumstance penalty to attack rolls with this weapon]] until the end of your next turn.

`Ranged`

# It bit your Fist

> The target deals jaws damage to you.

`Unarmed`

# Poor Trade

> You hit, but you lose a prepared spell or spell slot of the highest level available (you choose the spell).

`Spell`