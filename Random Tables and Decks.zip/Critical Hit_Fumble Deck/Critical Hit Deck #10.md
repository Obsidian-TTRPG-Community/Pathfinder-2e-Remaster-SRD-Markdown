---
title: "Critical Hit Deck #10"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #10"
foundryId: JournalEntry.aBzNx8Cyahzn88iT.JournalEntryPage.jON5ZXJSqO78xFNT
tags:
  - JournalEntryPage
---
# I See Stars

> Normal damage. **Crit Effect:** The target is [[Dazzled]] until healed.

`Bludgeoning`

# Pinhole

> **Crit Effect:** The target takes @Localize\[PF2E.PersistentDamage.Bleed1.success\] that can't be removed until the target is healed.

`Piercing`

# Disembowel

> Triple damage.

`Slashing`

# Conduit

> The target takes a -2 status penalty to AC and saves against your bombs or spells until the end of your next turn.

`Bomb or Spell`