---
title: "Critical Hit Deck #13"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #13"
foundryId: JournalEntry.wSevlvWXgS3BkePr.JournalEntryPage.kQHLnBkfwg7mgZAD
tags:
  - JournalEntryPage
---
# Crumpling Blow

> The target is knocked [[Prone]].

`Bludgeoning`

# Pierced

> The target is [[Slowed 1]] until the end of its next turn.

`Piercing`

# Throat Slash

> Normal damage. **Crit Effect:** The target takes [[/r 1d8\[bleed]]\]. The target can't talk, cast spells with a verbal component, or breathe while subject to this bleed damage.

`Slashing`

# Life Leech

> If this is a spell, the target becomes [[Doomed 1]] and you regain [[/r 1d8]] Hit Points.

`Bomb or Spell`