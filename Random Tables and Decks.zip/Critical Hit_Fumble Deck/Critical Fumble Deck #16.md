---
title: "Critical Fumble Deck #16"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #16"
foundryId: JournalEntry.Suj8ma3FKy6SoDr4.JournalEntryPage.1Xh3F6JINcq67Avv
tags:
  - JournalEntryPage
---
# Fling

> You drop the weapon you used for the attack. It lands [[/r 1d6\*5]] feet away from your in a random direction [[/r 1d8]].

`Melee`

# Head Rush

> You are [[Sickened 1|Sickened 2]]

`Ranged`

# Overextended

> You trigger reactions as if you had used a move action.

`Unarmed`

# Reflection

> The spell hits you instead of the target.

`Spell`