---
title: "Critical Hit Deck #7"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #7"
foundryId: JournalEntry.X0dIRZ1UbpD8DyjW.JournalEntryPage.d0sh4NZCQ5cKu4ae
tags:
  - JournalEntryPage
---
# Bell Ringer

> **Crit Effect:** The target is [[Sickened 1|Sickened 2]], and it is [[Stupefied 1|Stupefied 2]] until it is no longer sickened.

`Bludgeoning`

# Skewered

> Triple damage. **Crit Effect:** The target is [[Slowed 1]] for 1 round.

`Piercing`

# Momentum

> You gain a [[Effect\_ +2 circumstance bonus to attack rolls|+2 circumstance bonus to attack rolls]] until the end of your next turn.

`Slashing`

# Petrified

> The target is [[Petrified]] for 10 minutes.

`Bomb or Spell`