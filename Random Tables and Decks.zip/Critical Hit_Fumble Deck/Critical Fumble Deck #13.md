---
title: "Critical Fumble Deck #13"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #13"
foundryId: JournalEntry.3mfdmhAwlMczVsSN.JournalEntryPage.O54GgNHACD44rViW
tags:
  - JournalEntryPage
---
# Butterfingers

> You drop the weapon you made the attack with.

`Melee`

# Snapped String

> If the attack used a weapon in the bow group, the string snaps, requiring 3 Interact actions to fix.

`Ranged`

# Torn Muscle

> Until healed, you are [[Enfeebled 1]].

`Unarmed`

# Magic Fatigue

> You can't cast any spells until the end of your next turn.

`Spell`