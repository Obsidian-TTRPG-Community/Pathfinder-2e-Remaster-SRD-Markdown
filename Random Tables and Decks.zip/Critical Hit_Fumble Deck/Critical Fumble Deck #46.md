---
title: "Critical Fumble Deck #46"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #46"
foundryId: JournalEntry.5P2xrCWQk9L3fkJ2.JournalEntryPage.uxrtM7Zg7HSzLogm
tags:
  - JournalEntryPage
---
# Clipped your Hand

> You take [[/r 1d8\[bleed]]\].

`Melee`

# Oopsie!

> You hit yourself instead of the target.

`Ranged`

# Ingrown Nail

> You take a [[Effect\_ -1 circumstance penalty to attack rolls until you score a critical hit|-1 circumstance penalty to attack rolls until you score a critical hit]].

`Unarmed`

# Clatto Verata Necktie

> You critically hit your nearest ally.

`Spell`