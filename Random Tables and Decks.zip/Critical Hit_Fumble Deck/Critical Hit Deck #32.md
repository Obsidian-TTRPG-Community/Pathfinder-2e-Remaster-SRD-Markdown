---
title: "Critical Hit Deck #32"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #32"
foundryId: JournalEntry.drkSZLyn7m0qOGnR.JournalEntryPage.tUgtvtXyPyK1XHIt
tags:
  - JournalEntryPage
---
# Clocked!

> Triple damage. The target is knocked [[Prone]].

`Bludgeoning`

# Head Shot

> Triple damage. **Crit Effect:** The target must succeed at a @Check\[type:fortitude\] or die.

`Piercing`

# From chops to Groin

> Triple damage. **Crit Effect:** The target must succeed at a @Check\[type:fortitude\] or die.

`Slashing`

# Doomed!

> The target is [[Slowed 1]] for 1 round, and is also [[Doomed 1]].

`Bomb or Spell`