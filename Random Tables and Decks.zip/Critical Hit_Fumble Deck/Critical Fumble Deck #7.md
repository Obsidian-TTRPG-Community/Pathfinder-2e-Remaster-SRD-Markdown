---
title: "Critical Fumble Deck #7"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #7"
foundryId: JournalEntry.Ut6u0IDNzEVqlIw4.JournalEntryPage.zW0b5OCcFi5TPYp5
tags:
  - JournalEntryPage
---
# Vibration

> If you're using a bludgeoning weapon, you drop that weapon and become [[Enfeebled 1|Enfeebled 2]] until healed.

`Melee`

# Recoil

> You are pushed 5 feet backwards and fall [[Prone]].

`Ranged`

# Punctured Foot

> You take [[/r 1d4\[bleed]]\]. Until this effect ends, you take a [[Effect\_ -10-foot circumstance penalty to your land Speed|-10-foot circumstance penalty to your land Speed]].

`Unarmed`

# Mental Backlash

> Until healed, you are [[Stupefied 1|Stupefied 3]].

`Spell`