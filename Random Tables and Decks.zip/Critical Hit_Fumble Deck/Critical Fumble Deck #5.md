---
title: "Critical Fumble Deck #5"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #5"
foundryId: JournalEntry.M1Ik4ILX5ccR0PYq.JournalEntryPage.LXVN3PrglHFeUUQI
tags:
  - JournalEntryPage
---
# Bad Grip

> You take a [[Effect\_ -2 circumstance penalty to attack rolls with this weapon|-2 circumstance penalty to attack rolls with this weapon]] until the end of your next turn.

`Melee`

# Huh?

> You are [[Confused]]

`Ranged`

# Eye Strain

> You are [[Dazzled]] until the end of your next turn.

`Unarmed`

# Blastoff

> You must succeed at a @Check\[type: will\] saving throw or be thrown [[/r 1d6\*5]] feet into the air (or in a random direction determined by the GM if you are flying).

`Spell`