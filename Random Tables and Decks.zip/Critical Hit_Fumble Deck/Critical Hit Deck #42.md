---
title: "Critical Hit Deck #42"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #42"
foundryId: JournalEntry.HEnTU3nvuo53kYbX.JournalEntryPage.ZNh4PvHcmQEOa65W
tags:
  - JournalEntryPage
---
# Shield Smack

> **Crit Effect:** The target must succeed at a @Check\[type:reflex\] or drop a shield it's holding.

`Bludgeoning`

# Penetrating Wound

> The attack ignores all resistances.

`Piercing`

# Muscle Wound

> **Crit Effect:** The target is [[Enfeebled 1|Enfeebled 2]] until healed.

`Slashing`

# Intense Strike

> The attack ignores all resistances.

`Bomb or Spell`