---
title: "Critical Fumble Deck #9"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #9"
foundryId: JournalEntry.K00GuGExo1g2Kc4h.JournalEntryPage.IKTn2I00FjQ8CFT5
tags:
  - JournalEntryPage
---
# Attack the Darkness

> Your enemies are [[Concealed]] from you until the end of your next turn.

`Melee`

# Aim Carefully Next Time

> Until the end of your next turn, your attacks require and extra action to use.

`Ranged`

# Brutal Collision

> Attempt a @Check\[type: fortitude\] saving throw. If you succeed, you're [[Stunned 1]]. If you fail, you're [[Stunned 1|Stunned 2]].

`Unarmed`

# Power Transfer

> The highest-level beneficial spell effect currently affecting you is transferred to your target.

`Spell`