---
title: "Critical Hit Deck #6"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #6"
foundryId: JournalEntry.75PRwhJ28RmhXHhj.JournalEntryPage.yy6uVnmPsQNaxks9
tags:
  - JournalEntryPage
---
# Cracked Knee

> **Crit Effect:** Until healed, the target is [[Clumsy 1|Clumsy 2]] and takes a [[Effect\_ -5-foot status penalty to your land Speed|-5-foot status penalty to land Speed]].

`Bludgeoning`

# Calf Jab

> **Crit Effect:** Until healed, the target is [[Clumsy 1]] and takes a [[Effect\_ -10-foot status penalty to your land Speed|-10-foot status penalty to your land Speed]].

`Piercing`

# Ugly Wound

> The target takes a -2 circumstance penalty to checks with all Charisma-based skills except Intimidation.

`Slashing`

# Now you see me...

> You become [[Invisible]] until the end of your next turn or until you use a hostile action.

`Bomb or Spell`