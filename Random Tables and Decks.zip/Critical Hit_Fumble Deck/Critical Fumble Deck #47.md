---
title: "Critical Fumble Deck #47"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #47"
foundryId: JournalEntry.3lDf2GHPXKJIfiNk.JournalEntryPage.GM8KhEJHweIyOXpQ
tags:
  - JournalEntryPage
---
# Decision Paralysis

> You are [[Slowed 1]] until the end of your next turn.

`Melee`

# Torn Tendon

> Until healed, you are [[Clumsy 1|Clumsy 2]].

`Ranged`

# Stinging Failure

> Until healed, you take a [[Effect\_ -2 circumstance penalty to attack rolls made with this attack until healed|-2 circumstance penalty to attack rolls made with this attack until healed]].

`Unarmed`

# Cursed

> You are [[Doomed 1]].

`Spell`