---
title: "Critical Hit Deck #49"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #49"
foundryId: JournalEntry.BykdaMeD3PEWiSvX.JournalEntryPage.XTAKgmqj1ZFepfHx
tags:
  - JournalEntryPage
---
# Solid Blow

> Triple damage.

`Bludgeoning`

# Tenacious Wound

> Normal damage. **Crit Effect:** The target can't heal this damage until it has rested at least 8 hours.

`Piercing`

# Parrying Strike

> **Crit Effect:** Gain a [[Effect\_ +2 circumstance bonus to AC|+2 circumstance bonus to AC]] until the end of your next turn.

`Slashing`

# Phased

> The target becomes incorporeal (Pathfinder Bestiary 346) until the end of your next turn.

`Bomb or Spell`