---
title: "Critical Hit Deck #46"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #46"
foundryId: JournalEntry.o5tF4rbA4nV8faVA.JournalEntryPage.vbCWhbKx24g0Q40U
tags:
  - JournalEntryPage
---
# Busted Shin

> **Crit Effect:** Until healed, the target is [[Clumsy 1]] and takes a [[Effect\_ -10-foot status penalty to your land Speed|-10-foot status penalty to your land Speed]].

`Bludgeoning`

# Perfect strike

> Triple damage.

`Piercing`

# Sapping Slash

> **Crit Effect:** The target is [[Fatigued]].

`Slashing`

# Light Blast

> The target is [[Blinded]] until the end of its next turn.

`Bomb or Spell`