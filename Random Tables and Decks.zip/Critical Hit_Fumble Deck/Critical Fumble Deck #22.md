---
title: "Critical Fumble Deck #22"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #22"
foundryId: JournalEntry.2AYd7beqAHWjEN6R.JournalEntryPage.ChyeVeGrXiP83SMI
tags:
  - JournalEntryPage
---
# Wide Open

> You are [[Effect\_ Off-Guard until end of your next turn|Effect: Off-Guard until end of your next turn]] .

`Melee`

# Cracked

> The ranged weapon (not the ammunition) you are using takes [[/r 1d6]] damage, ignoring Hardness.

`Ranged`

# Fist meet Face

> You critically hit yourself with the attack.

`Unarmed`

# Distance Rift

> You are teleported to the nearest space adjacent to your spell's target.

`Spell`