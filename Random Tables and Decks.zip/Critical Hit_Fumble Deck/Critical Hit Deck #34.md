---
title: "Critical Hit Deck #34"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #34"
foundryId: JournalEntry.eOdUCFnZ0xosFEOK.JournalEntryPage.UnOv3yIG2BFWBvOo
tags:
  - JournalEntryPage
---
# Staggering Blow

> **Crit Effect:** The target is [[Stunned 1|Stunned 2]].

`Bludgeoning`

# Heart Shot

> Triple damage. **Crit Effect:** The target takes [[/r 1d4\[bleed]]\].

`Piercing`

# Leg Swipe

> The target is knocked [[Prone]].

`Slashing`

# Terrifying Display

> The target is [[Frightened 1|Frightened 3]].

`Bomb or Spell`