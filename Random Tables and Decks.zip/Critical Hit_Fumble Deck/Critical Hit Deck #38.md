---
title: "Critical Hit Deck #38"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #38"
foundryId: JournalEntry.cT8zfYeiUDkaZYxW.JournalEntryPage.hfnqwRiA1F8yFxO2
tags:
  - JournalEntryPage
---
# Armor Dent

> Normal damage. **Crit Effect:** Deal the same amount of damage to the target's armor, ignoring that armor's Hardness.

`Bludgeoning`

# Eye patch for you

> Triple damage. **Crit Effect:** The target is [[Dazzled]] until healed.

`Piercing`

# Flat-Blade Thwack

> Triple damage. You can deal bludgeoning damage instead of slashing damage.

`Slashing`

# Magical Glow

> The target glows for 1 minute with the effect of a _[[Faerie Fire]]_ spell.

`Bomb or Spell`