---
title: "Critical Hit Deck #29"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #29"
foundryId: JournalEntry.QRKpWdwOqIjxjhPk.JournalEntryPage.YrNP8Havb1BQ6akO
tags:
  - JournalEntryPage
---
# Caved Skull

> Triple damage. **Crit Effect:** The target must succeed at a @Check\[type:fortitude\] or die.

`Bludgeoning`

# Overreaction

> Normal damage. The target triggers reactions as if it just used a move action. It is also [[Off-Guard]] until the end of its next turn.

`Piercing`

# Paper Cut

> The target takes a [[Effect\_ -2 circumstance penalty to attack rolls|-2 circumstance penalty to attack rolls]] until the end of its next turn.

`Slashing`

# Unnatural Selection

> Triple damage to aberrations, celestials, fiends, and monitors. Double damage to all other creatures.

`Bomb or Spell`