---
title: "Critical Fumble Deck #36"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #36"
foundryId: JournalEntry.QwisOeH76U6cuwM3.JournalEntryPage.e9OAyablRyqsYAaP
tags:
  - JournalEntryPage
---
# Sorry!

> You hit and ally adjacent to you or an ally adjacent to the target.

`Melee`

# Lost the Target

> You take a [[Effect\_ -2 circumstance penalty to attack rolls|-2 circumstance penalty to attack rolls]] until the end of your next turn.

`Ranged`

# Sprain

> Until healed, you are [[Clumsy 1|Clumsy 2]].

`Unarmed`

# Weakened

> You take [[Effect\_ -2 circumstance penalty to spell attack rolls and spell DC's|-2 circumstance penalty to spell attack rolls and spell DC's]] until the end of your next turn.

`Spell`