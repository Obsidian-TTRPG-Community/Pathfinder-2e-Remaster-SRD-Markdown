---
title: "Critical Fumble Deck #2"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #2"
foundryId: JournalEntry.ZSuIIWRSLdgbfBJ9.JournalEntryPage.jvnfW76s6YjUo71n
tags:
  - JournalEntryPage
---
# Wrong End

> If you are using a slashing weapon, you take [[/r 1d6\[slashing]]\] damage and 1 persistent bleed damage.

`Melee`

# Phantom Wind

> You take a [[Effect\_ -2 circumstance penalty to ranged attacks|-2 circumstance penalty to ranged attacks]] until the end of your next turn.

`Ranged`

# Overthink It

> Your target gains a [[Effect\_ +2 circumstance bonus to AC|+2 circumstance bonus to AC]] against attacks you make against it until the end of your next turn.

`Unarmed`

# Power Down

> Until healed, you are [[Stupefied 1|Stupefied 2]]

`Spell`