---
title: "Critical Fumble Deck #24"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #24"
foundryId: JournalEntry.3fI3QYgVDVHj6UGU.JournalEntryPage.TLsZved7H5lQtKWl
tags:
  - JournalEntryPage
---
# Too much Stuff!

> You get tangled in your gear and rare [[Encumbered]] until you spend 2 Interact actions to free yourself.

`Melee`

# Sprain

> Until healed, you are [[Clumsy 1|Clumsy 2]].

`Ranged`

# Bleeding Fist

> You take [[/r 1d6\[bleed]]\].

`Unarmed`

# Vertigo

> You are [[Sickened 1|Sickened 2]].

`Spell`