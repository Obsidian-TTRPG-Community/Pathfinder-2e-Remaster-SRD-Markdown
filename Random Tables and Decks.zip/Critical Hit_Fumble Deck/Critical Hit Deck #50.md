---
title: "Critical Hit Deck #50"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #50"
foundryId: JournalEntry.b3RGUOAatCb42kk8.JournalEntryPage.WheD4j70ekVgpFb7
tags:
  - JournalEntryPage
---
# Tiring Blow

> The target is [[Fatigued]].

`Bludgeoning`

# Leg Wound

> **Crit Effect:** The target takes a [[Effect\_ -5-foot status penalty to your land Speed|-5-foot status penalty to land Speed]] until healed.

`Piercing`

# Spun Around

> The target is [[Off-Guard]] until the end of its next turn.

`Slashing`

# Time Vortex

> If this is a spell, normal damage and the target vanishes and reappears [[/r 1d4#rounds]]{1d4 rounds} later. The target can use no actions, and any effects it has with durations do not pass while it's gone.

`Bomb or Spell`