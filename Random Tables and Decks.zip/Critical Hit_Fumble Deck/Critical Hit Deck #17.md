---
title: "Critical Hit Deck #17"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #17"
foundryId: JournalEntry.m7fkufXaWAnkK2Ab.JournalEntryPage.Clcu2H0uVyozvbI1
tags:
  - JournalEntryPage
---
# And stay Down

> Normal damage. **Crit Effect:** The target is knocked [[Prone]] and [[Stunned 1|Stunned 2]].

`Bludgeoning`

# Ventilated

> Triple damage.

`Piercing`

# Knockback

> Push the target up to 10 feet.

`Slashing`

# Frozen

> If this is a cold bomb or spell, the target takes triple damage and is [[Slowed 1|Slowed 2]] for 1 round. Any other bomb or spell deals double damage.

`Bomb or Spell`