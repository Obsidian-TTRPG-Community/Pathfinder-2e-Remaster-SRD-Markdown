---
title: "Critical Hit Deck #14"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #14"
foundryId: JournalEntry.BjKIBeO8DZv1lru3.JournalEntryPage.ftmugY4kI4X2OHtJ
tags:
  - JournalEntryPage
---
# Shattered Hand

> Normal damage. Until healed, the target is [[Clumsy 1|Clumsy 2]] and [[Enfeebled 1|Enfeebled 2]], and it can't use one of its hands (chosen randomly by the GM).

`Bludgeoning`

# Right in the Ear

> Normal damage. The target is [[Deafened]] until healed.

`Piercing`

# Stand Aside

> Push the target 5 feet.

`Slashing`

# Vampiric Feedback

> Normal damage. You regain Hit Points equal half the damage you dealt.

`Bomb or Spell`