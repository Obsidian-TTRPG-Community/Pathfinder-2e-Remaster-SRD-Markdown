---
title: "Critical Hit Deck #30"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #30"
foundryId: JournalEntry.tlJGDeFvmQDHey7l.JournalEntryPage.bLrBNA83wIHBP2Y0
tags:
  - JournalEntryPage
---
# To your thinky Bits

> **Crit Effect:** The target is [[Stupefied 1|Stupefied 2]] until healed.

`Bludgeoning`

# Clean Through

> Triple damage.

`Piercing`

# Wide Open

> The target is [[Off-Guard]] until the end of its next turn.

`Slashing`

# Hoarder's Wrath

> Triple damage to dragons. Double damage to all other creatures.

`Bomb or Spell`