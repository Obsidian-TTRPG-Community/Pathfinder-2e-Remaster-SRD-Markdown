---
title: "Critical Hit Deck #8"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #8"
foundryId: JournalEntry.farxv2k63Ir3bkYA.JournalEntryPage.OSj1vOhjm71h9Km6
tags:
  - JournalEntryPage
---
# Split Open

> **Crit Effect:** The target takes [[/r 1d6\[bleed]]\].

`Bludgeoning`

# Send 'em Reeling

> **Crit Effect:** The target is [[Off-Guard]] until the end of its next turn.

`Piercing`

# Shattered Jaw

> **Crit Effect:** Until healed, the target is [[Wounded 1]] and can't speak, eat, drink, or make attacks with its jaws.

`Slashing`

# Protective Charm

> You gain a [[Effect\_ +2 status bonus to AC and all saving throws|+2 status bonus to AC and all saving throws]] until the end of your next turn.

`Bomb or Spell`