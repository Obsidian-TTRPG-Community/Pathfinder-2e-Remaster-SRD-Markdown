---
title: "Critical Fumble Deck #1"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #1"
foundryId: JournalEntry.Bwmi8HE0PBKMaaxe.JournalEntryPage.97Rw9jJrOJa7NM0s
tags:
  - JournalEntryPage
---
# Meant to do That

> You are moved 10 feet in a random direction (determined by the GM). This movement triggers reactions.

`Melee`

# Misjudged the Distance

> Until the end of your next turn, all your range increment penalties are doubled.

`Ranged`

# Not the Weak Point

> You take and [[/r 1d6\[bleed]]\] and can't use this attack until the end of your next turn.

`Unarmed`

# How did that Happen?

> You call forth a mist with the effects of _[[Stinking Cloud]]_ centered on a corner of your space (determined by the GM).

`Spell`