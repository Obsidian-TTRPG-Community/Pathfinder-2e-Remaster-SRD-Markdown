---
title: "Critical Hit Deck #5"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #5"
foundryId: JournalEntry.d8iQghl61qrsQED1.JournalEntryPage.pLB1M1oHTnFnzSCR
tags:
  - JournalEntryPage
---
# Feeble Parry

> **Crit Effect:** The target drops one weapon it's wielding determined by the GM.

`Bludgeoning`

# Shoulder Wound

> **Crit Effect:** Until healed, the target is [[Clumsy 1]] and [[Enfeebled 1|Enfeebled 2]].

`Piercing`

# Hamstring

> Normal damage. **Crit Effect:** The target is knocked [[Prone]]. The target is also [[Clumsy 1|Clumsy 2]] until healed.

`Slashing`

# Cut off from Magic

> Normal damage. The target can't cast spells or activate magic items for [[/r 1d4#rounds]]{1d4 rounds}.

`Bomb or Spell`