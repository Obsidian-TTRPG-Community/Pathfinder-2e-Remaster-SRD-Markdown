---
title: "Critical Hit Deck #18"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #18"
foundryId: JournalEntry.sG21wy2wA06bwsH8.JournalEntryPage.7shwLAHvCpn9nNyP
tags:
  - JournalEntryPage
---
# Rattled

> Normal damage. **Crit Effect:** The target is [[Confused]] for 1 round.

`Bludgeoning`

# Guarded Strike

> **Crit Effect:** Gain +2 circumstance bonus to AC until the end of your next turn.

`Piercing`

# Severed Tendon

> **Crit Effect:** Until healed, the target is [[Clumsy 1]] and takes a [[Effect\_ -5-foot status penalty to your land Speed|-5-foot status penalty to land Speed]].

`Slashing`

# Power Surge

> Triple damage.

`Bomb or Spell`