---
title: "Critical Fumble Deck #49"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #49"
foundryId: JournalEntry.3ucRDpBBvfeWh0XE.JournalEntryPage.QeRwmIUgBtzxElzk
tags:
  - JournalEntryPage
---
# Pointy End goes There

> You become [[Wounded 1]] or your wounded value increases by 1.

`Melee`

# Tunnel Vision

> For 3 rounds, you gain a [[Effect\_ +1 circumstance bonus to attack rolls for 3 rounds|+1 circumstance bonus to attack rolls]], but you are [[Off-Guard]].

`Ranged`

# Head First!

> You fall [[Unconscious]] until you wake up or the end of your next turn.

`Unarmed`

# Wild Magic

> Roll twice on the [[Rod of Wonder]] table. You are the target of those effects.

`Spell`