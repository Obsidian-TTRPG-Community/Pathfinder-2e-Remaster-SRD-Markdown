---
title: "Critical Fumble Deck #37"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #37"
foundryId: JournalEntry.PH5sSid3w9gPhS6K.JournalEntryPage.26fg43UMXWHaV5Ee
tags:
  - JournalEntryPage
---
# Better to Give

> You hit yourself instead of the target.

`Melee`

# Weapon Problem

> If the attack used a projectile weapon, something on the weapon malfunctions, requiring you to spend 2 [[Interact]] actions to fix.

`Ranged`

# Sneeze

> You are [[Slowed 1]] until the end of your next turn.

`Unarmed`

# Spell Rush

> You are [[Stupefied 1]] until healed.

`Spell`