---
title: "Critical Hit Deck #9"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #9"
foundryId: JournalEntry.jVEdLg8tr3goa8x0.JournalEntryPage.aJziqJXJbAHFMnJi
tags:
  - JournalEntryPage
---
# Momentum

> You gain a [[Effect\_ +2 circumstance bonus to attack rolls|+2 circumstance bonus to attack rolls]] until the end of your next turn.

`Bludgeoning`

# Blowback

> The target is knocked [[Prone]].

`Piercing`

# Tangled

> **Crit Effect:** You can attempt to [[Grapple]] the target as a free action. This uses the same multiple attack penalty as your attack and doesn't count towards your multiple attack penalty.

`Slashing`

# Pretty Colors

> The target is [[Dazzled]] until the end of your next turn.

`Bomb or Spell`