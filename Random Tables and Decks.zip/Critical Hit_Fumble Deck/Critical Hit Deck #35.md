---
title: "Critical Hit Deck #35"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #35"
foundryId: JournalEntry.PTRq6MePAFbP4Jut.JournalEntryPage.uYcfVZMr3ykQgRXN
tags:
  - JournalEntryPage
---
# Thunder Strike

> **Crit Effect:** The target is [[Deafened]] until healed.

`Bludgeoning`

# Nailed in Place

> As the bow critical specialization effect. If this is a melee weapon, you must drop the weapon to gain this effect. If this attack already has that effect, the Athletics check to pull free is DC 20 instead of DC 10.

`Piercing`

# Decapitation

> Triple damage. **Crit Effect:** The target must succeed at a @Check\[type:fortitude\] or die.

`Slashing`

# Returning Spell

> If a spell attack, the spell or spell slot is not expended.

`Bomb or Spell`