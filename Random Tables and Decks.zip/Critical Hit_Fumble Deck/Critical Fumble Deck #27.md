---
title: "Critical Fumble Deck #27"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #27"
foundryId: JournalEntry.lfGNTSYWFTyBxUie.JournalEntryPage.bZJiyaGJWhgfmrqF
tags:
  - JournalEntryPage
---
# Pin Prick

> You take @Localize\[PF2E.PersistentDamage.Bleed1.success\].

`Melee`

# Spilled Ammo

> The ammunition from the weapon you're using falls from its container onto the ground. You can spend 1 [[Interact]] action to pick up one piece of ammunition spilled this way.

`Ranged`

# Just a Taste

> You hit an ally adjacent to you or the target.

`Unarmed`

# Tiring Spell

> You are [[Fatigued]].

`Spell`