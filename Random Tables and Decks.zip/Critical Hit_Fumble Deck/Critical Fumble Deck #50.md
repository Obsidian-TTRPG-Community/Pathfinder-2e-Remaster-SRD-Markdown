---
title: "Critical Fumble Deck #50"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #50"
foundryId: JournalEntry.yvIaChdFVZqoRSar.JournalEntryPage.0UfzLjrNTkWSDZKb
tags:
  - JournalEntryPage
---
# Broken Haft

> Your weapon's current Hit Points are reduced to its Broken Threshold. If already broken, the weapon takes [[/r 3d6]] damage, ignoring Hardness. If your weapon is a reach weapon, it loses reach.

`Melee`

# All Thumbs

> Until healed, you are [[Clumsy 1]].

`Ranged`

# Whiff

> You hit yourself istead of the target.

`Unarmed`

# Draining Magic

> You are [[Drained 1]].

`Spell`