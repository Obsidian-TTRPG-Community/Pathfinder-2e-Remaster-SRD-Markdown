---
title: "Critical Fumble Deck #20"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #20"
foundryId: JournalEntry.F1bw05pBeUJWEN56.JournalEntryPage.CRAeRs5IsNZ6UvY1
tags:
  - JournalEntryPage
---
# This sword is Heavy

> You are [[Fatigued]].

`Melee`

# Errant Aim

> Reroll the attack roll, targeting the creature closest to the target (excluding yourself).

`Ranged`

# Awkward Attack

> You are [[Effect\_ Off-Guard until end of your next turn|Effect: Off-Guard until end of your next turn]] .

`Unarmed`

# Bleeding Eyes

> You take [[/r 1d6\[bleed]]\].

`Spell`