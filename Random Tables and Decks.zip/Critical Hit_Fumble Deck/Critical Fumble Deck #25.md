---
title: "Critical Fumble Deck #25"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #25"
foundryId: JournalEntry.MXD7uTor6dpGxmas.JournalEntryPage.XX7shh3pqdG5v6Lm
tags:
  - JournalEntryPage
---
# Spinning Swing

> You are [[Sickened 1|Sickened 2]].

`Melee`

# Nicked

> You take @Localize\[PF2E.PersistentDamage.Bleed1.success\].

`Ranged`

# Twisted Up

> You are [[Encumbered]] until you spend 2 [[Interact]] actions to free yourself.

`Unarmed`

# Apprentice Move

> Reroll the attack roll, targeting the creature closest to the target (excluding yourself).

`Spell`