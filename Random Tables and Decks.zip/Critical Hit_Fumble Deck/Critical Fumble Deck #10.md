---
title: "Critical Fumble Deck #10"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #10"
foundryId: JournalEntry.IuroaOy0MD9HKDJE.JournalEntryPage.RwmPxeyYxpqhNpKj
tags:
  - JournalEntryPage
---
# Off Balance

> You take a [[Effect\_ -2 circumstance penalty to attack rolls|-2 circumstance penalty to attack rolls]] until the end of your next turn.

`Melee`

# Friendly Fire

> You hit the ally nearest to the target.

`Ranged`

# Something's Broken

> You take [[/r 1d4\[bludgeoning]]\] damage, and you can't use this attack until healed.

`Unarmed`

# Power Drain

> You loose one prepared spell or spell slot (determined randomly by the GM).

`Spell`