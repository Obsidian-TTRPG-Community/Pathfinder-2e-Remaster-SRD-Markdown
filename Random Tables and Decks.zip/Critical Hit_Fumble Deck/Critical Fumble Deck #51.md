---
title: "Critical Fumble Deck #51"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #51"
foundryId: JournalEntry.f9U8ZiCl4QG81tPO.JournalEntryPage.HJNQmrXcBXqxpU8d
tags:
  - JournalEntryPage
---
# Fog of War

> You are [[Effect\_ Dazzled until end of your next turn|Effect: Dazzled until end of your next turn]].

`Melee`

# Bull's Eye

> Your attack ricochets and hits you near the eye. You are [[Blinded]] until the end of your next turn.

`Ranged`

# Jam a Finger

> You the the target for the minimum amount of damage you can deal with the attack. You take the attack's normal damage.

`Unarmed`

# Everything to Fear

> You are [[Frightened 1|Frightened 3]].

`Spell`