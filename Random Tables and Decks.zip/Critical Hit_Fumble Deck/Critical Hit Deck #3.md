---
title: "Critical Hit Deck #3"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #3"
foundryId: JournalEntry.fHXUWjCYqyLJK2rb.JournalEntryPage.XW36TQZYvQ9S7T4v
tags:
  - JournalEntryPage
---
# Surprise Opening

> **Crit Effect:** You gain 1 action that you can use before the end of your turn to use an attack action against the target.

`Bludgeoning`

# Tongue Piercing

> The target must succeed at a @Check\[type:flat|dc:5\] to cast spells with the verbal component until healed.

`Piercing`

# Brow to Chin

> **Crit Effect:** The target takes a -2 status penalty to Perception and ranged attack rolls until healer.

`Slashing`

# Olfactory Overload

> The target loses its sense of smell and any scent ability or other olfactory sense until healed.

`Bomb or Spell`