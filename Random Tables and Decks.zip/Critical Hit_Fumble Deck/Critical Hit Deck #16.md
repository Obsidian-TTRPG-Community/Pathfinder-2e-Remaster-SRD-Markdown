---
title: "Critical Hit Deck #16"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #16"
foundryId: JournalEntry.ZpHUHj1zx1mZhdQp.JournalEntryPage.Lqeke3pTNSHcyAlS
tags:
  - JournalEntryPage
---
# Two for One

> **Crit Effect:** Deal normal damage to one target adjacent to the original target.

`Bludgeoning`

# Pinned Arm

> As the bow critical specialization effect, and the target can't use one of its arms until freed. If using a melee weapon, you must drop it to gain this effect.

`Piercing`

# Cut Straps

> **Crit Effect:** The target's armor check penalty doubles until the armor is Repaired (DC 15).

`Slashing`

# Electrocuted

> If this is a electricity spell or bomb, the target takes double damage, and at the start of its next turn, it takes normal damage. Any other bomb or spell deals double damage.

`Bomb or Spell`