---
title: "Critical Fumble Deck #8"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #8"
foundryId: JournalEntry.0RIrxSge27Qx8rh1.JournalEntryPage.pdKVSF828hMb0ruS
tags:
  - JournalEntryPage
---
# Who was That?

> You are [[Slowed 1]] until the end of your next turn.

`Melee`

# Seeing Double

> You are [[Dazzled]] until the end of your next turn.

`Ranged`

# Broken Tooth

> Until healed, you take a [[Effect\_ -2 circumstance penalty to attack rolls until healed|-2 circumstance penalty to attack rolls]].

`Unarmed`

# Fragmented Magic

> Your target gains the effect of a _[[Mirror Image]]_ spell.

`Spell`