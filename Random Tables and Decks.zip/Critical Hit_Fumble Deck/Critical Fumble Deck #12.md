---
title: "Critical Fumble Deck #12"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #12"
foundryId: JournalEntry.HgYMyAGNcIIGcK96.JournalEntryPage.GHS4SvuvWoDaWa0x
tags:
  - JournalEntryPage
---
# Second Thoughts

> You are [[Sickened 1|Sickened 3]]

`Melee`

# Mix it Up

> You can't make ranged attacks until the end of your next turn.

`Ranged`

# Hangnail

> If you attacked with a claw or fist, you can't use that attack until the end of your next turn.

`Unarmed`

# Magic Vacuum

> The effects of all beneficial spells affecting you end immediately.

`Spell`