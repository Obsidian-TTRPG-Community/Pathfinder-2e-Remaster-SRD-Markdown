---
title: "Critical Fumble Deck #33"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #33"
foundryId: JournalEntry.vLkuEbP9ACjCZ7WL.JournalEntryPage.qsF4BXJlET5zW5n6
tags:
  - JournalEntryPage
---
# Funny Bone

> You drop one item you are holding (determined randomly by the GM).

`Melee`

# Not my Pony!

> You hit the nearest animal companion, mount, or familiar.

`Ranged`

# Bad Headbutt

> You are [[Stunned 1]].

`Unarmed`

# Caster's Block

> You can't cast this spell again at any level until you rest and make your daily preparations.

`Spell`