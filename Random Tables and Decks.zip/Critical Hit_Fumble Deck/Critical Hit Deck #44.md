---
title: "Critical Hit Deck #44"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #44"
foundryId: JournalEntry.dOGRH6xQLhtPO8w5.JournalEntryPage.aAQ9VezKVsEVvSZP
tags:
  - JournalEntryPage
---
# Knockback

> **Crit Effect:** The target is pushed [[/r 1d4\*5#feet]] feet away.

`Bludgeoning`

# Deep Hurting

> **Crit Effect:** The target is [[Fatigued]].

`Piercing`

# Gut Slash

> The target takes [[/r 1d4\[bleed]]\] and any creature it Swallows Whole is immediately released.

`Slashing`

# Intense Splash

> The target takes normal damage, and all creatures adjacent to the target take half damage of the same type.

`Bomb or Spell`