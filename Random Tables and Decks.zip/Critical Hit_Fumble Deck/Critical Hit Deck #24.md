---
title: "Critical Hit Deck #24"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #24"
foundryId: JournalEntry.5flTSilNNaLbMmD8.JournalEntryPage.8Qpc1cbM8YliNeWt
tags:
  - JournalEntryPage
---
# Ruptured Spleen

> Normal damage. **Crit Effect:** The target takes @Localize\[PF2E.PersistentDamage.Bleed1.success\] that can't be removed until the target has been subject to magical healing.

`Bludgeoning`

# Muscle Severed

> Normal damage. **Crit Effect:** Until healed, the target is [[Clumsy 1|Clumsy 3]] and [[Enfeebled 1|Enfeebled 3]].

`Piercing`

# Lean into the Blow

> Triple damage. You drop your weapon.

`Slashing`

# Funny Bone

> The target laughs uncontrollably until the end of its next turn. While laughing, it is [[Slowed 1]] and can't use reactions.

`Bomb or Spell`