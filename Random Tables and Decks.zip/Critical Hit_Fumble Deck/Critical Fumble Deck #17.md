---
title: "Critical Fumble Deck #17"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #17"
foundryId: JournalEntry.qYyoBP0PuoSi2ZQJ.JournalEntryPage.vFjWSlbJ9kWr7dhQ
tags:
  - JournalEntryPage
---
# Pulled Muscle

> Until healed, you are [[Enfeebled 1|Enfeebled 2]].

`Melee`

# Awkward Attack

> You are [[Off-Guard]] until the end of your next turn.

`Ranged`

# Bit your Tongue!

> You take @Localize\[PF2E.PersistentDamage.Bleed1.success\].

`Unarmed`

# Spontaneous Combustion

> You take [[/r 2d6\[fire]]\] damage.

`Spell`