---
title: "Critical Fumble Deck #23"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #23"
foundryId: JournalEntry.3smlqx6c7LdudGmS.JournalEntryPage.Z6uHNA2pcuTdNc4L
tags:
  - JournalEntryPage
---
# Strained

> Until healed, you are [[Clumsy 1|Clumsy 2]].

`Melee`

# Whoops!

> You fall [[Prone]].

`Ranged`

# Out of Position

> You can't use this attack until the end of your next turn.

`Unarmed`

# Mind Drain

> Until healed, you are [[Stupefied 1]].

`Spell`