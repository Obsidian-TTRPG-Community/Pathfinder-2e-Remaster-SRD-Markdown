---
title: "Critical Fumble Deck #44"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #44"
foundryId: JournalEntry.rvRYebf4Ixu2x6FP.JournalEntryPage.dg5t9bt48deLA8IH
tags:
  - JournalEntryPage
---
# Hand it Over

> Unless you succeed at a @Check\[type:reflex\], your target gains possessions of your weapon.

`Melee`

# Broken

> Your weapon's current Hit Points are reduced to its Broken Threshold. If already [[Broken]], the weapon takes [[/r 3d6]] damage, ignoring Hardness.

`Ranged`

# Smash the Floor

> You kick up a cloud of dust, becoming [[Blinded]] until the end of your next turn.

`Unarmed`

# You made 'em Faster

> The target is [[Quickened]] for 2 rounds.

`Spell`