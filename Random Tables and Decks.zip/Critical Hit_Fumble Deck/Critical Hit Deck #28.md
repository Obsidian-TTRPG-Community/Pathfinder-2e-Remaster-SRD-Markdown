---
title: "Critical Hit Deck #28"
icon: ":sticky-note:"
aliases: "Critical Hit Deck #28"
foundryId: JournalEntry.WrXZyvpTuvzqty6A.JournalEntryPage.VWlXcYzq9XEBOA3u
tags:
  - JournalEntryPage
---
# Skull Crush

> **Crit Effect:** The target is [[Stupefied 1|Stupefied 3]] until healed.

`Bludgeoning`

# hand Wound

> **Crit Effect:** Until healed, the target is [[Clumsy 1|Clumsy 2]] and can't use one of its hands (determined randomly by the GM).

`Piercing`

# Broad Swipe

> The target takes [[/r 1d4\[bleed]]\].

`Slashing`

# Lingering Damage

> The target takes [[/r 1d6\[persistent]]\] damage of the same type as the bomb or spell's damage.

`Bomb or Spell`