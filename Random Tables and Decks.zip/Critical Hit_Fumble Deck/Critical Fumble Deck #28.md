---
title: "Critical Fumble Deck #28"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #28"
foundryId: JournalEntry.mdkx7nV7CNRJmSQS.JournalEntryPage.TQtz26fCkZNSwPf2
tags:
  - JournalEntryPage
---
# Armor Smash

> You deal the attack's normal damage to your armor, applying Hardness.

`Melee`

# Lost Grip

> You are [[Slowed 1|Slowed 2]] until the end of your next turn.

`Ranged`

# Battered

> Until healed, you take a [[Effect\_ -2 circumstance penalty to checks and saving throws until healed|-2 circumstance penalty to checks and saving throws]].

`Unarmed`

# Unexpected Blast

> Your spell affects all targets within 30 feet of you. You are immune to this effect.

`Spell`