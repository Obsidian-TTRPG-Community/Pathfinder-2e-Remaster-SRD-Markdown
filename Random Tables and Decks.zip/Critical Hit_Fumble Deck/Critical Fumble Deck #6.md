---
title: "Critical Fumble Deck #6"
icon: ":sticky-note:"
aliases: "Critical Fumble Deck #6"
foundryId: JournalEntry.NqKBmtB1beR1MqPS.JournalEntryPage.q3wbDpopfALf7tJr
tags:
  - JournalEntryPage
---
# Eat Dirt

> You fall [[Prone]] and are [[Blinded]] until the end of your next turn.

`Melee`

# Overcompensate

> Cover provides a [[Effect\_ +4 circumstance bonus to AC against your ranged attacks|+4 circumstance bonus to AC against your ranged attacks]] against your ranged attacks for 1 minute.

`Ranged`

# That tastes Awful!

> If this was a jaws attack (or similar), you are [[Sickened 1|Sickened 3]].

`Unarmed`

# Strange Transference

> Lose one prepared spell or spell slot, determined randomly by the GM. Your target can Cast this Spell on its next turn even if they can't cast spells, using your level, spell attack modifier, and spell DC.

`Spell`