---
title: "Press On"
icon: ":sticky-note:"
aliases: "Press On"
foundryId: JournalEntry.smosG1XqVdGpcVB7.JournalEntryPage.zcBCxlvPCpmjt5IS
tags:
  - JournalEntryPage
---
Play at the start of your turn.

* * *

Until the end of your turn, ignore penalties to checks and DCs from conditions.