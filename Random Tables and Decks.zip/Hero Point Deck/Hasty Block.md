---
title: "Hasty Block"
icon: ":sticky-note:"
aliases: "Hasty Block"
foundryId: JournalEntry.smosG1XqVdGpcVB7.JournalEntryPage.g5G4unm9tbEDu3pZ
tags:
  - JournalEntryPage
---
Play when you are hit by a physical attack, and you have a shield within reach and a free hand.

* * *

You Interact to draw and wield the shield and then use it to Shield Block against the attack. After the attack and block are resolved, the shield is torn from your grip and lands in an adjacent space.