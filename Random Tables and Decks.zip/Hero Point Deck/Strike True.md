---
title: "Strike True"
icon: ":sticky-note:"
aliases: "Strike True"
foundryId: JournalEntry.smosG1XqVdGpcVB7.JournalEntryPage.pS87Zh4QJnu0p8ES
tags:
  - JournalEntryPage
---
Play when you or an ally are about to make a Strike.

* * *

The target rolls twice and takes the higher result. This strike deals an extra die of damage on a hit if the attacker has fewer than half their maximum Hit Points, or two extra dice if they have fewer than one quarter their maximum Hit Points. This is a fortune effect.