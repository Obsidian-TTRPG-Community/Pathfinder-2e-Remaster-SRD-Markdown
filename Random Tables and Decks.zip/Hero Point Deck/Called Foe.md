---
title: "Called Foe"
icon: ":sticky-note:"
aliases: "Called Foe"
foundryId: JournalEntry.smosG1XqVdGpcVB7.JournalEntryPage.spzRl5CS4vnvcrm5
tags:
  - JournalEntryPage
---
Play before you make a Strike.

* * *

Designate a foe that you can see. You gain a +2 status bonus to attack rolls made against that foe, but you take a -4 status penalty to attack rolls made against any other creature. This lasts until the end of your next turn or until you critically hit the designated foe, whichever comes first.