---
title: "Hold the Line"
icon: ":sticky-note:"
aliases: "Hold the Line"
foundryId: JournalEntry.smosG1XqVdGpcVB7.JournalEntryPage.FgA086C40VR9mzNr
tags:
  - JournalEntryPage
---
Play during your turn.

* * *

Until the start of your next turn, each time an enemy would leave a space adjacent to you while using a move action, it must succeed at an Acrobatics or Athletics check against your Fortitude DC or the move action is disrupted.