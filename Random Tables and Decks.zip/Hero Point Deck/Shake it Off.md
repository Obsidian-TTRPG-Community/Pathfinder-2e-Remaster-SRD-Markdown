---
title: "Shake it Off"
icon: ":sticky-note:"
aliases: "Shake it Off"
foundryId: JournalEntry.smosG1XqVdGpcVB7.JournalEntryPage.Y20GMjqVbTvGZ87k
tags:
  - JournalEntryPage
---
Play at any time.

* * *

All persistent damage affecting you immediately comes to an end.