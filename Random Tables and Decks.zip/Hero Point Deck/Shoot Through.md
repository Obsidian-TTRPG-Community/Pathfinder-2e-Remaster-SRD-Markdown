---
title: "Shoot Through"
icon: ":sticky-note:"
aliases: "Shoot Through"
foundryId: JournalEntry.smosG1XqVdGpcVB7.JournalEntryPage.j6hsF2TWFtGMyClW
tags:
  - JournalEntryPage
---
Play when you are about to make your attack roll for a ranged Strike.

* * *

If the path of the Strike goes through another creature's space before reaching the target, the target is [[Off-Guard]] against the attack, and the other creature doesn't provide cover.