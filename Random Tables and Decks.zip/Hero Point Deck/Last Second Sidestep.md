---
title: "Last Second Sidestep"
icon: ":sticky-note:"
aliases: "Last Second Sidestep"
foundryId: JournalEntry.smosG1XqVdGpcVB7.JournalEntryPage.AeGcoQNaZ1BUmWvu
tags:
  - JournalEntryPage
---
Play when you are targeted by a ranged Strike.

* * *

The Strike automatically misses.