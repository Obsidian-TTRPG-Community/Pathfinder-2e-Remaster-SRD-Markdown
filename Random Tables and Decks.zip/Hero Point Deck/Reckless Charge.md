---
title: "Reckless Charge"
icon: ":sticky-note:"
aliases: "Reckless Charge"
foundryId: JournalEntry.smosG1XqVdGpcVB7.JournalEntryPage.E4aI0BTV9ATxfjGd
tags:
  - JournalEntryPage
---
Play after taking two consecutive Stride actions.

* * *

Make a melee Strike. You are [[Off-Guard]] until the start of your next turn.