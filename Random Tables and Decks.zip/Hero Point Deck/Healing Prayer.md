---
title: "Healing Prayer"
icon: ":sticky-note:"
aliases: "Healing Prayer"
foundryId: JournalEntry.smosG1XqVdGpcVB7.JournalEntryPage.Ttn2H0JHJVksChGi
tags:
  - JournalEntryPage
---
Play during your turn.

* * *

Select yourself or an ally within reach. The target regains [[/r (1d8+8)\[healing]]\]{1d8+8 Hit Points}. If you are 7th level or higher, the target regains [[/r (2d8+16)\[healing]]\]{2d8+16 Hit Points}. If you are 12th level or higher, the target regains [[/r (3d8+24)\[healing]]\]{3d8+24 Hit Points}.