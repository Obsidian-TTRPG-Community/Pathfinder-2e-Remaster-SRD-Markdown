---
title: "Tuck and Roll"
icon: ":sticky-note:"
aliases: "Tuck and Roll"
foundryId: JournalEntry.smosG1XqVdGpcVB7.JournalEntryPage.dCd0YXLVx0DQwitm
tags:
  - JournalEntryPage
---
Play after a creature or hazard hits you with a Strike.

* * *

You take the minimum amount of damage and fall [[Prone]].