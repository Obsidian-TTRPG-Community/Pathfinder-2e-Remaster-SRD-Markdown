---
title: "Last Ounce of Strength"
icon: ":sticky-note:"
aliases: "Last Ounce of Strength"
foundryId: JournalEntry.smosG1XqVdGpcVB7.JournalEntryPage.Fq1KEUyv0zBp5nMV
tags:
  - JournalEntryPage
---
Play at the start of a turn when you are dying.

* * *

You regain consciousness and can act normally on your turn, but you can't regain Hit Points or remove the dying condition during this turn. At the end of your turn, you fall [[Unconscious]] and your dying condition increases by 1. Do not attempt a recovery check this turn.