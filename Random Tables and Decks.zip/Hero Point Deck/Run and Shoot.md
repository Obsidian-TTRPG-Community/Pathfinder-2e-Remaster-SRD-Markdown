---
title: "Run and Shoot"
icon: ":sticky-note:"
aliases: "Run and Shoot"
foundryId: JournalEntry.smosG1XqVdGpcVB7.JournalEntryPage.zX28AGU1k5sO2Tpd
tags:
  - JournalEntryPage
---
Play when you take a Stride action.

* * *

You make a ranged Strike at any point during this movement.