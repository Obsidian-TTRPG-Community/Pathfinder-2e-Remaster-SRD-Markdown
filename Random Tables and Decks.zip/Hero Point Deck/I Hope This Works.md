---
title: "I Hope This Works"
icon: ":sticky-note:"
aliases: "I Hope This Works"
foundryId: JournalEntry.smosG1XqVdGpcVB7.JournalEntryPage.OnB94Y7wYE9j0ict
tags:
  - JournalEntryPage
---
Play at the start of your turn.

* * *

Once during your turn, you can Activate an item to [[Cast a Spell]], even if you can't normally cast spells or don't have that spell on your spell list. After casting this spell, your turn ends.