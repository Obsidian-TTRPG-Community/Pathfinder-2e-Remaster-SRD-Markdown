---
title: "Tumble Through"
icon: ":sticky-note:"
aliases: "Tumble Through"
foundryId: JournalEntry.smosG1XqVdGpcVB7.JournalEntryPage.Gu6CHAPMigpV9awj
tags:
  - JournalEntryPage
---
Play after you end your movement adjacent to a creature that is larger than you.

* * *

Move to the opposite side of that creature. This movement doesn't trigger any reactions based on movement.