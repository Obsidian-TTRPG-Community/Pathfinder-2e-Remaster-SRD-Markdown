---
title: "Distract Foe"
icon: ":sticky-note:"
aliases: "Distract Foe"
foundryId: JournalEntry.smosG1XqVdGpcVB7.JournalEntryPage.tUu3x2iHtOUqqWUc
tags:
  - JournalEntryPage
---
Play this when a foe within 30 feet makes a melee attack against another creature.

* * *

That foe is [[Fascinated]] with you and it can't end this condition until it takes a hostile action against you or the combat ends.