---
title: "Fluid Motion"
icon: ":sticky-note:"
aliases: "Fluid Motion"
foundryId: JournalEntry.smosG1XqVdGpcVB7.JournalEntryPage.D6hqfmZUksRvqNFR
tags:
  - JournalEntryPage
---
Play at the start of your turn.

* * *

For the rest of your turn, you gain a climb Speed and a swim Speed equal to half your Speed. If you make a horizontal [[Leap]], increase the distance jumped by 10 feet.