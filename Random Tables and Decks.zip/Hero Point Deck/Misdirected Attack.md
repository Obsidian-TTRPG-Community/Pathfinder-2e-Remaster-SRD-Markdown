---
title: "Misdirected Attack"
icon: ":sticky-note:"
aliases: "Misdirected Attack"
foundryId: JournalEntry.smosG1XqVdGpcVB7.JournalEntryPage.GqZLaGQDNe41saZ7
tags:
  - JournalEntryPage
---
Play after a foe critically fails on a melee Strike against you.

* * *

That foe rerolls the attack, targeting one of its allies within reach.