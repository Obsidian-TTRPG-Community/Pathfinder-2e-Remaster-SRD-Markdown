---
title: "Battle Cry"
icon: ":sticky-note:"
aliases: "Battle Cry"
foundryId: JournalEntry.smosG1XqVdGpcVB7.JournalEntryPage.8NHTJ8kK9qCzOVxp
tags:
  - JournalEntryPage
---
Play after making a successful melee attack.

* * *

You unleash a terrifying battle cry. Attempt an Intimidation check to [[Demoralize]] and compare the result against all enemies within 30 feet.