---
title: "Daring Attempt"
icon: ":sticky-note:"
aliases: "Daring Attempt"
foundryId: JournalEntry.smosG1XqVdGpcVB7.JournalEntryPage.jHn1m1r95YgMQSvM
tags:
  - JournalEntryPage
---
Play at the start of your turn.

* * *

Select one untrained skill. You are trained in that skill until the end of your next turn. If you use that skill before the end of your next turn and succeed at your skill check, you keep this benefit until the end of the combat, or for 1 minute if not in combat.