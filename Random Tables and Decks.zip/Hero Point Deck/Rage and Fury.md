---
title: "Rage and Fury"
icon: ":sticky-note:"
aliases: "Rage and Fury"
foundryId: JournalEntry.smosG1XqVdGpcVB7.JournalEntryPage.cQH9Syl1SQpbAi5A
tags:
  - JournalEntryPage
---
Play when an ally is knocked [[Unconscious]] or when you take damage from a critical hit.

* * *

At the start of your next turn, you enter a rage (+2 damage to melee strikes, -1 AC penalty, no concentrate actions unless they have the rage trait, or use the stats for your rage class feature if you have one). At the end of that turn, if you don't have the rage class feature, the rage ends and you are [[Fatigued]].