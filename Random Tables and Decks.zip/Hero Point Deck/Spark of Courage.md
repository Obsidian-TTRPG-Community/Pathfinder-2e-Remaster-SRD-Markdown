---
title: "Spark of Courage"
icon: ":sticky-note:"
aliases: "Spark of Courage"
foundryId: JournalEntry.smosG1XqVdGpcVB7.JournalEntryPage.EZZxz9jeEB0N3FPZ
tags:
  - JournalEntryPage
---
Play when you have the [[Frightened 1|Frightened]] condition.

* * *

You lose that condition and instead gain a +2 status bonus to attack rolls and skill checks until the end of your next turn.