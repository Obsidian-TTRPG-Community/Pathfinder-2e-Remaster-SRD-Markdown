---
title: "Opportune Distraction"
icon: ":sticky-note:"
aliases: "Opportune Distraction"
foundryId: JournalEntry.smosG1XqVdGpcVB7.JournalEntryPage.ksg8D5ssP6WGwGqi
tags:
  - JournalEntryPage
---
Play at the start of your turn.

* * *

Until the end of your turn, you gain the benefits of greater cover after taking the [[Hide]] or [[Sneak]] action, allowing you to Hide or Sneak in the open. This effect ends if you do anything other than Hide, Sneak, or Step.