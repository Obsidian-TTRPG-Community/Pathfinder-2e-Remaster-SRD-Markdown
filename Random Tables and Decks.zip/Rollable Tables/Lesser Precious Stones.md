---
title: "Lesser Precious Stones"
icon: ":list:"
aliases: "Lesser Precious Stones"
foundryId: RollTable.osOpyjBl2n9z8CPw
tags:
  - RollTable
---

# Lesser Precious Stones
Table of Lesser Precious Stones

| 1d100 | result |
|------|--------|
| 1-25 | [[Aquamarine]] |
| 26-50 | [[Opal]] |
| 51-75 | [[Pearl, black]] |
| 76-100 | [[Topaz]] |
