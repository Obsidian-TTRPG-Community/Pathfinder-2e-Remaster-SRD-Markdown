---
title: "Plains Dangers"
icon: ":list:"
aliases: "Plains Dangers"
foundryId: RollTable.zxlHXNph63QI7W1X
tags:
  - RollTable
---

# Plains Dangers
| 1d100 | result |
|------|--------|
| 1-8 | [[/r 1d8]] [[Crawling Hand\|Crawling Hands]] (Moderate 1) |
| 9-11 | [[/r 1d3+1]] [[Festrog\|Festrogs]] (Moderate 2) |
| 12-15 | 1 [[Shambler Troop]] (Moderate 2) |
| 16-19 | [[/r 1d3]] [[Assassin Vine\|Assassin Vines]] (Moderate 3) |
| 20-23 | [[/r 2d6]] [[Skeleton Guard\|Skeleton Guards]] (Moderate 3) |
| 24-27 | 1 [[Baobhan Sith]] (Moderate 4) |
| 28-32 | 1 [[Scythe Tree]] (Moderate 4) |
| 33-37 | [[/r 1d3]] [[Necromancer\|Necromancers]] (Moderate 5) |
| 38-42 | [[/r 2d4]] [[Zombie Brute\|Zombie Brutes]] (Moderate 5) |
| 43-47 | 1 [[Greater Shadow]] and 1 [[Shadow]] (Moderate 6) |
| 48-55 | [[/r 1d3]] [[Shambler\|Shamblers]] {Moderate 6} |
| 56-63 | 1 [[Dread Wraith]] {Moderate 7} |
| 64-71 | [[/r 1d3+1]] [[Gurgist Mauler\|Gurgist Maulers]] (Moderate 7) |
| 72-76 | 1 [[Clacking Skull Swarm]] (Moderate 8) |
| 77-81 | [[/r 1d3]] [[Bulette\|Bulettes]] (Moderate 8) |
| 82-86 | 1 [[Devourer]] (Moderate 9) |
| 87-91 | 3 [[Lifeleecher Brawler\|Lifeleecher Brawlers]] (Moderate 9) |
| 92-94 | [[/r 1d3]] [[Graveknight\|Graveknights]] (Moderate 10) |
| 95-97 | 1 [[Viper Vine]] (Moderate 11) |
| 98-100 | [[/r 1d4]] [[Skeleton Infantry]] (Moderate 12) |
