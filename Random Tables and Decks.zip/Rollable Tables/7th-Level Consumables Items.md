---
title: "7th-Level Consumables Items"
icon: ":list:"
aliases: "7th-Level Consumables Items"
foundryId: RollTable.Fp29vILhsGjTHIVM
tags:
  - RollTable
---

# 7th-Level Consumables Items
Table of 7th-Level Consumables Items

| 1d75 | result |
|------|--------|
| 1-6 | [[Spellstrike Ammunition (Type III)]] |
| 7-12 | [[Feather Token (Anchor)]] |
| 13-18 | [[Comprehension Elixir (Greater)]] |
| 19-24 | [[Leaper's Elixir (Greater)]] |
| 25-30 | [[Giant Wasp Venom]] |
| 31-36 | [[Malyass Root Paste]] |
| 37-42 | Roll 1d6<br>1 [[Black Dragon's Breath Potion (Young)]] <br>2 [[Brass Dragon's Breath Potion (Young)]] <br>3 [[Bronze Dragon's Breath Potion (Young)]] <br>4 [[Green Dragon's Breath Potion (Young)]] <br>5 [[Red Dragon's Breath Potion (Young)]] <br>6 [[Silver Dragon's Breath Potion (Young)]]  |
| 43-48 | [[Serum of Sex Shift]] |
| 49-54 | [[Scroll of 4th-rank Spell\|Scroll of 4th-level Spell]] |
| 55-60 | [[Grim Trophy]] |
| 61-66 | [[Murderer's Knot]] |
| 67-69 | [[Swift Block Cabochon]] |
| 70-75 | [[Smoke Ball (Greater)\|Smokestick (Greater)]] |
