---
title: "10th-Level Consumables Items"
icon: ":list:"
aliases: "10th-Level Consumables Items"
foundryId: RollTable.DvG6MEH5srE34TmF
tags:
  - RollTable
---

# 10th-Level Consumables Items
Table of 10th-Level Consumables Items

| 1d72 | result |
|------|--------|
| 1-6 | [[Elemental Gem]] |
| 7-12 | [[Antidote (Greater)]] |
| 13-18 | [[Antiplague (Greater)]] |
| 19-24 | [[Bravo's Brew (Moderate)]] |
| 25-30 | [[Eagle Eye Elixir (Greater)]] |
| 31-36 | [[Mistform Elixir (Greater)]] |
| 37-42 | [[Shadow Essence]] |
| 43-48 | [[Wolfsbane]] |
| 49-54 | [[Potion of Resistance (Moderate)]] |
| 55-60 | [[Iron Medallion]] |
| 61-66 | [[Mummified Bat]] |
| 67-72 | [[Vanishing Coin]] |
