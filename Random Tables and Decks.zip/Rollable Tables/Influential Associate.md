---
title: "Influential Associate"
icon: ":list:"
aliases: "Influential Associate"
foundryId: RollTable.5BvSNBK2Rdqo2hhI
tags:
  - RollTable
---

# Influential Associate
Table of Influential Associates

| 1d20 | result |
|------|--------|
| 1 | The Academic |
| 2 | The Boss |
| 3 | The Champion |
| 4 | The Confidante |
| 5 | The Crafter |
| 6 | The Criminal |
| 7 | The Dead One |
| 8 | The Fiend |
| 9 | The Fool |
| 10 | The Hunter |
| 11 | The Liege Lord |
| 12 | The Lover |
| 13 | The Mentor |
| 14 | The Mercenary |
| 15 | The Mystic |
| 16 | The Pariah |
| 17 | The Relative |
| 18 | The Seer |
| 19 | The Wanderer |
| 20 | The Well-Connected |
