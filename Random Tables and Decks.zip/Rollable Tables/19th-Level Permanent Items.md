---
title: "19th-Level Permanent Items"
icon: ":list:"
aliases: "19th-Level Permanent Items"
foundryId: RollTable.kriYbaxr2ru82UNd
tags:
  - RollTable
---

# 19th-Level Permanent Items
Table of 19th-Level Permanent Items

| 1d73 | result |
|------|--------|
| 1-3 | Adamantine Armor, High-Grade |
| 4-6 | Darkwood Armor, High-Grade |
| 7-9 | Dragonhide Armor, High Grade |
| 10-12 | Mithral Armor, High Grade |
| 13-15 | [[Crystal Ball (Obsidian)]] |
| 16-21 | [[Striking (Major)]] |
| 22-27 | [[Sturdy Shield (Supreme)]] |
| 28-33 | [[Magic Wand (9th-Rank Spell)\|Magic Wand (9th-Level Spell)]] |
| 34-39 | [[Wand of Continuation (8th-Rank Spell)\|Wand of Continuation (8th-Level Spell)]] |
| 40-45 | +3 major striking weapon |
| 46 | [[Luck Blade (Wishing)]] |
| 47-49 | [[Mattock of the Titans]] |
| 50-55 | +3 major striking Handwraps of Mighty Blows |
| 56-58 | [[Aeon Stone (Lavender and Green Ellipsoid)]] |
| 59-64 | [[Berserker's Cloak (Greater)]] |
| 65-67 | [[Robe of the Archmagi (Greater)]] |
| 68-73 | [[Third Eye]] |
