---
title: "6th-Level Permanent Items"
icon: ":list:"
aliases: "6th-Level Permanent Items"
foundryId: RollTable.QTlyk71SGMKCls7A
tags:
  - RollTable
---

# 6th-Level Permanent Items
Table of 6th-Level Permanent Items

| 1d135 | result |
|------|--------|
| 1-3 | [[Ghoul Hide]] |
| 4-6 | [[Chime of Opening]] |
| 7-12 | [[Cloud Pouch\|Horn of Fog]] |
| 13-18 | [[Primeval Mistletoe]] |
| 19-24 | [[Traveler's Any-Tool]] |
| 25-30 | [[Shifting]] |
| 31-36 | [[Lion's Shield]] |
| 37-42 | [[Spellguard Shield]] |
| 43-48 | [[Staff of Abjuration]] |
| 49-54 | [[Staff of Conjuration]] |
| 55-60 | [[Staff of Divination]] |
| 61-66 | [[Staff of Enchantment]] |
| 67-72 | [[Staff of Evocation]] |
| 73-78 | [[Staff of Illusion]] |
| 79-84 | [[Staff of Necromancy]] |
| 85-90 | [[Staff of Transmutation]] |
| 91-96 | [[Verdant Staff]] |
| 97-102 | [[Wand of Widening (2nd-Rank Spell)\|Wand of Widening (2nd-Level Spell)]] |
| 103-105 | [[Bloodletting Kukri]] |
| 106-111 | [[Twining Staff]] |
| 112-114 | [[Aeon Stone (Gold Nodule)]] |
| 115-120 | [[Choker of Elocution]] |
| 121-123 | [[Clandestine Cloak]] |
| 124-129 | [[Charm of Resistance\|Ring of Energy Resistance]] |
| 130-135 | [[Ring of the Ram]] |
