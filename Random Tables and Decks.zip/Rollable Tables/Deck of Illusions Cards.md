---
title: "Deck of Illusions Cards"
icon: ":list:"
aliases: "Deck of Illusions Cards"
foundryId: RollTable.vQhsbWeJT7tPPHOb
tags:
  - RollTable
---

# Deck of Illusions Cards
Potential illusions drawn randomly from the deck. The card is destroyed on use.

| 1d34 | result |
|------|--------|
| 1 | Iron Golem |
| 2 | Centaur |
| 3 | Greater Shadow |
| 4 | Earth Mephit |
| 5 | Hill Giant |
| 6 | Gelatinous Cube |
| 7 | Pixie |
| 8 | Arboreal Warden |
| 9 | Glabrezu (demon) |
| 10 | Chimera |
| 11 | Warg |
| 12 | Troll |
| 13 | Yeti |
| 14 | Harpy |
| 15 | Hydra |
| 16 | Sphinx |
| 17 | Red Dragon |
| 18 | Hyaenodon |
| 19 | Bugbear |
| 20 | Ettin |
| 21 | Cloud Giant |
| 22 | Giant Mantis |
| 23 | Mammoth |
| 24 | Tyrannosaurus |
| 25 | Lich |
| 26 | Dryad Queen |
| 27 | Giant Scorpion |
| 28 | Troll |
| 29 | Frost Giant |
| 30 | Boar |
| 31 | Medusa |
| 32 | Leaf Leshy |
| 33 | Deck Activator |
| 34 | Deck Activator's Greatest Fear |
