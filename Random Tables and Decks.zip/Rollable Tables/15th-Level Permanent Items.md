---
title: "15th-Level Permanent Items"
icon: ":list:"
aliases: "15th-Level Permanent Items"
foundryId: RollTable.Y91izsUCF6cNS1J9
tags:
  - RollTable
---

# 15th-Level Permanent Items
Table of 15th-Level Permanent Items

| 1d87 | result |
|------|--------|
| 1-3 | [[Plate Armor of the Deep]] |
| 4-6 | [[Crystal Ball (Selenite)]] |
| 7-9 | [[Wondrous Figurine (Obsidian Steed)]] |
| 10-12 | [[Antimagic]] |
| 13-18 | [[Corrosive (Greater)]] |
| 19-24 | [[Flaming (Greater)]] |
| 25-30 | [[Frost (Greater)]] |
| 31-36 | [[Shock (Greater)]] |
| 37-42 | [[Thundering (Greater)]] |
| 43-48 | [[Cold Iron Buckler (High-Grade)]] |
| 49-54 | [[Cold Iron Shield (High-Grade)]] |
| 55-60 | [[Silver Buckler (High-Grade)]] |
| 61-66 | [[Silver Shield (High-Grade)]] |
| 67-72 | [[Magic Wand (7th-Rank Spell)\|Magic Wand (7th-Level Spell)]] |
| 73-78 | [[Wand of Continuation (6th-Rank Spell)\|Wand of Continuation (6th-Level Spell)]] |
| 79-84 | [[Necklace of Fireballs VI]] |
| 85-87 | [[Robe of the Archmagi]] |
