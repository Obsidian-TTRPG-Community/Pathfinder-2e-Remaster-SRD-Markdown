---
title: "Forest Dangers"
icon: ":list:"
aliases: "Forest Dangers"
foundryId: RollTable.wZkaIeVraBG4jNaV
tags:
  - RollTable
---

# Forest Dangers
| 1d100 | result |
|------|--------|
| 1-3 | [[/r 1d4]] [[Grave Robber\|Grave Robbers]] (Moderate 1) |
| 4-7 | [[/r 2d4]] [[Zombie Shambler\|Zombie Shamblers]] (Moderate 1) |
| 8-10 | 1 [[Yellow Musk Creeper]] and [[/r 1d6]] [[Yellow Musk Thrall\|Thralls]] (Moderate 2) |
| 11-13 | [[/r 1d4]] [[Bandit\|Bandits]] (Moderate 2) |
| 14-18 | [[/r 1d3]] [[Assassin Vine\|Assassin Vines]] (Moderate 3) |
| 19-22 | [[/r 1d3]] [[Trailgaunt\|Trailgaunts]] (Moderate 3) |
| 23-26 | 1 [[Scythe Tree]] (Moderate 4) |
| 27-32 | [[/r 2d4]] [[Bandit\|Bandits]] (Moderate 4) |
| 33-38 | [[/r 2d4]] [[Shambler Troop\|Shambler Troops]] (Moderate 5) |
| 39-44 | [[/r 1d3]] [[Skeletal Hulk\|Skeletal Hulks]] (Moderate 5) |
| 45-50 | [[/r 1d4]] [[Sulfur Zombie\|Sulfur Zombies]] (Moderate 6) |
| 51-56 | [[/r 2d4]] [[Harpy Skeleton\|Harpy Skeletons]] (Moderate 6) |
| 57-62 | 1 [[Witchfire]] (Moderate 7) |
| 63-68 | 1 [[Zombie Dragon]] (Moderate 7) |
| 69-74 | [[/r 2d4]] [[Specter\|Specters]] (Moderate 8) |
| 75-80 | 1 [[Dezullon]] (Moderate 8) |
| 81-84 | [[/r 1d4]] [[Baykok\|Baykoks]] (Moderate 9) |
| 85-88 | [[/r 1d4]] [[Graveknight\|Graveknights]] (Moderate 9) |
| 89-92 | [[/r 1d4]] [[Giant Flytrap\|Giant Flytraps]] (Moderate 10) |
| 93-94 | 2 [[Skeleton Infantry\|Skeleton Infantries]] (Moderate 11) |
| 95-96 | [[/r 1d3]] [[Viper Vine\|Viper Vines]] (Moderate 12) |
| 97-98 | 1 [[Wemmuth]] (Moderate 13) |
| 99 | 1 [[Warsworn]] (Moderate 14) |
| 100 | 2 [[Zomok\|Zomoks]] (Moderate 15) |
