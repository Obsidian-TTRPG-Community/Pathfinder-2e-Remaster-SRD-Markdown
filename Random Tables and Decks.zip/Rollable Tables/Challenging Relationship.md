---
title: "Challenging Relationship"
icon: ":list:"
aliases: "Challenging Relationship"
foundryId: RollTable.YpIsaQUVHnMXoxrK
tags:
  - RollTable
---

# Challenging Relationship
Table of Inspiring Relationship

| 1d12 | result |
|------|--------|
| 1 | Accidental Fall |
| 2 | Accusation of Theft |
| 3 | Called Before Judges |
| 4 | Matter of Might |
| 5 | Mercantile Expertise |
| 6 | Privileged Position |
| 7 | Relationship Ender |
| 8 | Rival Trackers |
| 9 | Seeking Accolades |
| 10 | Slander |
| 11 | Social Maneuvering |
| 12 | Spy |
