---
title: "Minor Art Object"
icon: ":list:"
aliases: "Minor Art Object"
foundryId: RollTable.LocMu8OgdxfgU3lL
tags:
  - RollTable
---

# Minor Art Object
Table of Minor Art Objects

| 1d100 | result |
|------|--------|
| 1-5 | [[Elegant cloth doll]] |
| 6-10 | [[Scrimshaw whale bone]] |
| 11-15 | [[Illustrated book]] |
| 16-20 | [[Brass statuette of a bull]] |
| 21-25 | [[Carved wooden game set]] |
| 26-30 | [[Set of six ivory dice]] |
| 31-35 | [[Engraved copper ring]] |
| 36-40 | [[Lapis lazuli pendant]] |
| 41-45 | [[Hand mirror with decorated frame]] |
| 46-50 | [[Colorful velvet half mask]] |
| 51-55 | [[Set of decorated ceramic plates]] |
| 56-60 | [[Leather flagon with Caydenite symbol]] |
| 61-65 | [[Bronze bowl with wave imagery]] |
| 66-70 | [[Brass anklet]] |
| 71-75 | [[Iron cauldron with gargoyle faces]] |
| 76-80 | [[Religious Symbol (Silver)]] |
| 81-85 | [[Bronze brazier with Asmodean artwork]] |
| 86-90 | [[Plain brass censer]] |
| 91-95 | [[Simple sculpture]] |
| 96-100 | [[Simple painting]] |
