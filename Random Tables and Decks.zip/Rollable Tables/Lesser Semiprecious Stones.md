---
title: "Lesser Semiprecious Stones"
icon: ":list:"
aliases: "Lesser Semiprecious Stones"
foundryId: RollTable.hkzF5m76NVGgrBcO
tags:
  - RollTable
---

# Lesser Semiprecious Stones
Table of Lesser Semiprecious Stones

| 1d100 | result |
|------|--------|
| 1-7 | [[Agate]] |
| 8-14 | [[Alabaster]] |
| 15-21 | [[Azurite]] |
| 22-28 | [[Hematite]] |
| 29-35 | [[Lapis lazuli]] |
| 36-42 | [[Malachite]] |
| 43-49 | [[Obsidian]] |
| 50-56 | [[Pearl, irregular freshwater]] |
| 57-63 | [[Pyrite]] |
| 64-70 | [[Rhodochrosite]] |
| 71-77 | [[Quartz, rock crystal]] |
| 78-84 | [[Shell]] |
| 85-92 | [[Tiger's‑eye]] |
| 93-100 | [[Turquoise]] |
