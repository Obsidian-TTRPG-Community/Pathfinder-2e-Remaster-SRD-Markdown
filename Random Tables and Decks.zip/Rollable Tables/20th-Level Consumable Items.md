---
title: "20th-Level Consumable Items"
icon: ":list:"
aliases: "20th-Level Consumable Items"
foundryId: RollTable.IRjCJjbiM9t8Yr8l
tags:
  - RollTable
---

# 20th-Level Consumable Items
Table of 20th-Level Consumables Items

| 1d25 | result |
|------|--------|
| 1-3 | [[Elixir of Rejuvenation]] |
| 4 | [[Antimagic Oil]] |
| 5-10 | [[Tears of Death]] |
| 11-16 | [[Flying Blade Wheel Snare]] |
| 17-22 | [[Instant Evisceration Snare]] |
| 23-25 | [[Philosopher's Stone]] |
