---
title: "Random Encounter Type"
icon: ":list:"
aliases: "Random Encounter Type"
foundryId: RollTable.Kg0wcU1td13kdSUn
tags:
  - RollTable
---

# Random Encounter Type
Random Encounter Type Table

| 1d10 | result |
|------|--------|
| 1-5 | Harmless |
| 6-7 | Hazard |
| 8-10 | Creature |
