---
title: "7th-Level Permanent Items"
icon: ":list:"
aliases: "7th-Level Permanent Items"
foundryId: RollTable.ppIFukAiFFVnLW7I
tags:
  - RollTable
---

# 7th-Level Permanent Items
Table of 7th-Level Permanent Items

| 1d135 | result |
|------|--------|
| 1-6 | [[Moonlit Chain]] |
| 7-12 | [[Alacritous Horseshoes\|Horseshoes of Speed]] |
| 13-18 | [[Spacious Pouch (Type II)\|Bag of Holding (Type II)]] |
| 19-24 | [[Bottled Air]] |
| 25-30 | [[Decanter of Endless Water]] |
| 31-36 | [[Wondrous Figurine (Jade Serpent)]] |
| 37-42 | [[Wounding]] |
| 43-48 | [[Cold Iron Buckler (Standard-Grade)]] |
| 49-54 | [[Cold Iron Shield (Standard-Grade)]] |
| 55-60 | [[Silver Buckler (Standard-Grade)]] |
| 61-66 | [[Silver Shield (Standard-Grade)]] |
| 67-72 | [[Spined Shield]] |
| 73-78 | [[Sturdy Shield (Lesser)]] |
| 79-84 | [[Magic Wand (3rd-Rank Spell)\|Magic Wand (3rd-Level Spell)]] |
| 85-90 | [[Wand of Continuation (2nd-Rank Spell)\|Wand of Continuation (2nd-Level Spell)]] |
| 91-93 | [[Aeon Stone (Nourishing)\|Aeon Stone (Clear Spindle)]] |
| 94-96 | [[Aeon Stone (Delaying)\|Aeon Stone (Tourmaline Sphere)]] |
| 97-102 | [[Boots of Bounding]] |
| 103-108 | [[Cloak of Elvenkind]] |
| 109-111 | [[Retrieval Belt\|Gloves of Storing]] |
| 112-117 | [[Masquerade Scarf (Greater)\|Hat of Disguise (Greater)]] |
| 118-123 | [[Necklace of Fireballs II]] |
| 124-126 | [[Ring of Sustenance]] |
| 127-129 | [[Ring of Wizardry (Type I)]] |
| 130-135 | [[Slippers of Spider Climbing]] |
