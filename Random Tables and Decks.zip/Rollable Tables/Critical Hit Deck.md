---
title: "Critical Hit Deck"
icon: ":list:"
aliases: "Critical Hit Deck"
foundryId: RollTable.qbeLD7DsE6iXQ6ht
tags:
  - RollTable
---

# Critical Hit Deck
Table for Critical Hit Cards

| 1d53 | result |
|------|--------|
| 1 | [[Critical Hit Deck #1]] |
| 2 | [[Critical Hit Deck #2]] |
| 3 | [[Critical Hit Deck #3]] |
| 4 | [[Critical Hit Deck #4]] |
| 5 | [[Critical Hit Deck #5]] |
| 6 | [[Critical Hit Deck #6]] |
| 7 | [[Critical Hit Deck #7]] |
| 8 | [[Critical Hit Deck #8]] |
| 9 | [[Critical Hit Deck #9]] |
| 10 | [[Critical Hit Deck #10]] |
| 11 | [[Critical Hit Deck #11]] |
| 12 | [[Critical Hit Deck #12]] |
| 13 | [[Critical Hit Deck #13]] |
| 14 | [[Critical Hit Deck #14]] |
| 15 | [[Critical Hit Deck #15]] |
| 16 | [[Critical Hit Deck #16]] |
| 17 | [[Critical Hit Deck #17]] |
| 18 | [[Critical Hit Deck #18]] |
| 19 | [[Critical Hit Deck #19]] |
| 20 | [[Critical Hit Deck #20]] |
| 21 | [[Critical Hit Deck #21]] |
| 22 | [[Critical Hit Deck #22]] |
| 23 | [[Critical Hit Deck #23]] |
| 24 | [[Critical Hit Deck #24]] |
| 25 | [[Critical Hit Deck #25]] |
| 26 | [[Critical Hit Deck #26]] |
| 27 | [[Critical Hit Deck #27]] |
| 28 | [[Critical Hit Deck #28]] |
| 29 | [[Critical Hit Deck #29]] |
| 30 | [[Critical Hit Deck #30]] |
| 31 | [[Critical Hit Deck #31]] |
| 32 | [[Critical Hit Deck #32]] |
| 33 | [[Critical Hit Deck #33]] |
| 34 | [[Critical Hit Deck #34]] |
| 35 | [[Critical Hit Deck #35]] |
| 36 | [[Critical Hit Deck #36]] |
| 37 | [[Critical Hit Deck #37]] |
| 38 | [[Critical Hit Deck #38]] |
| 39 | [[Critical Hit Deck #39]] |
| 40 | [[Critical Hit Deck #40]] |
| 41 | [[Critical Hit Deck #41]] |
| 42 | [[Critical Hit Deck #42]] |
| 43 | [[Critical Hit Deck #43]] |
| 44 | [[Critical Hit Deck #44]] |
| 45 | [[Critical Hit Deck #45]] |
| 46 | [[Critical Hit Deck #46]] |
| 47 | [[Critical Hit Deck #47]] |
| 48 | [[Critical Hit Deck #48]] |
| 49 | [[Critical Hit Deck #49]] |
| 50 | [[Critical Hit Deck #50]] |
| 51 | [[Critical Hit Deck #51]] |
| 52 | [[Critical Hit Deck #52]] |
| 53 | [[Critical Hit Deck #53]] |
