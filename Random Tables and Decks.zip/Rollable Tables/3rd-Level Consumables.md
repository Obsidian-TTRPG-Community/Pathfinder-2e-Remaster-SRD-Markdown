---
title: "3rd-Level Consumables"
icon: ":list:"
aliases: "3rd-Level Consumables"
foundryId: RollTable.PkvULdGJbJLunWnV
tags:
  - RollTable
---

# 3rd-Level Consumables
Table of 3rd-Level Consumables

| 1d150 | result |
|------|--------|
| 1-6 | [[Beacon Shot]] |
| 7-12 | [[Sleep Arrow]] |
| 13-18 | [[Spellstrike Ammunition (Type I)]] |
| 19-24 | [[Vine Arrow]] |
| 25-30 | [[Acid Flask (Moderate)]] |
| 31-36 | [[Alchemist's Fire (Moderate)]] |
| 37-42 | [[Bottled Lightning (Moderate)]] |
| 43-48 | [[Frost Vial (Moderate)]] |
| 49-54 | [[Glue Bomb (Moderate)\|Tanglefoot Bag (Moderate)]] |
| 55-60 | [[Thunderstone (Moderate)]] |
| 61-66 | [[Feather Token (Bird)]] |
| 67-72 | [[Marvelous Miniature (Chest)\|Feather Token (Chest)]] |
| 73-78 | [[Bestial Mutagen (Moderate)]] |
| 79-84 | [[Cognitive Mutagen (Moderate)]] |
| 85-90 | [[Juggernaut Mutagen (Moderate)]] |
| 91-96 | [[Quicksilver Mutagen (Moderate)]] |
| 97-102 | [[Serene Mutagen (Moderate)]] |
| 103-108 | [[Silvertongue Mutagen (Moderate)]] |
| 109-114 | [[Oil of Mending]] |
| 115-120 | [[Cytillesh Oil]] |
| 121-126 | [[Graveroot]] |
| 127-132 | [[Healing Potion (Lesser)]] |
| 133-138 | [[Potion of Water Breathing]] |
| 139-144 | [[Scroll of 2nd-rank Spell\|Scroll of 2nd-level Spell]] |
| 145-150 | [[Feather Step Stone]] |
