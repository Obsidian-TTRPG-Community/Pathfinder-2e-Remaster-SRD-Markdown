---
title: "13th-Level Consumables Items"
icon: ":list:"
aliases: "13th-Level Consumables Items"
foundryId: RollTable.c4UcxxLcMTaGmRKo
tags:
  - RollTable
---

# 13th-Level Consumables Items
Table of 13th-Level Consumables Items

| 1d42 | result |
|------|--------|
| 1-6 | [[Explosive Ammunition (Greater)]] |
| 7-12 | [[Spellstrike Ammunition (Type VI)]] |
| 13-18 | [[Elixir of Life (Greater)]] |
| 19-24 | [[Deathcap Powder]] |
| 25-30 | [[Purple Worm Venom]] |
| 31-33 | [[Panacea]] |
| 34-39 | [[Scroll of 7th-rank Spell\|Scroll of 7th-level Spell]] |
| 40-42 | [[Mending Lattice]] |
