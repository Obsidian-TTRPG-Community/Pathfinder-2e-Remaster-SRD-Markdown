---
title: "16th-Level Consumables Items"
icon: ":list:"
aliases: "16th-Level Consumables Items"
foundryId: RollTable.JmSk4kE9heD8xQE8
tags:
  - RollTable
---

# 16th-Level Consumables Items
Table of 16th-Level Consumables Items

| 1d60 | result |
|------|--------|
| 1-6 | [[Eagle Eye Elixir (Major)]] |
| 7-12 | [[Salamander Elixir (Greater)]] |
| 13-18 | [[Winter Wolf Elixir (Greater)]] |
| 19-24 | [[Brimstone Fumes]] |
| 25-30 | [[Nightmare Vapor]] |
| 31-36 | [[Truesight Potion]] |
| 37-42 | [[Hail of Arrows Snare]] |
| 43-48 | [[Omnidirectional Spear Snare]] |
| 49-54 | [[Flame Navette]] |
| 55-60 | [[Ghost Dust]] |
