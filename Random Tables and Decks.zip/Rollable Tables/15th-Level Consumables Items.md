---
title: "15th-Level Consumables Items"
icon: ":list:"
aliases: "15th-Level Consumables Items"
foundryId: RollTable.KKWnhyFUH6aeUW3F
tags:
  - RollTable
---

# 15th-Level Consumables Items
Table of 15th-Level Consumables Items

| 1d63 | result |
|------|--------|
| 1-3 | [[Disintegration Bolt]] |
| 4-9 | [[Spellstrike Ammunition (Type VII)]] |
| 10-15 | [[Stone Bullet]] |
| 16-21 | [[Bravo's Brew (Greater)]] |
| 22-27 | [[Elixir of Life (Major)]] |
| 28-33 | [[Sea Touch Elixir (Greater)]] |
| 34-39 | [[Obfuscation Oil]] |
| 40-45 | [[Dragon Bile]] |
| 46-51 | [[Mindfog Mist]] |
| 52-57 | [[Potion of Flying (Greater)]] |
| 58-63 | [[Scroll of 8th-rank Spell\|Scroll of 8th-level Spell]] |
