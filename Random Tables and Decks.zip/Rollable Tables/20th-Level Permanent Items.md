---
title: "20th-Level Permanent Items"
icon: ":list:"
aliases: "20th-Level Permanent Items"
foundryId: RollTable.hMWKrJ2TLJrqZfoN
tags:
  - RollTable
---

# 20th-Level Permanent Items
Table of 20th-Level Permanent Items

| 1d44 | result |
|------|--------|
| 1-6 | +3 major resilient Armor |
| 7-9 | [[Elven Chain (High-Grade)]] |
| 10 | Orichalcum Armor (High-Grade) |
| 11-16 | [[Resilient (Major)]] |
| 17 | [[Staff of the Magi]] |
| 18-23 | [[Wand of Slaying (9th-Level Spell)]] |
| 24-29 | [[Wand of Smoldering Fireballs (9th-Level Spell)]] |
| 30-35 | [[Wand of Widening (9th-Rank Spell)\|Wand of Widening (9th-Level Spell)]] |
| 36 | [[Sky Hammer]] |
| 37-42 | [[Bands of Force (Major)\|Bracers of Armor III]] |
| 43 | [[Ring of Spell Turning]] |
| 44 | [[Whisper of the First Lie]] |
