---
title: "9th-Level Permanent Items"
icon: ":list:"
aliases: "9th-Level Permanent Items"
foundryId: RollTable.rTHonzhKVYHBz3x9
tags:
  - RollTable
---

# 9th-Level Permanent Items
Table of 9th-Level Permanent Items

| 1d162 | result |
|------|--------|
| 1-6 | [[Rhino Hide]] |
| 7-12 | [[Collar of Empathy]] |
| 13-18 | [[Horn of Blasting]] |
| 19-24 | [[Immovable Rod]] |
| 25-30 | [[Triton's Conch]] |
| 31-36 | [[Grievous]] |
| 37-42 | [[Shadow (Greater)]] |
| 43-45 | [[Dragonslayer's Shield]] |
| 46-48 | [[Force Shield]] |
| 49-54 | [[Magic Wand (4th-Rank Spell)\|Magic Wand (4th-Level Spell)]] |
| 55-60 | [[Wand of Continuation (3rd-Rank Spell)\|Wand of Continuation (3rd-Level Spell)]] |
| 61-66 | [[Wand of Shardstorm (3rd-Rank Spell)\|Wand of Manifold Missiles (3rd-Level Spell)]] |
| 67-72 | [[Gloom Blade]] |
| 73-78 | [[Armbands of Athleticism]] |
| 79-81 | [[Belt of the Five Kings]] |
| 82-87 | [[Bracers of Missile Deflection (Greater)]] |
| 88-93 | [[Coyote Cloak (Greater)]] |
| 94-99 | [[Dancing Scarf (Greater)]] |
| 100-105 | [[Eyes of the Cat\|Eyes of the Eagle]] |
| 106-111 | [[Mage's Hat (Greater)\|Hat of the Magi (Greater)]] |
| 112-117 | [[Healer's Gloves (Greater)]] |
| 118-120 | [[Knapsack of Halflingkind]] |
| 121-126 | [[Messenger's Ring]] |
| 127-132 | [[Necklace of Fireballs III]] |
| 133-138 | [[Pendant of the Occult (Greater)]] |
| 139-144 | [[Persona Mask (Greater)]] |
| 145-150 | [[Phylactery of Faithfulness]] |
| 151-156 | [[Tracker's Goggles (Greater)]] |
| 157-162 | [[Ventriloquist's Ring (Greater)]] |
