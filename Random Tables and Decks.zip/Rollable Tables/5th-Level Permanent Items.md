---
title: "5th-Level Permanent Items"
icon: ":list:"
aliases: "5th-Level Permanent Items"
foundryId: RollTable.PXpwfyboWSGNVID8
tags:
  - RollTable
---

# 5th-Level Permanent Items
Table of 5th-Level Permanent Items

| 1d105 | result |
|------|--------|
| 1-6 | Magic Armor (+1) |
| 7-12 | Cold Iron Armor (Low-Grade) |
| 13-18 | Silver Armor (Low-Grade) |
| 19-21 | [[Holy Prayer Beads]] |
| 22-27 | [[Skeleton Key]] |
| 28-33 | [[Armor Potency (+1)]] |
| 34-39 | [[Raiment\|Glamered]] |
| 40-45 | [[Vitalizing\|Disrupting]] |
| 46-51 | [[Pocket Stage]] |
| 52-57 | [[Magic Wand (2nd-Rank Spell)\|Magic Wand (2nd-Level Spell)]] |
| 58-63 | [[Wand of Continuation (1st-Rank Spell)\|Wand of Continuation (1st-Level Spell)]] |
| 64-69 | [[Wand of Shardstorm (1st-Rank Spell)\|Wand of Manifold Missiles (1st-Level Spell)]] |
| 70-75 | [[Caterwaul Sling]] |
| 76-81 | [[Serpent Dagger\|Dagger of Venom]] |
| 82-87 | [[Boots of Elvenkind]] |
| 88-93 | [[Diplomat's Badge]] |
| 94-99 | [[Obsidian Goggles]] |
| 100-105 | [[Necklace of Fireballs I]] |
