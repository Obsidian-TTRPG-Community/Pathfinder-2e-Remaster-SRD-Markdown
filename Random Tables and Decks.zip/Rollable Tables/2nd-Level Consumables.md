---
title: "2nd-Level Consumables"
icon: ":list:"
aliases: "2nd-Level Consumables"
foundryId: RollTable.ItsybLCwwGKMng0S
tags:
  - RollTable
---

# 2nd-Level Consumables
Table of 2nd-Level Consumables

| 1d123 | result |
|------|--------|
| 1-6 | [[Feather Token (Holly Bush)]] |
| 7-12 | [[Bravo's Brew (Lesser)]] |
| 13-18 | [[Cat's Eye Elixir]] |
| 19-24 | [[Comprehension Elixir (Lesser)]] |
| 25-30 | [[Darkvision Elixir (Lesser)]] |
| 31-36 | [[Infiltrator's Elixir]] |
| 37-42 | [[Belladonna]] |
| 43-48 | [[Black Adder Venom]] |
| 49-51 | [[Lethargy Poison]] |
| 52-57 | [[Bronze Bull Pendant]] |
| 58-63 | [[Crying Angel Pendant]] |
| 64-69 | [[Effervescent Ampoule]] |
| 70-75 | [[Hunter's Bane]] |
| 76-81 | [[Jade Cat]] |
| 82-87 | [[Mesmerizing Opal]] |
| 88-93 | [[Monkey Pin]] |
| 94-99 | [[Onyx Panther]] |
| 100-105 | [[Oil of Potency]] |
| 106-111 | [[Oil of Weightlessness]] |
| 112-117 | [[Savior Spike]] |
| 118-123 | [[Silver Salve]] |
