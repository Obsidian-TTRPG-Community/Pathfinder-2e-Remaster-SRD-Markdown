---
title: "Deities, Faiths and Philosophies"
icon: ":list:"
aliases: "Deities, Faiths and Philosophies"
foundryId: RollTable.Nl0N04S3DuefzjDK
tags:
  - RollTable
---

# Deities, Faiths and Philosophies
Table of Deities, Faiths and Philosophies

| 1d23 | result |
|------|--------|
| 1 | [[Abadar]] |
| 2 | [[Asmodeus]] |
| 3 | [[Calistria]] |
| 4 | [[Cayden Cailean]] |
| 5 | [[Desna]] |
| 6 | [[Erastil]] |
| 7 | [[Gorum]] |
| 8 | [[Gozreh]] |
| 9 | [[Iomedae]] |
| 10 | [[Irori]] |
| 11 | [[Lamashtu]] |
| 12 | [[Nethys]] |
| 13 | [[Norgorber]] |
| 14 | [[Pharasma]] |
| 15 | [[Rovagug]] |
| 16 | [[Sarenrae]] |
| 17 | [[Shelyn]] |
| 18 | [[Torag]] |
| 19 | [[Urgathoa]] |
| 20 | [[Zon-Kuthon]] |
| 21 | [[Green Faith]] |
| 22 | [[Prophecies of Kalistrade]] |
| 23 | [[Whispering Way]] |
