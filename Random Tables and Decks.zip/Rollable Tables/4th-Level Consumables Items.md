---
title: "4th-Level Consumables Items"
icon: ":list:"
aliases: "4th-Level Consumables Items"
foundryId: RollTable.cN2MuTbqhaaEMlbx
tags:
  - RollTable
---

# 4th-Level Consumables Items
Table of 4th-Level Consumables Items

| 1d111 | result |
|------|--------|
| 1-6 | [[Climbing Bolt]] |
| 7-12 | [[Viper Arrow]] |
| 13-18 | [[Feather Token (Fan)]] |
| 19-24 | [[Bomber's Eye Elixir (Lesser)]] |
| 25-30 | [[Darkvision Elixir (Moderate)]] |
| 31-36 | [[Mistform Elixir (Lesser)]] |
| 37-42 | [[Salamander Elixir (Lesser)]] |
| 43-48 | [[Stone Fist Elixir]] |
| 49-54 | [[Winter Wolf Elixir (Lesser)]] |
| 55-60 | [[Oak Potion\|Barkskin Potion]] |
| 61-63 | [[Invisibility Potion]] |
| 64-69 | [[Shrinking Potion]] |
| 70-75 | [[Biting Snare]] |
| 76-78 | [[Hobbling Snare]] |
| 79-81 | [[Stalker Bane Snare]] |
| 82-87 | [[Trip Snare]] |
| 88-93 | [[Warning Snare]] |
| 94-99 | [[Bloodseeker Beak]] |
| 100-105 | [[Dragon Turtle Scale]] |
| 106-111 | [[Fear Gem]] |
