---
title: "1st-Level Consumables"
icon: ":list:"
aliases: "1st-Level Consumables"
foundryId: RollTable.g2J5e8YPre2nSRvo
tags:
  - RollTable
---

# 1st-Level Consumables
Table of 1st-Level Consumables

| 1d246 | result |
|------|--------|
| 1-6 | [[Shining Ammunition]] |
| 7-12 | [[Acid Flask (Lesser)]] |
| 13-18 | [[Alchemist's Fire (Lesser)]] |
| 19-24 | [[Bottled Lightning (Lesser)]] |
| 25-30 | [[Frost Vial (Lesser)]] |
| 31-36 | [[Glue Bomb (Lesser)\|Tanglefoot Bag (Lesser)]] |
| 37-42 | [[Thunderstone (Lesser)]] |
| 43-48 | [[Marvelous Miniature (Ladder)\|Feather Token (Ladder)]] |
| 49-54 | [[Holy Water]] |
| 55-60 | [[Runestone]] |
| 61-66 | [[Unholy Water]] |
| 67-72 | [[Antidote (Lesser)]] |
| 73-78 | [[Antiplague (Lesser)]] |
| 79-84 | [[Bestial Mutagen (Lesser)]] |
| 85-90 | [[Cheetah's Elixir (Lesser)]] |
| 91-96 | [[Cognitive Mutagen (Lesser)]] |
| 97-102 | [[Eagle Eye Elixir (Lesser)]] |
| 103-108 | [[Elixir of Life (Minor)]] |
| 109-114 | [[Juggernaut Mutagen (Lesser)]] |
| 115-120 | [[Leaper's Elixir (Lesser)]] |
| 121-126 | [[Quicksilver Mutagen (Lesser)]] |
| 127-132 | [[Serene Mutagen (Lesser)]] |
| 133-138 | [[Silvertongue Mutagen (Lesser)]] |
| 139-144 | [[Nectar of Purification]] |
| 145-150 | [[Arsenic]] |
| 151-156 | [[Giant Centipede Venom]] |
| 157-162 | [[Healing Potion (Minor)]] |
| 163-168 | [[Scroll of 1st-rank Spell\|Scroll of 1st-level Spell]] |
| 169-174 | [[Alarm Snare]] |
| 175-180 | [[Caltrop Snare]] |
| 181-186 | [[Hampering Snare]] |
| 187-192 | [[Marking Snare]] |
| 193-198 | [[Signaling Snare]] |
| 199-204 | [[Spike Snare]] |
| 205-210 | [[Predator's Claw\|Owlbear Claw]] |
| 211-216 | [[Potency Crystal]] |
| 217-222 | [[Wolf Fang]] |
| 223-228 | [[Smoke Ball (Lesser)\|Smokestick (Lesser)]] |
| 229-234 | [[Snake Oil]] |
| 235-240 | [[Glow Rod\|Sunrod]] |
| 241-246 | [[Matchstick\|Tindertwig]] |
