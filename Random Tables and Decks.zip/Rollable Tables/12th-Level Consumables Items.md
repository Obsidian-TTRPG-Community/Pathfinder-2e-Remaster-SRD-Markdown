---
title: "12th-Level Consumables Items"
icon: ":list:"
aliases: "12th-Level Consumables Items"
foundryId: RollTable.CPWon7gGRXTK2Jnf
tags:
  - RollTable
---

# 12th-Level Consumables Items
Table of 12th-Level Consumables Items

| 1d90 | result |
|------|--------|
| 1-6 | [[Penetrating Ammunition]] |
| 7-12 | [[Salamander Elixir (Moderate)]] |
| 13-18 | [[Sea Touch Elixir (Moderate)]] |
| 19-24 | [[Winter Wolf Elixir (Moderate)]] |
| 25-27 | [[Oil of Animation]] |
| 28-33 | [[Salve of Antiparalysis (Greater)]] |
| 34-39 | [[Slumber Wine]] |
| 40-45 | Roll 1d6<br>1 [[Black Dragon's Breath Potion (Adult)]] <br>2 [[Brass Dragon's Breath Potion (Adult)]] <br>3 [[Bronze Dragon's Breath Potion (Adult)]] <br>4 [[Green Dragon's Breath Potion (Adult)]] <br>5 [[Red Dragon's Breath Potion (Adult)]] <br>6 [[Silver Dragon's Breath Potion (Adult)]] |
| 46-51 | [[Healing Potion (Greater)]] |
| 52-54 | [[Potion of True Speech\|Potion of Tongues]] |
| 55-60 | [[Bleeding Spines Snare]] |
| 61-66 | [[Scything Blade Snare]] |
| 67-72 | [[Stunning Snare]] |
| 73-78 | [[Eye of Apprehension]] |
| 79-84 | [[Fade Band]] |
| 85-90 | [[Iron Equalizer]] |
