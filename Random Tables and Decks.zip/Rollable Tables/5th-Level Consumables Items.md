---
title: "5th-Level Consumables Items"
icon: ":list:"
aliases: "5th-Level Consumables Items"
foundryId: RollTable.tFKz4tY90wobEn6S
tags:
  - RollTable
---

# 5th-Level Consumables Items
Table of 5th-Level Consumables Items

| 1d78 | result |
|------|--------|
| 1-6 | [[Spellstrike Ammunition (Type II)]] |
| 7-12 | [[Cheetah's Elixir (Moderate)]] |
| 13-18 | [[Eagle Eye Elixir (Moderate)]] |
| 19-24 | [[Elixir of Life (Lesser)]] |
| 25-30 | [[Sea Touch Elixir (Lesser)]] |
| 31-36 | [[Salve of Slipperiness]] |
| 37-42 | [[Spider Venom\|Hunting Spider Venom]] |
| 43-48 | [[Potion of Leaping]] |
| 49-54 | [[Scroll of 3rd-rank Spell\|Scroll of 3nd-level Spell]] |
| 55-60 | [[Emerald Grasshopper]] |
| 61-66 | [[Shark Tooth Charm]] |
| 67-72 | [[Sneaky Key]] |
| 73-78 | [[Tiger Menuki]] |
