---
title: "2nd-Level Permanent Items"
icon: ":list:"
aliases: "2nd-Level Permanent Items"
foundryId: RollTable.9IRG9QHRyA0g4PKL
tags:
  - RollTable
---

# 2nd-Level Permanent Items
Table of 2nd-Level Permanent Items

| 1d84 | result |
|------|--------|
| 1-6 | [[Full Plate]] |
| 7-12 | [[Wondrous Figurine (Onyx Dog)]] |
| 13-18 | [[Weapon Potency (+1)]] |
| 19-24 | [[Cold Iron Buckler (Low-Grade)]] |
| 25-30 | [[Cold Iron Shield (Low-Grade)]] |
| 31-36 | [[Silver Buckler (Low-Grade)]] |
| 37-42 | [[Silver Shield (Low-Grade)]] |
| 43-48 | Weapon (+1) |
| 49-54 | Cold iron weapon (low-grade) |
| 55-60 | Silver weapon (low-grade) |
| 61-66 | +1 Handwraps of Mighty Blows |
| 67-69 | [[Brooch of Shielding]] |
| 70-75 | [[Hand of the Mage]] |
| 76-81 | [[Masquerade Scarf\|Hat of Disguise]] |
| 82-84 | [[Wayfinder]] |
