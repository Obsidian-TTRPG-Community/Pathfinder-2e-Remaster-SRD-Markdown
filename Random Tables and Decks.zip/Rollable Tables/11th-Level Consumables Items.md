---
title: "11th-Level Consumables Items"
icon: ":list:"
aliases: "11th-Level Consumables Items"
foundryId: RollTable.kO8OLCeyLUF27r1p
tags:
  - RollTable
---

# 11th-Level Consumables Items
Table of 11th-Level Consumables Items

| 1d105 | result |
|------|--------|
| 1-6 | [[Spellstrike Ammunition (Type V)]] |
| 7-12 | [[Acid Flask (Greater)]] |
| 13-18 | [[Alchemist's Fire (Greater)]] |
| 19-24 | [[Bottled Lightning (Greater)]] |
| 25-30 | [[Frost Vial (Greater)]] |
| 31-36 | [[Glue Bomb (Greater)\|Tanglefoot Bag (Greater)]] |
| 37-42 | [[Thunderstone (Greater)]] |
| 43-48 | [[Bestial Mutagen (Greater)]] |
| 49-54 | [[Cognitive Mutagen (Greater)]] |
| 55-60 | [[Juggernaut Mutagen (Greater)]] |
| 61-66 | [[Quicksilver Mutagen (Greater)]] |
| 67-72 | [[Serene Mutagen (Greater)]] |
| 73-78 | [[Silvertongue Mutagen (Greater)]] |
| 79-81 | [[Oil of Keen Edges]] |
| 82-87 | [[Oil of Repulsion]] |
| 88-93 | [[Blightburn Resin]] |
| 94-99 | [[Potion of Swimming (Greater)]] |
| 100-105 | [[Scroll of 6th-rank Spell\|Scroll of 6th-level Spell]] |
