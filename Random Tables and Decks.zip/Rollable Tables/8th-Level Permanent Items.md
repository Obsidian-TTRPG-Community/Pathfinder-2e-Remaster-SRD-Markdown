---
title: "8th-Level Permanent Items"
icon: ":list:"
aliases: "8th-Level Permanent Items"
foundryId: RollTable.05g6sQOwslkfyxYQ
tags:
  - RollTable
---

# 8th-Level Permanent Items
Table of 8th-Level Permanent Items

| 1d169 | result |
|------|--------|
| 1-6 | Magic Armor (+1 Resilient) |
| 7-12 | [[Collar of Inconspicuousness]] |
| 13 | [[Rod of Wonder]] |
| 14-19 | [[Corrosive]] |
| 20-25 | [[Energy-Resistant]] |
| 26-31 | [[Flaming]] |
| 32-37 | [[Frost]] |
| 38-43 | [[Invisibility]] |
| 44-49 | [[Resilient]] |
| 50-55 | [[Shock]] |
| 56-61 | [[Slick (Greater)]] |
| 62-67 | [[Thundering]] |
| 68-73 | [[Adamantine Buckler (Standard-Grade)]] |
| 74-79 | [[Adamantine Shield (Standard-Grade)]] |
| 80-85 | [[Duskwood Buckler (Standard-Grade)\|Darkwood Buckler (Standard-Grade)]] |
| 86-91 | [[Duskwood Shield (Standard-Grade)\|Darkwood Shield (Standard-Grade)]] |
| 92-97 | [[Duskwood Tower Shield (Standard-Grade)\|Darkwood Tower Shield (Standard-Grade)]] |
| 98-103 | [[Dragonhide Buckler (Standard-Grade)]] |
| 104-109 | [[Dragonhide Shield (Standard-Grade)]] |
| 110-115 | [[Dawnsilver Buckler (Standard-Grade)\|Mithral Buckler (Standard-Grade)]] |
| 116-121 | [[Dawnsilver Shield (Standard-Grade)\|Mithral Shield (Standard-Grade)]] |
| 122-127 | [[Animal Staff (Greater)]] |
| 128-133 | [[Mentalist's Staff (Greater)]] |
| 134-139 | [[Staff of Fire (Greater)]] |
| 140-145 | [[Staff of Healing (Greater)]] |
| 146-151 | [[Staff of Illumination]] |
| 152-157 | [[Wand of Smoldering Fireballs (3rd-Level Spell)]] |
| 158-163 | [[Wand of Widening (3rd-Rank Spell)\|Wand of Widening (3rd-Level Spell)]] |
| 164-169 | [[Bands of Force\|Bracers of Armor I]] |
