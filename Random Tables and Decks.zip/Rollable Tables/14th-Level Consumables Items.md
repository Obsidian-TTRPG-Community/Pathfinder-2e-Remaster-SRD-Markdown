---
title: "14th-Level Consumables Items"
icon: ":list:"
aliases: "14th-Level Consumables Items"
foundryId: RollTable.Iz2GYFj70zVdG2uR
tags:
  - RollTable
---

# 14th-Level Consumables Items
Table of 14th-Level Consumables Items

| 1d48 | result |
|------|--------|
| 1-6 | [[Ghost Ammunition]] |
| 7-12 | [[Antidote (Major)]] |
| 13-18 | [[Antiplague (Major)]] |
| 19-24 | [[Bomber's Eye Elixir (Greater)]] |
| 25-30 | [[Potion of Resistance (Greater)]] |
| 31-36 | [[Dazing Coil]] |
| 37-42 | [[Iron Cudgel]] |
| 43-48 | [[Viper's Fang]] |
