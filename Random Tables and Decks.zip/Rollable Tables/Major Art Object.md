---
title: "Major Art Object"
icon: ":list:"
aliases: "Major Art Object"
foundryId: RollTable.kVPGyftjAJ2TNCAL
tags:
  - RollTable
---

# Major Art Object
Table of Major Art Objects

| 1d100 | result |
|------|--------|
| 1-5 | [[Jewel‑encrusted gold altar]] |
| 6-10 | [[Saint's bone with lost scriptures]] |
| 11-15 | [[Previously lost volume from a legendary author]] |
| 16-20 | [[Jeweled mithral crown]] |
| 21-25 | [[Platinum dragon statuette]] |
| 26-30 | [[Diamond ring with platinum band]] |
| 31-35 | [[Star sapphire necklace]] |
| 36-40 | [[Darkwood violin by a legend]] |
| 41-45 | [[Platinum image of a fey noble with a bit of orichalcum]] |
| 46-50 | [[Jeweled gold puzzle box]] |
| 51-55 | [[Crystallized dragon heart]] |
| 56-60 | [[Living flame shaped into a phoenix]] |
| 61-65 | [[Phasing ether silk tapestry]] |
| 66-70 | [[Solidified Moment of Time\|Solidified moment of time]] |
| 71-75 | [[Tankard owned by Cayden Cailean]] |
| 76-80 | [[Thought Lens of Astral Essence\|Thought lens of astral essence]] |
| 81-85 | [[Divine art piece created by Shelyn]] |
| 86-90 | [[Chandelier crafted from dreams]] |
| 91-95 | [[Enormous chryselephantine sculpture by a legend]] |
| 96-100 | [[Major Painting by a Legend\|Major painting by a legend]] |
