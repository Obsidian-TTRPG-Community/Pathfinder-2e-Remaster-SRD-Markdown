---
title: "6th-Level Consumables Items"
icon: ":list:"
aliases: "6th-Level Consumables Items"
foundryId: RollTable.iKztRm5vzvl32H74
tags:
  - RollTable
---

# 6th-Level Consumables Items
Table of 6th-Level Consumables Items

| 1d75 | result |
|------|--------|
| 1-6 | [[Dust of Appearance]] |
| 7-12 | [[Feather Token (Tree)]] |
| 13-18 | [[Antidote (Moderate)]] |
| 19-24 | [[Antiplague (Moderate)]] |
| 25-30 | [[Mistform Elixir (Moderate)]] |
| 31-36 | [[Oil of Weightlessness (Greater)]] |
| 37-42 | [[Salve of Antiparalysis]] |
| 43-48 | [[Giant Scorpion Venom]] |
| 49-54 | [[Healing Potion (Moderate)]] |
| 55-60 | [[Potion of Resistance (Lesser)]] |
| 61-66 | [[Potion of Swimming\|Potion of Swimming (Moderate)]] |
| 67-69 | [[Truth Potion]] |
| 70-75 | [[Iron Cube]] |
