---
title: "12th-Level Permanent Items"
icon: ":list:"
aliases: "12th-Level Permanent Items"
foundryId: RollTable.724EJzkJcToIzMUi
tags:
  - RollTable
---

# 12th-Level Permanent Items
Table of 12th-Level Permanent Items

| 1d126 | result |
|------|--------|
| 1-3 | Adamantine Armor, Standard-Grade |
| 4-6 | Darkwood Armor, Standard-Grade |
| 7-9 | Dragonhide Armor, Standard-Grade |
| 10-12 | Mithral Armor, Standard-Grade |
| 13-18 | [[Flying Broomstick\|Broom of Flying]] |
| 19-24 | [[Marvelous Medicines]] |
| 25-30 | [[Energy-Resistant (Greater)]] |
| 31-36 | [[Fortification]] |
| 37-42 | [[Striking (Greater)]] |
| 43-48 | [[Animal Staff (Major)]] |
| 49-54 | [[Mentalist's Staff (Major)]] |
| 55-60 | [[Staff of Fire (Major)]] |
| 61-66 | [[Staff of Healing (Major)]] |
| 67-72 | [[Verdant Staff (Greater)]] |
| 73-78 | [[Wand of Smoldering Fireballs (5th-Level Spell)]] |
| 79-84 | [[Wand of Widening (5th-Rank Spell)\|Wand of Widening (5th-Level Spell)]] |
| 85-90 | Magic Weapon (+2 Greater Striking) |
| 91-96 | +2 greater striking [[Handwraps of Mighty Blows]] |
| 97-99 | [[Aeon Stone (Pink Rhomboid)]] |
| 100-105 | [[Berserker's Cloak]] |
| 106-111 | [[Cloak of Elvenkind (Greater)]] |
| 112-117 | [[Ring of Climbing]] |
| 118-123 | [[Ring of Swimming]] |
| 124-126 | [[Ring of Wizardry (Type III)]] |
