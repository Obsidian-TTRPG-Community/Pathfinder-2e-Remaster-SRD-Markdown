---
title: "Homeland"
icon: ":list:"
aliases: "Homeland"
foundryId: RollTable.CMxoGhTr0hRDX4AP
tags:
  - RollTable
---

# Homeland
Table of Homeland
For a dwarf, subtract 3; For an elf, add 2; For a Goblin, subtract 4. For non CRB ancestries the GM determines the modifier.

| 1d20 | result |
|------|--------|
| -3-1 | Underground |
| 2-3 | Frontier |
| 4-5 | Trade Town |
| 6-7 | Simple Village |
| 8-9 | Cosmopolitan City |
| 10-11 | Metropolis |
| 12 | Front Lines |
| 13-14 | Itinerant |
| 15 | Another Ancestry's Settlement |
| 16 | Coastal Community |
| 17-18 | Religious Community |
| 19-22 | Academic Community |
