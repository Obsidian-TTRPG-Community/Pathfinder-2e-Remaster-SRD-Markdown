---
title: "18th-Level Permanent Items"
icon: ":list:"
aliases: "18th-Level Permanent Items"
foundryId: RollTable.8gOEuHzn3R7Zgd2E
tags:
  - RollTable
---

# 18th-Level Permanent Items
Table of 18th-Level Permanent Items

| 1d101 | result |
|------|--------|
| 1-6 | Magic Armor (+3 Greater Resilient) |
| 7-12 | [[Breastplate of Command (Greater)]] |
| 13-18 | Cold Iron Armor (High-Grade) |
| 19-24 | Silver Armor (High-Grade) |
| 25-30 | [[Maestro's Instrument (Greater)]] |
| 31-36 | [[Marvelous Medicines (Greater)]] |
| 37-42 | [[Possibility Tome]] |
| 43-48 | [[Thurible of Revelation (Greater)]] |
| 49-54 | [[Armor Potency (+3)]] |
| 55-60 | [[Fortification (Greater)]] |
| 61 | [[Indestructible Shield]] |
| 62-64 | [[Reflecting Shield]] |
| 65-70 | [[Wand of Slaying (8th-Level Spell)]] |
| 71-76 | [[Wand of Widening (8th-Rank Spell)\|Wand of Widening (8th-Level Spell)]] |
| 77 | Orichalcum Weapon, High-Grade |
| 78-83 | [[Storm Flash (Greater)]] |
| 84-89 | [[Obsidian Goggles (Major)]] |
| 90-95 | [[Inexplicable Apparatus]] |
| 96-101 | [[Ring of Maniacal Devices (Greater)\|Ring of Manical Devices (Greater)]] |
