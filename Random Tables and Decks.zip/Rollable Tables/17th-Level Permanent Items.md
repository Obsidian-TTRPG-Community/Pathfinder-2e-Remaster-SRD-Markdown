---
title: "17th-Level Permanent Items"
icon: ":list:"
aliases: "17th-Level Permanent Items"
foundryId: RollTable.2BGFwkWCbUD0Vh1L
tags:
  - RollTable
---

# 17th-Level Permanent Items
Table of 17th-Level Permanent Items

| 1d36 | result |
|------|--------|
| 1 | [[Anklets of Alacrity]] |
| 2 | [[Belt of Giant Strength]] |
| 3 | [[Belt of Long Life\|Belt of Regeneration]] |
| 4 | [[Circlet of Persuasion]] |
| 5 | [[Crown of Intellect\|Diadem of Intellect]] |
| 6 | [[Headwrap of Wisdom\|Headband of Inspired Wisdom]] |
| 7 | [[Impenetrable Scale]] |
| 8 | [[Crystal Ball (Peridot)]] |
| 10 | [[Ethereal]] |
| 11 | [[Shadow (Major)]] |
| 12 | [[Vorpal]] |
| 13 | [[Orichalcum Shield (High-Grade)]] |
| 14 | [[Orichalcum Buckler (High-Grade)]] |
| 15 | [[Magic Wand (8th-Rank Spell)\|Magic Wand (8th-Level Spell)]] |
| 16 | [[Wand of Continuation (7th-Rank Spell)\|Wand of Continuation (7th-Level Spell)]] |
| 17 | [[Wand of Shardstorm (7th-Rank Spell)\|Wand of Manifold Missiles (7th-Level Spell)]] |
| 18 | Adamantine Weapon (High-Grade) |
| 19 | Darkwood Weapon (High-Grade) |
| 20 | [[Searing Blade (Greater)\|Flame Tongue (Greater)]] |
| 21 | [[Luck Blade]] |
| 22 | Mithral Weapon (High-Grade) |
| 24 | [[Alchemist Goggles (Major)]] |
| 25 | [[Armbands of Athleticism (Greater)]] |
| 27 | [[Cloak of the Bat (Greater)]] |
| 28 | [[Daredevil Boots (Greater)]] |
| 29 | [[Dread Blindfold]] |
| 30 | [[Messenger's Ring (Greater)]] |
| 31 | [[Necklace of Fireballs VII]] |
| 32 | [[Phylactery of Faithfulness (Greater)]] |
| 34 | [[Robe of Eyes]] |
| 36 | [[Voyager's Pack]] |
