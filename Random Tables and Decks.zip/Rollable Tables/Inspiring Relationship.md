---
title: "Inspiring Relationship"
icon: ":list:"
aliases: "Inspiring Relationship"
foundryId: RollTable.Wla1xJZxbkrl8zKF
tags:
  - RollTable
---

# Inspiring Relationship
Table of Inspiring Relationship

| 1d12 | result |
|------|--------|
| 1 | Animal Helpers |
| 2 | Comrade-in-Arms |
| 3 | Desperate Intimidation |
| 4 | Homelessness |
| 5 | Kindly Witch |
| 6 | Liberators |
| 7 | Magician |
| 8 | Missing Child |
| 9 | Patron of the Arts |
| 10 | Religious Students |
| 11 | Timely Cure |
| 12 | Wasteland Survivors |
