---
title: "10th-Level Permanent Items"
icon: ":list:"
aliases: "10th-Level Permanent Items"
foundryId: RollTable.pVv1D9cMRomg9VnT
tags:
  - RollTable
---

# 10th-Level Permanent Items
Table of 10th-Level Permanent Items

| 1d198 | result |
|------|--------|
| 1-6 | [[Breastplate of Command]] |
| 7-12 | [[Electric Eelskin]] |
| 13-18 | [[Barding of the Zephyr]] |
| 19-24 | [[Maestro's Instrument (Moderate)]] |
| 25-30 | [[Thurible of Revelation (Moderate)]] |
| 31-36 | [[Wondrous Figurine (Golden Lions)]] |
| 37-42 | [[Weapon Potency (+2)]] |
| 43-48 | [[Invisibility (Greater)]] |
| 49-51 | [[Forge Warden]] |
| 52-57 | [[Sturdy Shield (Moderate)]] |
| 58-63 | [[Staff of Abjuration (Greater)]] |
| 64-69 | [[Staff of Conjuration (Greater)]] |
| 70-75 | [[Staff of Divination (Greater)]] |
| 76-81 | [[Staff of Enchantment (Greater)]] |
| 82-87 | [[Staff of Evocation (Greater)]] |
| 88-93 | [[Staff of Illusion (Greater)]] |
| 94-99 | [[Staff of Necromancy (Greater)]] |
| 100-105 | [[Staff of Transmutation (Greater)]] |
| 106-111 | [[Explorer's Yurt]] |
| 112-117 | [[Wand of Widening (4th-Rank Spell)\|Wand of Widening (4th-Level Spell)]] |
| 118-123 | Magic Weapon (+2 Striking) |
| 124-129 | Cold Iron Weapon (Standard-Grade) |
| 130-135 | Silver Weapon (Standard-Grade) |
| 136-141 | +2 striking [[Handwraps of Mighty Blows]] |
| 142-144 | [[Charlatan's Cape\|Cape of the Mountebank]] |
| 145-150 | [[Choker of Elocution (Greater)]] |
| 151-153 | [[Clandestine Cloak (Greater)]] |
| 154-159 | [[Cloak of the Bat]] |
| 160-165 | [[Daredevil Boots]] |
| 166-171 | [[Demon Mask (Greater)]] |
| 172-177 | [[Living Mantle\|Druid's Vestments]] |
| 178-180 | [[Ring of Counterspells]] |
| 181-186 | [[Charm of Resistance (Greater)\|Ring of Energy Resistance (Greater)]] |
| 187-189 | [[Ring of Lies]] |
| 190-192 | [[Ring of Wizardry (Type II)]] |
| 193-198 | [[Winged Sandals\|Winged Boots]] |
