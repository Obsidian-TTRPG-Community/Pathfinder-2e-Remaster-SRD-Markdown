---
title: "16th-Level Permanent Items"
icon: ":list:"
aliases: "16th-Level Permanent Items"
foundryId: RollTable.we5gWIrW0Mz0AdA9
tags:
  - RollTable
---

# 16th-Level Permanent Items
Table of 16th-Level Permanent Items

| 1d119 | result |
|------|--------|
| 1-3 | [[Dragonplate]] |
| 4-6 | [[Crystal Ball (Moonstone)]] |
| 7-12 | [[Weapon Potency (+3)]] |
| 13-18 | [[Slick (Major)]] |
| 19 | [[Quickstrike\|Speed]] |
| 20-22 | [[Adamantine Buckler (High-Grade)]] |
| 23-25 | [[Adamantine Shield (High-Grade)]] |
| 26-28 | [[Duskwood Buckler (High-Grade)\|Darkwood Buckler (High-Grade)]] |
| 29-31 | [[Duskwood Shield (High-Grade)\|Darkwood Shield (High-Grade)]] |
| 32-34 | [[Duskwood Tower Shield (High-Grade)\|Darkwood Tower Shield (High-Grade)]] |
| 35-37 | [[Dragonhide Buckler (High-Grade)]] |
| 38-40 | [[Dragonhide Shield (High-Grade)]] |
| 41-46 | [[Floating Shield (Greater)]] |
| 47-49 | [[Dawnsilver Buckler (High-Grade)\|Mithral Buckler (High-Grade)]] |
| 50-52 | [[Dawnsilver Shield (High-Grade)\|Mithral Shield (High-Grade)]] |
| 53-58 | [[Sturdy Shield (Major)]] |
| 59-64 | [[Staff of Healing (True)]] |
| 65 | [[Staff of Power]] |
| 66-68 | [[Instant Fortress]] |
| 69-74 | [[Wand of Slaying (7th-Level Spell)]] |
| 75-80 | [[Wand of Smoldering Fireballs (7th-Level Spell)]] |
| 81-86 | [[Wand of Widening (7th-Rank Spell)\|Wand of Widening (7th-Level Spell)]] |
| 87-92 | +3 greater striking weapon |
| 93-98 | Cold Iron Weapon (High-Grade) |
| 99-104 | [[Frost Brand]] |
| 105-110 | Silver Weapon (High-Grade) |
| 111-116 | +3 greater striking [[Handwraps of Mighty Blows]] |
| 117-119 | [[Aeon Stone (Amplifying)\|Aeon Stone (Orange Prism)]] |
