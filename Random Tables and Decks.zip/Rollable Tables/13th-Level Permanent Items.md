---
title: "13th-Level Permanent Items"
icon: ":list:"
aliases: "13th-Level Permanent Items"
foundryId: RollTable.Z2VBTF3a63QrEsUr
tags:
  - RollTable
---

# 13th-Level Permanent Items
Table of 13th-Level Permanent Items

| 1d108 | result |
|------|--------|
| 1-6 | [[Celestial Armor]] |
| 7-12 | [[Demon Armor]] |
| 13-15 | [[Elven Chain (Standard-Grade)]] |
| 16-21 | [[Mail of Luck]] |
| 22-27 | [[Spacious Pouch (Type IV)\|Bag of Holding (Type IV)]] |
| 28-33 | [[Wondrous Figurine (Marble Elephant)]] |
| 34-36 | [[Animated\|Dancing]] |
| 37-39 | [[Keen]] |
| 40-42 | [[Spell Reservoir\|Spell-Storing]] |
| 43-48 | [[Sturdy Shield (Greater)]] |
| 49-54 | [[Magic Wand (6th-Rank Spell)\|Magic Wand (6th-Level Spell)]] |
| 55-60 | [[Wand of Continuation (5th-Rank Spell)\|Wand of Continuation (5th-Level Spell)]] |
| 61-66 | [[Wand of Shardstorm (5th-Rank Spell)\|Wand of Manifold Missiles (5th-Level Spell)]] |
| 67-72 | [[Dwarven Thrower]] |
| 73-78 | [[Searing Blade\|Flame Tongue]] |
| 79-81 | [[Aeon Stone (Pale Lavender Ellipsoid)]] |
| 82-87 | [[Propulsive Boots\|Boots of Speed]] |
| 88-93 | [[Eye of Fortune]] |
| 94-96 | [[Knapsack of Halflingkind (Greater)]] |
| 97-102 | [[Necklace of Fireballs V]] |
| 103-108 | [[Ring of the Ram (Greater)]] |
