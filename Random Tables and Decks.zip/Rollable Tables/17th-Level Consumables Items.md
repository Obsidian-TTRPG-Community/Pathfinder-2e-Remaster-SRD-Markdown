---
title: "17th-Level Consumables Items"
icon: ":list:"
aliases: "17th-Level Consumables Items"
foundryId: RollTable.SrNs3I4DLXiYdHbW
tags:
  - RollTable
---

# 17th-Level Consumables Items
Table of 17th-Level Consumables Items

| 1d102 | result |
|------|--------|
| 1-6 | [[Spellstrike Ammunition (Type VIII)]] |
| 7-12 | [[Acid Flask (Major)]] |
| 13-18 | [[Alchemist's Fire (Major)]] |
| 19-24 | [[Bottled Lightning (Major)]] |
| 25-30 | [[Frost Vial (Major)]] |
| 31-36 | [[Glue Bomb (Major)\|Tanglefoot Bag (Major)]] |
| 37-42 | [[Thunderstone (Major)]] |
| 43-48 | [[Bestial Mutagen (Major)]] |
| 49-54 | [[Cognitive Mutagen (Major)]] |
| 55-60 | [[Juggernaut Mutagen (Major)]] |
| 61-66 | [[Quicksilver Mutagen (Major)]] |
| 67-72 | [[Serene Mutagen (Major)]] |
| 73-78 | [[Silvertongue Mutagen (Major)]] |
| 79-84 | [[Hemlock]] |
| 85-90 | Roll 1d6<br>1 [[Black Dragon's Breath Potion (Wyrm)]] <br>2 [[Brass Dragon's Breath Potion (Wyrm)]] <br>3 [[Bronze Dragon's Breath Potion (Wyrm)]] <br>4 [[Green Dragon's Breath Potion (Wyrm)]] <br>5 [[Red Dragon's Breath Potion (Wyrm)]] <br>6 [[Silver Dragon's Breath Potion (Wyrm)]] |
| 91-96 | [[Scroll of 9th-rank Spell\|Scroll of 9th-level Spell]] |
| 97-102 | [[Dispelling Sliver]] |
