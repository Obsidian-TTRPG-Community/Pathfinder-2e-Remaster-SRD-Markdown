---
title: "19th-Level Consumables Items"
icon: ":list:"
aliases: "19th-Level Consumables Items"
foundryId: RollTable.jT6i6sdrz3f87dJI
tags:
  - RollTable
---

# 19th-Level Consumables Items
Table of 19th-Level Consumables Items

| 1d21 | result |
|------|--------|
| 1-6 | [[Spellstrike Ammunition (Type IX)]] |
| 7-12 | [[Elixir of Life (True)]] |
| 13-18 | [[Black Lotus Extract]] |
| 19-21 | [[Scroll of 10th-rank Spell\|Scroll of 10th-level Spell]] |
