---
title: "Moderate Precious Stones"
icon: ":list:"
aliases: "Moderate Precious Stones"
foundryId: RollTable.BzjBCewGGVE9Aq5j
tags:
  - RollTable
---

# Moderate Precious Stones
Table of Moderate Precious Stones

| 1d100 | result |
|------|--------|
| 1-25 | [[Diamond, small]] |
| 26-50 | [[Emerald]] |
| 51-75 | [[Ruby, small]] |
| 76-100 | [[Sapphire]] |
