---
title: "8th-Level Consumables Items"
icon: ":list:"
aliases: "8th-Level Consumables Items"
foundryId: RollTable.mvEFjSLvVFAxKTzK
tags:
  - RollTable
---

# 8th-Level Consumables Items
Table of 8th-Level Consumables Items

| 1d72 | result |
|------|--------|
| 1-3 | [[Candle of Truth]] |
| 4-9 | [[Marvelous Miniature (Boat)\|Feather Token (Swan Boat)]] |
| 10-15 | [[Darkvision Elixir (Greater)]] |
| 16-21 | [[Nettleweed Residue]] |
| 22-27 | [[Wyvern Poison]] |
| 28-33 | [[Potion of Flying (Standard)]] |
| 34-39 | [[Potion of Quickness]] |
| 40-45 | [[Shrinking Potion (Greater)]] |
| 46-51 | [[Bomb Snare]] |
| 52-54 | [[Grasping Snare]] |
| 55-60 | [[Striking Snare]] |
| 61-66 | [[Gallows Tooth]] |
| 67-72 | [[Jade Bauble]] |
