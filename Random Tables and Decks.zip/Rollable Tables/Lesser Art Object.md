---
title: "Lesser Art Object"
icon: ":list:"
aliases: "Lesser Art Object"
foundryId: RollTable.Hro4rc7cP70oOZms
tags:
  - RollTable
---

# Lesser Art Object
Table of Lesser Art Objects

| 1d100 | result |
|------|--------|
| 1-5 | [[Silk ceremonial armor]] |
| 6-10 | [[Inscribed crocodile skull]] |
| 11-15 | [[Illuminated manuscript]] |
| 16-20 | [[Simple silver circlet]] |
| 21-25 | [[Copper statuette of a salamander]] |
| 26-30 | [[Alabaster and obsidian game set]] |
| 31-35 | [[Silk fan decorated with turquoise]] |
| 36-40 | [[Ceremonial dagger with onyx hilt]] |
| 41-45 | [[Amphora with lavish scenes]] |
| 46-50 | [[Colorful pastoral tapestry]] |
| 51-55 | [[Chrysoberyl symbol of an evil eye]] |
| 56-60 | [[Alabaster idol]] |
| 61-65 | [[Silk mask decorated with citrines]] |
| 66-70 | [[Set of decorated porcelain plates]] |
| 71-75 | [[Etched copper ewer]] |
| 76-80 | [[Brass scepter with amethyst head]] |
| 81-85 | [[Bronze chalice with bloodstones]] |
| 86-90 | [[Iron and rock crystal brazier]] |
| 91-95 | [[Quality sculpture by an unknown]] |
| 96-100 | [[Quality painting by an unknown]] |
