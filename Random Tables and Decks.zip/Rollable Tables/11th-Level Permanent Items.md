---
title: "11th-Level Permanent Items"
icon: ":list:"
aliases: "11th-Level Permanent Items"
foundryId: RollTable.3vD0TyBKnwlpvvxU
tags:
  - RollTable
---

# 11th-Level Permanent Items
Table of 11th-Level Permanent Items

| 1d148 | result |
|------|--------|
| 1-6 | Magic Armor (+2 resilient) |
| 7-12 | Cold Iron Armor, Standard Grade |
| 13-18 | Silver Armor, Standard Grade |
| 19-24 | [[Spacious Pouch (Type III)\|Bag of Holding (Type III)]] |
| 25-27 | [[Holy Prayer Beads (Greater)]] |
| 28-33 | [[Skeleton Key (Greater)]] |
| 34-39 | [[Armor Potency (+2)]] |
| 40-45 | [[Anarchic]] |
| 46-51 | [[Axiomatic]] |
| 52-57 | [[Holy]] |
| 58-63 | [[Unholy]] |
| 64-69 | [[Arrow-Catching Shield]] |
| 70-72 | [[Floating Shield]] |
| 73-78 | [[Magic Wand (5th-Rank Spell)\|Magic Wand (5th-Level Spell)]] |
| 79-84 | [[Wand of Continuation (4th-Rank Spell)\|Wand of Continuation (4th-Level Spell)]] |
| 85-87 | Adamantine Weapon, Standard Grade |
| 88-90 | Darkwood Weapon, Standard Grade |
| 91-93 | Mithral Weapon, Standard Grade |
| 94-99 | [[Oathbow]] |
| 100-105 | [[Alchemist Goggles (Greater)]] |
| 106 | Mithral Weapon (Standard-Grade) |
| 107-112 | [[Cassock of Devotion]] |
| 113-118 | [[Crafter's Eyepiece (Greater)]] |
| 119-124 | [[Doubling Rings (Greater)]] |
| 125-130 | [[Obsidian Goggles (Greater)]] |
| 131-136 | [[Gorget of the Primal Roar]] |
| 137-142 | [[Necklace of Fireballs IV]] |
| 143-148 | [[Ring of Maniacal Devices]] |
