---
title: "Moderate Art Object"
icon: ":list:"
aliases: "Moderate Art Object"
foundryId: RollTable.Qlu9bt1COI05olXW
tags:
  - RollTable
---

# Moderate Art Object
Table of Moderate Art Objects

| 1d100 | result |
|------|--------|
| 1-5 | [[Porcelain doll with amber eyes]] |
| 6-10 | [[Marble altar]] |
| 11-15 | [[Parade armor with flourishes]] |
| 16-20 | [[Silver coronet with peridots]] |
| 21-25 | [[Moonstone and onyx game set]] |
| 26-30 | [[Gold and garnet ring]] |
| 31-35 | [[Ceremonial shortsword with spinels]] |
| 36-40 | [[Silver statuette of a raven]] |
| 41-45 | [[Porcelain vase inlaid with gold]] |
| 46-50 | [[Enormous tapestry of a major battle]] |
| 51-55 | [[Gold necklace with peridots]] |
| 56-60 | [[Alabaster idol]] |
| 61-65 | [[Coral idol of an elemental lord]] |
| 66-70 | [[Silver mirror with gilded frame]] |
| 71-75 | [[Silver flagon inscribed with fields]] |
| 76-80 | [[Copper and spinel puzzle box]] |
| 81-85 | [[Small cold iron cauldron with onyx]] |
| 86-90 | [[Silver and jade censer]] |
| 91-95 | [[Life‑size sculpture by an expert]] |
| 96-100 | [[Wide landscape by an expert]] |
