---
title: "14th-Level Permanent Items"
icon: ":list:"
aliases: "14th-Level Permanent Items"
foundryId: RollTable.9qM3n4S16Pt96JIL
tags:
  - RollTable
---

# 14th-Level Permanent Items
Table of 14th-Level Permanent Items

| 1d120 | result |
|------|--------|
| 1-6 | Magic Armor (+2 Greater Resilient) |
| 7-12 | [[Alacritous Horseshoes (Greater)\|Horseshoes of Speed (Greater)]] |
| 13-15 | [[Crystal Ball (Clear Quartz)]] |
| 16-21 | [[Primeval Mistletoe (Greater)]] |
| 22-27 | [[Rod of Negation]] |
| 28-30 | [[Disrupting (Greater)]] |
| 31-36 | [[Resilient (Greater)]] |
| 37-42 | [[Staff of Abjuration (Major)]] |
| 43-48 | [[Staff of Conjuration (Major)]] |
| 49-54 | [[Staff of Divination (Major)]] |
| 55-60 | [[Staff of Enchantment (Major)]] |
| 61-66 | [[Staff of Evocation (Major)]] |
| 67-72 | [[Staff of Illusion (Major)]] |
| 73-78 | [[Staff of Necromancy (Major)]] |
| 79-84 | [[Staff of Transmutation (Major)]] |
| 85-90 | [[Wand of Widening (6th-Rank Spell)\|Wand of Widening (6th-Level Spell)]] |
| 91-93 | [[Holy Avenger]] |
| 94-99 | [[Storm Flash]] |
| 100-105 | [[Boots of Bounding (Greater)]] |
| 106-111 | [[Bands of Force (Greater)\|Bracers of Armor II]] |
| 112-117 | [[Charm of Resistance (Major)\|Ring of Energy Resistance (Major)]] |
| 118-120 | [[Ring of Wizardry (Type IV)]] |
