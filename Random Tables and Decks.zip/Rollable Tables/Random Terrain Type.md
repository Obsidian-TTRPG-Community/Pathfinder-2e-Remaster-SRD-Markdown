---
title: "Random Terrain Type"
icon: ":list:"
aliases: "Random Terrain Type"
foundryId: RollTable.duHQ6nz3uUB81j1G
tags:
  - RollTable
---

# Random Terrain Type
Table for Random Terrain Types

| 1d20 | result |
|------|--------|
| 1-3 | Plains |
| 4-5 | Desert |
| 6-7 | Aquatic (lake, sea, or ocean) |
| 8-9 | Mountain |
| 10-11 | Forest |
| 12 | Swamp |
| 13 | Arctic |
| 14-20 | Match the previous hex |
