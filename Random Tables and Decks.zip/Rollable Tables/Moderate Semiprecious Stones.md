---
title: "Moderate Semiprecious Stones"
icon: ":list:"
aliases: "Moderate Semiprecious Stones"
foundryId: RollTable.u3MngEzaOkftcWTt
tags:
  - RollTable
---

# Moderate Semiprecious Stones
Table of Moderate Semiprecious Stones

| 1d100 | result |
|------|--------|
| 1-7 | [[Bloodstone]] |
| 8-14 | [[Carnelian]] |
| 15-21 | [[Chrysoprase]] |
| 22-28 | [[Citrine]] |
| 29-35 | [[Ivory]] |
| 36-42 | [[Jasper]] |
| 43-49 | [[Moonstone]] |
| 50-56 | [[Onyx]] |
| 57-63 | [[Peridot]] |
| 64-70 | [[Quartz, milky, rose, or smoky]] |
| 71-77 | [[Sard]] |
| 78-84 | [[Sardonyx]] |
| 85-92 | [[Spinel, red or green]] |
| 93-100 | [[Zircon]] |
