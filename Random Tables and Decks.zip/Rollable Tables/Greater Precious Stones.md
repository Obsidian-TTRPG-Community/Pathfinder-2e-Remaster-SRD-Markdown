---
title: "Greater Precious Stones"
icon: ":list:"
aliases: "Greater Precious Stones"
foundryId: RollTable.XduQkNmN6SSYGSBJ
tags:
  - RollTable
---

# Greater Precious Stones
Table of Greater Precious Stones

| 1d100 | result |
|------|--------|
| 1-25 | [[Diamond, large]] |
| 26-50 | [[Emerald, brilliant green]] |
| 51-75 | [[Ruby, large]] |
| 76-100 | [[Star sapphire]] |
