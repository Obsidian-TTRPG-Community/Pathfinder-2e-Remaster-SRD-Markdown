---
title: "18th-Level Consumables"
icon: ":list:"
aliases: "18th-Level Consumables"
foundryId: RollTable.9Cw75mA8PMNlM1o8
tags:
  - RollTable
---

# 18th-Level Consumables
Table of 18th-Level Consumables Items

| 1d18 | result |
|------|--------|
| 1-6 | [[King's Sleep]] |
| 7-12 | [[Healing Potion (Major)]] |
| 13-18 | [[Potion of Undetectability]] |
