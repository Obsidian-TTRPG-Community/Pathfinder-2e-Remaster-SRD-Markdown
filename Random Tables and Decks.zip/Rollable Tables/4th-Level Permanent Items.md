---
title: "4th-Level Permanent Items"
icon: ":list:"
aliases: "4th-Level Permanent Items"
foundryId: RollTable.PML6HIQHuncSFpx5
tags:
  - RollTable
---

# 4th-Level Permanent Items
Table of 4th-Level Permanent Items

| 1d84 | result |
|------|--------|
| 1-6 | [[Spacious Pouch (Type I)\|Bag of Holding (Type I)]] |
| 7-12 | [[Ghost Touch]] |
| 13-18 | [[Striking]] |
| 19-24 | [[Sturdy Shield (Minor)]] |
| 25-30 | [[Animal Staff]] |
| 31-36 | [[Mentalist's Staff]] |
| 37-42 | [[Staff of Healing]] |
| 43-48 | [[Wand of Widening (1st-Rank Spell)\|Wand of Widening (1st-Level Spell)]] |
| 49-54 | Weapon (+1 Striking) |
| 55-60 | [[Alchemist Goggles]] |
| 61-66 | +1 striking [[Handwraps of Mighty Blows]] |
| 67-72 | [[Demon Mask]] |
| 73-78 | [[Healer's Gloves]] |
| 79-84 | [[Lifting Belt]] |
