---
title: "3rd-Level Permanent Items"
icon: ":list:"
aliases: "3rd-Level Permanent Items"
foundryId: RollTable.5LA0wGKBC98nU2kt
tags:
  - RollTable
---

# 3rd-Level Permanent Items
Table of 3rd-Level Permanent Items

| 1d123 | result |
|------|--------|
| 1-6 | [[Maestro's Instrument (Lesser)]] |
| 7-12 | [[Thurible of Revelation (Lesser)]] |
| 13-18 | [[Returning]] |
| 19-24 | [[Shadow]] |
| 25-30 | [[Slick]] |
| 31-36 | [[Staff of Fire]] |
| 37-42 | [[Magic Wand (1st-Rank Spell)\|Magic Wand (1st-Level Spell)]] |
| 43-48 | [[Fighter's Fork]] |
| 49-54 | [[Retribution Axe]] |
| 55-60 | [[Bracelet of Dashing]] |
| 61-66 | [[Bracers of Missile Deflection]] |
| 67-69 | [[Channel Protection Amulet]] |
| 70-75 | [[Coyote Cloak]] |
| 76-81 | [[Crafter's Eyepiece]] |
| 82-87 | [[Dancing Scarf]] |
| 88-93 | [[Doubling Rings]] |
| 94-99 | [[Mage's Hat\|Hat of the Magi]] |
| 100-105 | [[Pendant of the Occult]] |
| 106-111 | [[Persona Mask]] |
| 112-117 | [[Tracker's Goggles]] |
| 118-123 | [[Ventriloquist's Ring]] |
