---
title: "Hills Dangers"
icon: ":list:"
aliases: "Hills Dangers"
foundryId: RollTable.KYhCzAlzCmxVpdPU
tags:
  - RollTable
---

# Hills Dangers
| 1d100 | result |
|------|--------|
| 1-3 | [[/r 1d6]] [[Ghoul\|Ghouls]] (Moderate 2) |
| 4-7 | 1 [[Orc Warchief\|Orc Commander]] and [[/r 1d4]] [[Orc Warrior\|Orc Veterans]] (Moderate 3) |
| 8-11 | 3 [[Dhampir Wizard\|Dhampir Wizards]] (Moderate 3) |
| 12-15 | [[/r 1d8]] [[Zombie Brute\|Zombie Brutes]] (Moderate 4) |
| 16-19 | 1 [[Zombie Hulk]] (Moderate 4) |
| 20-24 | 1 [[Soul Eater]] (Moderate 5) |
| 25-29 | 1 [[Specter]] (Moderate 5) |
| 30-34 | 1 [[Vampire Count]] and [[/r 1d3]] [[Vampire Spawn Rogue\|Vampire Spawn Rogues]] (Moderate 6) |
| 35-39 | [[/r 2d4]] [[Wight\|Wights]] (Moderate 6) |
| 40-47 | [[/r 1d3]] [[Skeletal Hulk\|Skeletal Hulks]] (Moderate 7) |
| 48-55 | 1 [[Roiling Incant (Evocation)]] (Moderate 7) |
| 56-63 | 1 [[Cult Leader]] and [[/r 1d6]] [[Necromancer\|Necromancers]] (Moderate 8) |
| 64-71 | 1 [[Vrykolakas Master]] (Moderate 8) |
| 72-76 | 2 [[Zombie Dragon\|Zombie Dragons]] (Moderate 9) |
| 77-81 | 1 [[Lich]] (Moderate 10) |
| 82-86 | [[/r 1d6]] [[Dread Wraith\|Dread Wraiths]] (Moderate 11) |
| 87-92 | [[/r 1d3]] [[Tomb Giant\|Tomb Giants]] (Moderate 12) |
| 93-96 | 1 [[Wemmuth]] (Moderate 13) |
| 97-99 | 1 [[Lesser Death]] (Moderate 14) |
| 100 | 2 [[Warsworn\|Warsworns]] (Moderate 16) |
