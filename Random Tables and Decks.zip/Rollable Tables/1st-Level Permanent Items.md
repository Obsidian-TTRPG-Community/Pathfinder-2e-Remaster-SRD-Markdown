---
title: "1st-Level Permanent Items"
icon: ":list:"
aliases: "1st-Level Permanent Items"
foundryId: RollTable.ltoa3yvjmLeDoxcS
tags:
  - RollTable
---

# 1st-Level Permanent Items
Table of 1st-Level Permanent Items

| 1d21 | result |
|------|--------|
| 1-6 | [[Half Plate]] |
| 7-12 | [[Splint Mail]] |
| 13-18 | [[Everlight Crystal\|Everburning Torch]] |
| 19-21 | [[Aeon Stone (Consumed)\|Aeon Stone (Dull Grey)]] |
