---
title: "Critical Fumble Deck"
icon: ":list:"
aliases: "Critical Fumble Deck"
foundryId: RollTable.oHt5LvvAcaCXvjyB
tags:
  - RollTable
---

# Critical Fumble Deck
Table for Critical Fumble Cards

| 1d53 | result |
|------|--------|
| 1 | [[Critical Fumble Deck #1]] |
| 2 | [[Critical Fumble Deck #2]] |
| 3 | [[Critical Fumble Deck #3]] |
| 4 | [[Critical Fumble Deck #4]] |
| 5 | [[Critical Fumble Deck #5]] |
| 6 | [[Critical Fumble Deck #6]] |
| 7 | [[Critical Fumble Deck #7]] |
| 8 | [[Critical Fumble Deck #8]] |
| 9 | [[Critical Fumble Deck #9]] |
| 10 | [[Critical Fumble Deck #10]] |
| 11 | [[Critical Fumble Deck #11]] |
| 12 | [[Critical Fumble Deck #12]] |
| 13 | [[Critical Fumble Deck #13]] |
| 14 | [[Critical Fumble Deck #14]] |
| 15 | [[Critical Fumble Deck #15]] |
| 16 | [[Critical Fumble Deck #16]] |
| 17 | [[Critical Fumble Deck #17]] |
| 18 | [[Critical Fumble Deck #18]] |
| 19 | [[Critical Fumble Deck #19]] |
| 20 | [[Critical Fumble Deck #20]] |
| 21 | [[Critical Fumble Deck #21]] |
| 22 | [[Critical Fumble Deck #22]] |
| 23 | [[Critical Fumble Deck #23]] |
| 24 | [[Critical Fumble Deck #24]] |
| 25 | [[Critical Fumble Deck #25]] |
| 26 | [[Critical Fumble Deck #26]] |
| 27 | [[Critical Fumble Deck #27]] |
| 28 | [[Critical Fumble Deck #28]] |
| 29 | [[Critical Fumble Deck #29]] |
| 30 | [[Critical Fumble Deck #30]] |
| 31 | [[Critical Fumble Deck #31]] |
| 32 | [[Critical Fumble Deck #32]] |
| 33 | [[Critical Fumble Deck #33]] |
| 34 | [[Critical Fumble Deck #34]] |
| 35 | [[Critical Fumble Deck #35]] |
| 36 | [[Critical Fumble Deck #36]] |
| 37 | [[Critical Fumble Deck #37]] |
| 38 | [[Critical Fumble Deck #38]] |
| 39 | [[Critical Fumble Deck #39]] |
| 40 | [[Critical Fumble Deck #40]] |
| 41 | [[Critical Fumble Deck #41]] |
| 42 | [[Critical Fumble Deck #42]] |
| 43 | [[Critical Fumble Deck #43]] |
| 44 | [[Critical Fumble Deck #44]] |
| 45 | [[Critical Fumble Deck #45]] |
| 46 | [[Critical Fumble Deck #46]] |
| 47 | [[Critical Fumble Deck #47]] |
| 48 | [[Critical Fumble Deck #48]] |
| 49 | [[Critical Fumble Deck #49]] |
| 50 | [[Critical Fumble Deck #50]] |
| 51 | [[Critical Fumble Deck #51]] |
| 52 | [[Critical Fumble Deck #52]] |
| 53 | [[Critical Fumble Deck #53]] |
