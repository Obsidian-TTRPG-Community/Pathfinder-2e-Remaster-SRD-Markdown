---
title: "Waterways Dangers"
icon: ":list:"
aliases: "Waterways Dangers"
foundryId: RollTable.d3Z743j4QGSkK0Qj
tags:
  - RollTable
---

# Waterways Dangers
| 1d100 | result |
|------|--------|
| 1-3 | [[/r 1d4]] [[Bandit\|Bandits]] (Moderate 2) |
| 4-7 | [[/r 1d6]] [[Draugr]] (Moderate 3) |
| 8-11 | [[/r 1d4]] [[River Drake\|River Drakes]] (Moderate 3) |
| 12-15 | [[/r 1d4]] [[Brood Leech Swarm]] (Moderate 4) |
| 16-19 | 2 [[Bog Mummy\|Bog Mummies]] (Moderate 4) |
| 20-24 | [[/r 1d4]] [[Revenant\|Revenants]] (Moderate 5) |
| 25-29 | [[/r 1d4]] [[Will-o'-Wisp]] (Moderate 5) |
| 30-34 | [[/r 1d4]] [[Giant Mosquito]] (Moderate 6) |
| 35-39 | [[/r 1d4]] [[Sea Drake\|Sea Drakes]] (Moderate 6) |
| 40-47 | [[/r 1d3]] [[Skeletal Hulk\|Skeletal Hulks]] (Moderate 7) |
| 48-55 | 1 [[Giant Snapping Turtle]] (Moderate 7) |
| 56-63 | [[/r 1d4]] [[Giant Slug\|Giant Slugs]] (Moderate 8) |
| 64-71 | [[/r 1d4]] [[Dread Wraith\|Dread Wraiths]] (Moderate 8) |
| 72-76 | [[/r 1d3]] [[Water Orm\|Water Orms]] (Moderate 9) |
| 77-81 | 1 [[Sea Serpent]] (Moderate 10) |
| 82-86 | [[/r 1d3]] [[Catoblepas]] (Moderate 11) |
| 87-92 | 1 [[Ravener Husk]] (Moderate 12) |
| 93-96 | 1 [[Demilich]] (Moderate 13) |
| 97-99 | 2 [[Worm That Walks Cultist]] (Moderate 14) |
| 100 | 1 [[Bone Ship]] (Moderate 16) |
