---
title: "9th-Level Consumables Items"
icon: ":list:"
aliases: "9th-Level Consumables Items"
foundryId: RollTable.fuwQQNtHC8aWpQqw
tags:
  - RollTable
---

# 9th-Level Consumables Items
Table of 9th-Level Consumables Items

| 1d72 | result |
|------|--------|
| 1-6 | [[Explosive Ammunition]] |
| 7-12 | [[Spellstrike Ammunition (Type IV)]] |
| 13-18 | [[Storm Arrow]] |
| 19-24 | [[Dust of Disappearance]] |
| 25-30 | [[Feather Token (Whip)]] |
| 31-36 | [[Trident of Lightning\|Javelin of Lightning]] |
| 37-42 | [[Cheetah's Elixir (Greater)]] |
| 43-48 | [[Elixir of Life (Moderate)]] |
| 49-54 | [[Aligned Oil]] |
| 55-60 | [[Lich Dust]] |
| 61-66 | [[Spider Root]] |
| 67-72 | [[Scroll of 5th-rank Spell\|Scroll of 5th-level Spell]] |
