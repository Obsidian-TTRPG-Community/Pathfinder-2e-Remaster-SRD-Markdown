---
title: "Greater Art Object"
icon: ":list:"
aliases: "Greater Art Object"
foundryId: RollTable.I9l6M9KugNhoWspN
tags:
  - RollTable
---

# Greater Art Object
Table of Greater Art Objects

| 1d100 | result |
|------|--------|
| 1-5 | [[Gilded ceremonial armor]] |
| 6-10 | [[Ancient dragon skull etched with mystic sigils]] |
| 11-15 | [[Original manuscript from a world‑famous author]] |
| 16-20 | [[Gold and aquamarine diadem]] |
| 21-25 | [[Gold dragon statuette]] |
| 26-30 | [[Jet and white gold game set]] |
| 31-35 | [[Gold rapier with amethysts]] |
| 36-40 | [[Gold urn with scenes of judgment]] |
| 41-45 | [[Splendid lyre of world‑famous lyrist]] |
| 46-50 | [[Platinum‑framed monocle]] |
| 51-55 | [[Gold mask of a high priest]] |
| 56-60 | [[Crystal dinner set, fine silverware]] |
| 61-65 | [[Gold and opal bracelet]] |
| 66-70 | [[Intricate silver and gold music box]] |
| 71-75 | [[Jeweled orrery of the planes]] |
| 76-80 | [[Gilded scepter with sapphire]] |
| 81-85 | [[Fine gold spyglass]] |
| 86-90 | [[Gold chalice with black pearls]] |
| 91-95 | [[Towering sculpture by a master]] |
| 96-100 | [[Famous portrait by a master]] |
