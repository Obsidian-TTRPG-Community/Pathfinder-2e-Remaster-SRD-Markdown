---
title: "Hero Point Deck"
icon: ":list:"
aliases: "Hero Point Deck"
foundryId: RollTable.mdGLbrqTmCbXCuY4
tags:
  - RollTable
---

# Hero Point Deck
<p>Table for Hero Point Cards</p>

| 1d52 | result |
|------|--------|
| 1 | [[Ancestral Might]] |
| 2 | [[Aura of Protection]] |
| 3 | [[Rage and Fury]] |
| 4 | [[I Hope This Works]] |
| 5 | [[Endure the Onslaught]] |
| 6 | [[Battle Cry]] |
| 7 | [[Catch your Breath]] |
| 8 | [[Last Stand]] |
| 9 | [[Shoot Through]] |
| 10 | [[Reckless Charge]] |
| 11 | [[Roll Back]] |
| 12 | [[Warding Sign]] |
| 13 | [[Called Foe]] |
| 14 | [[Class Might]] |
| 15 | [[Hold the Line]] |
| 16 | [[Tumble Through]] |
| 17 | [[Fluid Motion]] |
| 18 | [[Magical Reverberation]] |
| 19 | [[Spark of Courage]] |
| 20 | [[Pierce Resistance]] |
| 21 | [[Press On]] |
| 22 | [[Impossible Shot]] |
| 23 | [[Protect the Innocent]] |
| 24 | [[Healing Prayer]] |
| 25 | [[Make Way!]] |
| 26 | [[Rending Swipe]] |
| 27 | [[Stay in the Fight]] |
| 28 | [[Strike True]] |
| 29 | [[Drain Power]] |
| 30 | [[Shake it Off]] |
| 31 | [[Dive Out of Danger]] |
| 32 | [[Push Through the Pain]] |
| 33 | [[Hasty Block]] |
| 34 | [[Distract Foe]] |
| 35 | [[Last Second Sidestep]] |
| 36 | [[Reverse Strike]] |
| 37 | [[Critical Moment]] |
| 38 | [[Channel Life Force]] |
| 39 | [[Stoke the Magical Flame]] |
| 40 | [[Desperate Swing]] |
| 41 | [[Cut Through the Fog]] |
| 42 | [[Surge of Speed]] |
| 43 | [[Opportune Distraction]] |
| 44 | [[Run and Shoot]] |
| 45 | [[Flash of Insight]] |
| 46 | [[Rampage]] |
| 47 | [[Misdirected Attack]] |
| 48 | [[Grazing Blow]] |
| 49 | [[Last Ounce of Strength]] |
| 50 | [[Tuck and Roll]] |
| 51 | [[Surge of Magic]] |
| 52 | [[Daring Attempt]] |
