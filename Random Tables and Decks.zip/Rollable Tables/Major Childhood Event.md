---
title: "Major Childhood Event"
icon: ":list:"
aliases: "Major Childhood Event"
foundryId: RollTable.2fkZHqd1RxVjkBqQ
tags:
  - RollTable
---

# Major Childhood Event
Table of Major Childhood Events

| 1d20 | result |
|------|--------|
| 1 | Abandoned in a Distant Land |
| 2 | Academy Trained |
| 3 | Attained a Magical Gift |
| 4 | Betrayed |
| 5 | Bullied |
| 6 | Captured by Giants |
| 7 | Claimed an Inheritance |
| 8 | Died |
| 9 | Fell In with a Bad Crowd |
| 10 | Had an Ordinary Childhood |
| 11 | Had Your First Kill |
| 12 | Kidnapped |
| 13 | Lost in the Wilderness |
| 14 | Met a Fantastic Creature |
| 15 | Raided |
| 16 | Robbed |
| 17 | Survived a Disaster |
| 18 | Trained by a Mentor |
| 19 | Witnessed War |
| 20 | Won a Competition |
