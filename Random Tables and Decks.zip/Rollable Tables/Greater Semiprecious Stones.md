---
title: "Greater Semiprecious Stones"
icon: ":list:"
aliases: "Greater Semiprecious Stones"
foundryId: RollTable.r3krU1zLRkr4KQaR
tags:
  - RollTable
---

# Greater Semiprecious Stones
Table of Greater Semiprecious Stones

| 1d100 | result |
|------|--------|
| 1-10 | [[Amber]] |
| 11-20 | [[Amethyst]] |
| 21-30 | [[Chrysoberyl]] |
| 31-40 | [[Coral]] |
| 41-50 | [[Garnet]] |
| 51-60 | [[Jade]] |
| 61-70 | [[Jet]] |
| 71-80 | [[Pearl, saltwater]] |
| 81-90 | [[Spinel, deep blue]] |
| 91-100 | [[Tourmaline]] |
