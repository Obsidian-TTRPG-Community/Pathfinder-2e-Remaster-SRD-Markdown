---
title: "Primal Howl"
icon: ":luggage:"
aliases: "Primal Howl"
foundryId: Item.si28iSaNRTEDBRx6
tags:
  - Item
---

# Primal Howl `pf2:2`

**Frequency** once per hour

* * *

**Effect** Your familiar screeches and howls, empowered with natural magic. All creatures in a 30-Foot Cone take 0 sonic damage for every 2 levels your companion has, with a DC 0 Basic Fortitude save against your spell DC. Creatures that fail become Frightened 1, and creatures that critically fail become Frightened 2. The fright is an emotion, fear, and mental effect.
