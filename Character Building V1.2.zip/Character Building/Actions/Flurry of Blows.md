---
title: "Flurry of Blows"
icon: ":luggage:"
aliases: "Flurry of Blows"
foundryId: Item.iJkmBN4rtruFHk7f
tags:
  - Item
---

# Flurry of Blows `pf2:1`

Make two unarmed Strikes. If both hit the same creature, combine their damage for the purpose of resistances and weaknesses. Apply your multiple attack penalty to the Strikes normally. As it has the flourish trait, you can use Flurry of Blows only once per turn.
