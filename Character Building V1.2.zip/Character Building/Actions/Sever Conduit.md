---
title: "Sever Conduit"
icon: ":luggage:"
aliases: "Sever Conduit"
foundryId: Item.jqflyu3qlzRHMZX8
tags:
  - Item
---

# Sever Conduit `pf2:r`

**Trigger** Your eidolon takes damage that would bring you to 0 Hit Points and comes from an effect other than a death effect

* * *

**Effect** You quickly shut the buffer in your link with your eidolon, causing your bonded ally to wink out of existence before you can be laid low. Your eidolon unmanifests, and you can't Manifest your Eidolon for 1 minute. In exchange, you don't take the triggering damage, though your eidolon still suffers any other adverse effects that accompanied the damage.
