---
title: "Master Strike"
icon: ":luggage:"
aliases: "Master Strike"
foundryId: Item.4SruDEl8VLRGg2ku
tags:
  - Item
---

# Master Strike `pf2:0`

**Trigger** Your Strike hits an [[Off-Guard]] creature and deals damage.

* * *

The target attempts a DC resolve fortitude save against your class DC. It then becomes temporarily immune to your Master Strike for 1 day.

* * *

**Critical Success** The target is unaffected.

**Success** The target is [[Enfeebled 1|Enfeebled 2]] until the end of your next turn.

**Failure** The target is [[Paralyzed]] for 4 rounds.

**Critical Failure** The target is paralyzed for 4 rounds, knocked [[Unconscious]] for 2 hours, or killed (your choice).
