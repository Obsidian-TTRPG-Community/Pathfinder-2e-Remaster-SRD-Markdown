---
title: "Fey's Fortune"
icon: ":luggage:"
aliases: "Fey's Fortune"
foundryId: Item.VfJbI2b7z15htrBl
tags:
  - Item
---

# Fey's Fortune `pf2:0`

**Frequency** once per day

**Trigger** You attempt a skill check and haven't yet rolled

* * *

**Effect** Roll the skill check twice and use the better result
