---
title: "Call Companion"
icon: ":luggage:"
aliases: "Call Companion"
foundryId: Item.tWq8zkbUJ2yNMYkT
tags:
  - Item
---

# Call Companion
![[systems-pf2e-icons-actions-Passive.webp|150]]

You spend 1 minute calling for a different animal companion, switching your active companion for another of your animal companions.
