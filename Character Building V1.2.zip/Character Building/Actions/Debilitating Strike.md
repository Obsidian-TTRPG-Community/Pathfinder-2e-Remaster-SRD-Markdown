---
title: "Debilitating Strike"
icon: ":luggage:"
aliases: "Debilitating Strike"
foundryId: Item.zthxSigYIXwWZvIo
tags:
  - Item
---

# Debilitating Strike `pf2:0`

**Trigger** Your Strike hits an off-guard creature and deals damage

* * *

You apply one of the following debilitations, which lasts until the end of your next turn:

*   **Debilitation** The target takes a -10-foot status penalty to its Speeds.
*   **Debilitation** The target becomes [[Enfeebled 1]].


