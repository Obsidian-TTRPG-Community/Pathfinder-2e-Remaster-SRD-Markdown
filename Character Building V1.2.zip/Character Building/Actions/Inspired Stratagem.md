---
title: "Inspired Stratagem"
icon: ":luggage:"
aliases: "Inspired Stratagem"
foundryId: Item.jvIrVJrCUFc4Y6ez
tags:
  - Item
---

# Inspired Stratagem `pf2:r`

**Trigger** An ally you reviewed stratagems with is about to attempt an attack roll or skill check

* * *

**Effect** The ally rolls the triggering check twice and takes the better of the two results. That ally then becomes temporarily immune to your Inspired Stratagem until your next daily preparations.


