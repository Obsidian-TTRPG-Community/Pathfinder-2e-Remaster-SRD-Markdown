---
title: "Set Free"
icon: ":luggage:"
aliases: "Set Free"
foundryId: Item.igCMtUI0XBkPxHC3
tags:
  - Item
---

# Set Free `pf2:r`

**Frequency** once per hour

**Trigger** You attempt a check to remove or counteract an effect with the [[Confused]], [[Controlled]], [[Fascinated]], [[Immobilized]], [[Paralyzed]], or [[Restrained]] conditions

* * *

**Effect** You roll twice and use the better result.
