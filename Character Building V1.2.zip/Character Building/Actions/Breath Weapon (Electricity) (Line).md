---
title: "Breath Weapon (Electricity) (Line)"
icon: ":luggage:"
aliases: "Breath Weapon (Electricity) (Line)"
foundryId: Item.cnwAuYDsMzbID0xa
tags:
  - Item
---

# Breath Weapon (Electricity) (Line) `pf2:2`

Your eidolon exhales a blast of destructive energy. Your eidolon deals 1d6 electricity damage to all creatures in a 60 foot line, with a basic Reflex save against your spell DC.

Your eidolon then can't use their Breath Weapon again for the next 1d4 rounds.

At 3rd level and every 2 levels thereafter, the damage increases by 1d6. 
