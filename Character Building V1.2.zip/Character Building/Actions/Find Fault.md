---
title: "Find Fault"
icon: ":luggage:"
aliases: "Find Fault"
foundryId: Item.jzbxiTGQuk9hYPAI
tags:
  - Item
---

# Find Fault `pf2:r`

**Trigger** You attempt a saving throw against a spell or magic effect but haven't rolled yet

* * *

**Effect** You find some kind of fault with the magic, using that flaw to protect yourself from the effect. You gain a +1 circumstance bonus to your saving throw against the triggering effect, which increases to a +2 circumstance bonus if the effect is divine and originates from a worshipper of the deity you chose for your grudge.
