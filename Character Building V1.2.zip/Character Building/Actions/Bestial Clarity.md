---
title: "Bestial Clarity"
icon: ":luggage:"
aliases: "Bestial Clarity"
foundryId: Item.rWfMKYow2MFcAuYF
tags:
  - Item
---

# Bestial Clarity `pf2:r`

**Frequency** once per day

**Trigger** You fail a saving throw against an enchantment effect

* * *

**Effect** Your bestial manifestation becomes more pronounced, and your mind gains a flash of clarity as your instincts take over. You can reroll the triggering saving throw with a +2 circumstance bonus, but you must use the new result. This is a fortune effect.
