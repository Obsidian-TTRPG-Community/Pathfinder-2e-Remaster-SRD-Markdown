---
title: "Mutagenic Flashback"
icon: ":luggage:"
aliases: "Mutagenic Flashback"
foundryId: Item.2kykwQZdyJPVtAV2
tags:
  - Item
---

# Mutagenic Flashback `pf2:0`

**Frequency** once per day

* * *

You experience a brief resurgence of a mutagen. Choose one mutagen you've consumed since your last daily preparations. You gain the effects of that mutagen for 1 minute.
