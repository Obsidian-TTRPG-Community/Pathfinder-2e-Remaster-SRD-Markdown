---
title: "Call Upon the Brightness"
icon: ":luggage:"
aliases: "Call Upon the Brightness"
foundryId: Item.m69bWddnoIlTC3cM
tags:
  - Item
---

# Call Upon the Brightness `pf2:r`

**Trigger** You attempt an attack roll, skill check, or saving throw while performing the course of action from your _[[Augury]]_, but you haven't rolled yet

* * *

You gain a +1 status bonus to the triggering check, or a +2 status bonus if the result of the augury was "woe" and you proceeded anyway.


