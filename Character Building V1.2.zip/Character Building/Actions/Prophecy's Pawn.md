---
title: "Prophecy's Pawn"
icon: ":luggage:"
aliases: "Prophecy's Pawn"
foundryId: Item.S8DODc4qZDdQxgB5
tags:
  - Item
---

# Prophecy's Pawn `pf2:0`

**Trigger** You fail a saving throw, attack roll, or skill check

* * *

**Effect** You twist the prophecy in your favor, which will have consequences later. Reroll the failed check. You must use the result of the second roll.

For 24 hours afterward, the GM can force you to reroll a successful saving throw, attack roll, or skill check as fate balances the scale. This is a misfortune effect. You can't use prophecy's pawn again until the GM uses this option or 24 hours pass, whichever comes first.
