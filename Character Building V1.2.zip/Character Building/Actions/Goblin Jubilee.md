---
title: "Goblin Jubilee"
icon: ":luggage:"
aliases: "Goblin Jubilee"
foundryId: Item.duHbb0w4rxQbRmCl
tags:
  - Item
---

# Goblin Jubilee `pf2:3`

**Cost** 3 batches of infused reagents

* * *

**Effect** Chaos fills a 20 foot burst within 120 feet. All creatures in the area takes 3d6 fire, 3d6 sonic{3d6 fire damage and 3d6 sonic damage} and must attempt a Fortitude save. A goblin jubilee display costs 3 batches of infused reagents, rather than 1.

* * *

**Critical Success** The creature is unaffected.

**Success** The creature is [[Dazzled]] and [[Deafened]] until the end of its next turn and takes half damage.

**Failure** The creature is dazzled and deafened for 1 minute and takes full damage.

**Critical Failure** The creature is [[Blinded]] for 1 round, dazzled and deafened for 1 minute, and takes double damage.
