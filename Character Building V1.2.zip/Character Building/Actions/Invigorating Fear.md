---
title: "Invigorating Fear"
icon: ":luggage:"
aliases: "Invigorating Fear"
foundryId: Item.1ppnRXrQ4YXbAjJC
tags:
  - Item
---

# Invigorating Fear `pf2:r`

**Frequency** once per hour

**Trigger** A creature within 60 feet gains the [[Frightened]] condition.

* * *

You are invigorated by the shock of a prank or the thrum of terror. You gain temporary Hit Points equal to the creature's level or 3, whichever is higher. You lose any temporary Hit Points after 1 minute.
