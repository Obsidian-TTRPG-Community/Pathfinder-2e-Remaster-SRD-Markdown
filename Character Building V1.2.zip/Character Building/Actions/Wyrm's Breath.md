---
title: "Wyrm's Breath"
icon: ":luggage:"
aliases: "Wyrm's Breath"
foundryId: Item.IkSbzJR4cugx95U7
tags:
  - Item
---

# Wyrm's Breath `pf2:0`

**Frequency** once per minute

Your eidolon gathers the power of the mightiest wyrms to make its magical breath even more spectacular. If your eidolon's next action is to use Breath Weapon, both the number of damage dice and area of the Breath Weapon are doubled.
