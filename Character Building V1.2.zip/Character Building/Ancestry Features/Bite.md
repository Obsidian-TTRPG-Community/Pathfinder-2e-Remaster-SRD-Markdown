---
title: "Bite"
icon: ":luggage:"
aliases: "Bite"
foundryId: Item.bwUXBkPoQ0hsGVN2
tags:
  - Item
---

# Bite
![[icons-creatures-abilities-mouth-teeth-long-red.webp|150]]

Your sharp teeth and powerful jaws are fearsome weapons. You have a jaws unarmed attack that deals 1d6 piercing damage. Your jaws are in the brawling group.
