---
title: "Darkvision"
icon: ":luggage:"
aliases: "Darkvision"
foundryId: Item.YH5s4zY34W5rhkD1
tags:
  - Item
---

# Darkvision
![[systems-pf2e-icons-features-ancestry-darkvision.webp|150]]

You can see in darkness and dim light just as well as you can see in bright light, though your vision in darkness is in black and white.
