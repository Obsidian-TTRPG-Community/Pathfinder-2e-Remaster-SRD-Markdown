---
title: "Innate Venom"
icon: ":luggage:"
aliases: "Innate Venom"
foundryId: Item.UblSuXZ0rC4UG8q6
tags:
  - Item
---

# Innate Venom
![[icons-skills-melee-blade-tip-energy-green.webp|150]]

Your blood carries toxins deadly to all but yourself. You gain the [[Envenom]] action, which can deliver minor vishkanyan venom. The save DC for your venom is equal to the higher of your class DC or spell DC.
