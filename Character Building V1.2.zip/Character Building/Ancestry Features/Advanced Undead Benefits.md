---
title: "Advanced Undead Benefits"
icon: ":luggage:"
aliases: "Advanced Undead Benefits"
foundryId: Item.nsYJUsUqPdZaEX5V
tags:
  - Item
---

# Advanced Undead Benefits
![[icons-magic-death-skull-humanoid-white-red.webp|150]]

**Darkvision:** You gain darkvision if you don't already have it.

**Greater Disease and Poison Protection:** Your bonus against disease and poison increases to +2. You gain poison resistance equal to half your level.

**Paralysis and Sleep Protection:** You gain a +1 circumstance bonus to saving throws (or any other defense) against effects that would make you [[Paralyzed]] or have the sleep trait.
