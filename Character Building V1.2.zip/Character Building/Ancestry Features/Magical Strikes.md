---
title: "Magical Strikes"
icon: ":luggage:"
aliases: "Magical Strikes"
foundryId: Item.KG857nT6MeypNfJj
tags:
  - Item
---

# Magical Strikes
![[icons-creatures-magical-fae-fairy-winged-glowing-green.webp|150]]

Your inherent magic pervades your entire being. All your Strikes are magical, whether with unarmed attacks or weapons.
