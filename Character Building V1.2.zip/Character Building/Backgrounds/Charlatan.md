---
title: "Charlatan"
icon: ":luggage:"
aliases: "Charlatan"
foundryId: Item.HYJMVu6xaJpVAe60
tags:
  - Item
---

# Charlatan
![[systems-pf2e-icons-default-icons-background.svg|150]]

You traveled from place to place, peddling false fortunes and snake oil in one town, pretending to be royalty in exile to seduce a wealthy heir in the next. Becoming an adventurer might be your next big scam or an attempt to put your talents to use for a greater cause. Perhaps it's a bit of both, as you realize that after pretending to be a hero, you've become the mask.

Choose two attribute boosts. One must be to **Intelligence** or **Charisma**, and one is a free attribute boost.

You're trained in the Deception skill and the Underworld Lore skill. You gain the [[Charming Liar]] skill feat.
