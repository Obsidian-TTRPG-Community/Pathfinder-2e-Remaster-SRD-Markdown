---
title: "Sprite"
icon: ":luggage:"
aliases: "Sprite"
foundryId: Item.mTKjZmE5u8Z4omli
tags:
  - Item
---

# Sprite
![[systems-pf2e-icons-default-icons-alternatives-ancestries-sprite.svg|150]]

_Sprites are diminutive, whimsical, and exuberant creatures from the fey realm known as the First World. They love playing pranks, exploring new things, and embracing everything to do with magic._

_[[Sprite]]_
