---
title: "Elf"
icon: ":luggage:"
aliases: "Elf"
foundryId: Item.j6g4WMcVvQpEHZFq
tags:
  - Item
---

# Elf
![[systems-pf2e-icons-default-icons-alternatives-ancestries-elf.svg|150]]

_As an ancient people, elves have seen great change and have the perspective that can come only from watching the arc of history. After leaving the world in ancient times, they returned to a changed land, and they still struggle to reclaim their ancestral homes, most notably from terrible demons that have invaded parts of their lands. To some, the elves are objects of awe—graceful and beautiful, with immense talent and knowledge. Among themselves, however, the elves place far more importance on personal freedom than on living up to these ideals._

_[[Elf]]_
