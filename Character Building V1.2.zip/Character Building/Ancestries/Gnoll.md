---
title: "Gnoll"
icon: ":luggage:"
aliases: "Gnoll"
foundryId: Item.u5fHgtsVNN3YEQcC
tags:
  - Item
---

# Gnoll
![[systems-pf2e-icons-default-icons-alternatives-ancestries-gnoll.svg|150]]

_Powerfully-built humanoids that resemble hyenas, gnolls are cunning warriors and hunters. Their frightening visage and efficient tactics have given them an ill-starred reputation._

_[[Gnoll]]_
