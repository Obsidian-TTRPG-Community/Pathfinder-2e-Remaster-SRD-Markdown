---
title: "Vanara"
icon: ":luggage:"
aliases: "Vanara"
foundryId: Item.Hxf2fk8EhyhRajZN
tags:
  - Item
---

# Vanara
![[systems-pf2e-icons-default-icons-ancestry.svg|150]]

Vanaras are inquisitive and mischievous monkey-like humanoids with short, soft fur, expressive eyes, and long, prehensile tails. Their handlike feet and agile builds serve them well in the jungle realms where most vanaras live.

[[Vanara]]
