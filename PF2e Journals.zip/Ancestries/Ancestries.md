---
title: "Ancestries"
icon: ":book:"
aliases: "Ancestries"
foundryId: Compendium.pf2e.journals.JournalEntry.45SK8rdbbxvEHfMn
tags:
  - JournalEntry
---

# Ancestries

## Table of Contents

- [[Anadi]]
- [[Android]]
- [[Automaton]]
- [[Azarketi]]
- [[Catfolk]]
- [[Conrasu]]
- [[Dwarf]]
- [[Elf]]
- [[Fetchling]]
- [[Fleshwarp]]
- [[Ghoran]]
- [[Gnoll]]
- [[Gnome]]
- [[Goblin]]
- [[Goloma]]
- [[Grippli]]
- [[Halfling]]
- [[Hobgoblin]]
- [[Human]]
- [[Kashrishi]]
- [[Kitsune]]
- [[Kobold]]
- [[Leshy]]
- [[Lizardfolk]]
- [[Nagaji]]
- [[Orc]]
- [[Poppet]]
- [[Ratfolk]]
- [[Shisk]]
- [[Shoony]]
- [[Skeleton]]
- [[Sprite]]
- [[Strix]]
- [[Tengu]]
- [[Vanara]]
- [[Vishkanya]]
- [[Versatile Heritages]]