---
title: "Nature Domain"
icon: ":sticky-note:"
aliases: "Nature Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.wBhgIgt47v9uspp3
tags:
  - JournalEntryPage
---

# Nature Domain
**Deities** [[Angazhan]], [[Arundhat]], [[Balumbdar]], [[Barbatos]], [[Bastet]], [[Cernunnos]], [[Chamidu]], [[Cyth-V'sug]], [[Daikitsu]], [[Elven Pantheon]], [[Erastil]], [[Gendowyn]], [[Gozreh]], [[Green Man]], [[Gruhastha]], [[Halcamora]], [[Jaidi]], [[Kalekot]], [[Ketephys]], [[Lahkgya]], [[Lysianassa]], [[Matravash]], [[Mazludeh]], [[Mother Vulture]], [[Nhimbaloth]], [[Osiris]], [[Ra]], [[Selket]], [[Stag Mother of the Forest of Stones]], [[Sun Wukong]], [[Tanagaar]], [[The Green Mother]], [[Treerazer]], [[Xhamen-Dor]], [[Ylimancha]], [[Zevgavizeb]]

**Domain Spell** _[[Vibrant Thorns]]_; **Advanced Domain Spell** _[[Nature's Bounty]]_

You hold power over animals and plants.