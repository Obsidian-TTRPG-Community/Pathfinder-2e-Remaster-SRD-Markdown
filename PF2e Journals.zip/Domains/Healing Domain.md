---
title: "Healing Domain"
icon: ":sticky-note:"
aliases: "Healing Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.A7vErdGAweYsFcW8
tags:
  - JournalEntryPage
---

# Healing Domain
**Deities** [[Arundhat]], [[Atreia]], [[Bolka]], [[Chamidu]], [[Green Man]], [[Isis]], [[Korada]], [[Osiris]], [[Pharasma]], [[Qi Zhong]], [[Sarenrae]], [[Sekhmet]], [[Selket]], [[Shei]], [[Stag Mother of the Forest of Stones]], [[The Prismatic Ray]], [[Tlehar]], [[Uvuko]], [[Wards of the Pharaoh]]

**Domain Spell** _[[Healer's Blessing]]_; **Advanced Domain Spell** _[[Rebuke Death]]_

Your healing magic is particularly potent.