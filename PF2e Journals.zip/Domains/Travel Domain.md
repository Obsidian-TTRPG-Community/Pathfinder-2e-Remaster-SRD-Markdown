---
title: "Travel Domain"
icon: ":sticky-note:"
aliases: "Travel Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.bTujFcUut9RX4GCy
tags:
  - JournalEntryPage
---

# Travel Domain
**Deities** [[Abadar]], [[Apsu]], [[Barbatos]], [[Count Ranalc]], [[Desna]], [[Dranngvit]], [[Gozreh]], [[Gruhastha]], [[Hanspur]], [[Hei Feng]], [[Jaidz]], [[Kelizandri]], [[Kofusachi]], [[Matravash]], [[Ng]], [[Nocticula]], [[Ranginori]], [[The Path of the Heavens]], [[The Prismatic Ray]], [[Wadjet]], [[Ylimancha]], [[Yog-Sothoth]]

**Domain Spell** _[[Agile Feet]]_; **Advanced Domain Spell** _[[Traveler's Transit]]_

You have power over movement and journeys.