---
title: "Luck Domain"
icon: ":sticky-note:"
aliases: "Luck Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.L11XsA5G89xVKlDw
tags:
  - JournalEntryPage
---

# Luck Domain
**Deities** [[Bes]], [[Desna]], [[Gendowyn]], [[Halcamora]], [[Irez]], [[Kofusachi]], [[Lao Shu Po]], [[Nivi Rhombodazzle]]

**Domain Spell** _[[Bit of Luck]]_; **Advanced Domain Spell** _[[Lucky Break]]_

You're unnaturally lucky and keep out of harm's way.