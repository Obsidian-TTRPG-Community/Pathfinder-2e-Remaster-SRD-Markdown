---
title: "Soul Domain"
icon: ":sticky-note:"
aliases: "Soul Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.rtobUemb6vF2Yu3Y
tags:
  - JournalEntryPage
---

# Soul Domain
**Deities** [[Alglenweis]], [[Anubis]], [[Ashava]], [[Charon]], [[Luhar]], [[Pharasma]], [[Ravithra]], [[Tsukiyo]], [[Zyphus]]

**Domain Spell** _[[Eject Soul]]_; **Advanced Domain Spell** _[[Ectoplasmic Interstice]]_

You wield power over the spiritual.