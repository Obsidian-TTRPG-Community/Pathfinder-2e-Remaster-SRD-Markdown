---
title: "Delirium Domain"
icon: ":sticky-note:"
aliases: "Delirium Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.tuThzOCvMLbRVba8
tags:
  - JournalEntryPage
---

# Delirium Domain
**Deities** [[Narriseminek]], [[Nhimbaloth]], [[Shyka]], [[Sivanah]], [[The Lantern King]], [[Tsukiyo]], [[Zura]]

**Domain Spell** _[[Hyperfocus]]_; **Advanced Domain Spell** _[[Ephemeral Hazards]]_

You can bring about hallucinations and restlessness.