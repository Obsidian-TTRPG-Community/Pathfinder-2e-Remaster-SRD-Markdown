---
title: "Glyph Domain"
icon: ":sticky-note:"
aliases: "Glyph Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.9g1dNytABTpmmGkG
tags:
  - JournalEntryPage
---

# Glyph Domain
**Deities** [[Asmodeus]], [[Dwarven Pantheon]], [[Eritrice]], [[Gruhastha]], [[Hastur]], [[Imot]], [[Irez]], [[Lady Jingxi]], [[Lissala]], [[Magdh]], [[Magrim]], [[Mephistopheles]], [[Nalinivati]], [[Nethys]], [[Pillars of Knowledge]], [[Sivanah]], [[Thoth]], [[Valmallos]], [[Wards of the Pharaoh]], [[Winlas]], [[Ydajisk]]

**Domain Spell** _[[Redact]]_; **Advanced Domain Spell** _[[Ghostly Transcription]]_

You wield power over written words and symbols.