---
title: "Zeal Domain"
icon: ":sticky-note:"
aliases: "Zeal Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.DI3MYGIK8iEycanU
tags:
  - JournalEntryPage
---

# Zeal Domain
**Deities** [[Achaekek]], [[Angradd]], [[Baphomet]], [[Belial]], [[Cernunnos]], [[Chaldira]], [[Chohar]], [[Dagon]], [[Dahak]], [[Diomazul]], [[Eiseth]], [[General Susumu]], [[Gorum]], [[Gyronna]], [[Iomedae]], [[Kostchtchie]], [[Kurgess]], [[Lubaiko]], [[Luhar]], [[Milani]], [[Ragathiel]], [[Rovagug]], [[Tanagaar]], [[The Godclaw]], [[Tlehar]], [[Vildeis]], [[Wadjet]], [[Ydersius]], [[Ymeri]]

**Domain Spell** _[[Weapon Surge]]_; **Advanced Domain Spell** _[[Zeal for Battle]]_

Your inner fire increases your combat prowess.