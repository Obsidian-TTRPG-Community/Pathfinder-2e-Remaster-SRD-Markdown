---
title: "Introspection Domain"
icon: ":sticky-note:"
aliases: "Introspection Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.qjnUXickBOBDBu2N
tags:
  - JournalEntryPage
---

# Introspection Domain
**Deities** [[Narakaas]]

**Domain Spell** _[[Guided Introspection]]_; **Advanced Domain Spell** _[[Confront Selves]]_

You guide others in examining their lives, emotions, and motivations to ultimately become a truer version of themselves—a difficult and often painful process.