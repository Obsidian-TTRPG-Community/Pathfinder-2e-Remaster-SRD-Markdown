---
title: "Freedom Domain"
icon: ":sticky-note:"
aliases: "Freedom Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.5MjSsuKOLBoiL8FB
tags:
  - JournalEntryPage
---

# Freedom Domain
**Deities** [[Arazni]], [[Arshea]], [[Black Butterfly]], [[Casandalee]], [[Cayden Cailean]], [[Cosmic Caravan]], [[Falayna]], [[Kazutal]], [[Milani]], [[Narriseminek]], [[Ranginori]], [[Saloc]], [[Shei]], [[Walkena]]

**Domain Spell** _[[Unimpeded Stride]]_; **Advanced Domain Spell** _[[Word of Freedom]]_

You liberate yourself and others from shackles and constraints.