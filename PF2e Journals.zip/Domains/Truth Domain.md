---
title: "Truth Domain"
icon: ":sticky-note:"
aliases: "Truth Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.lgsJz7mZ1OTe340e
tags:
  - JournalEntryPage
---

# Truth Domain
**Deities** [[Dammerich]], [[Erecura]], [[Followers of Fate]], [[Geryon]], [[Gruhastha]], [[Iomedae]], [[Irori]], [[Kols]], [[Kurgess]], [[Ma'at]], [[Magdh]], [[Mahathallah]], [[Monad]], [[Pillars of Knowledge]], [[Ravithra]], [[Sarenrae]], [[Zohls]]

**Domain Spell** _[[Word of Truth]]_; **Advanced Domain Spell** _[[Glimpse the Truth]]_

You pierce lies and discover the truth.