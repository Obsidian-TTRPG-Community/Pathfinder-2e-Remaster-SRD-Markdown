---
title: "Earth Domain"
icon: ":sticky-note:"
aliases: "Earth Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.zkiLWWYzzqoxmN2J
tags:
  - JournalEntryPage
---

# Earth Domain
**Deities** [[Abadar]], [[Ashukharma]], [[Ayrzul]], [[Bes]], [[Brigh]], [[Diomazul]], [[Droskar]], [[Erastil]], [[Fumeiyoshi]], [[Gendowyn]], [[Imbrex]], [[Nivi Rhombodazzle]], [[Rovagug]], [[Sairazul]], [[Soralyon]], [[Torag]], [[Trelmarixian]], [[Yamatsumi]], [[Yuelral]]

**Domain Spell** _[[Hurtling Stone]]_; **Advanced Domain Spell** _[[Localized Quake]]_

You control soil and stone.