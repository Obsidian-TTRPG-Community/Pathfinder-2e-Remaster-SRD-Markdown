---
title: "Duty Domain"
icon: ":sticky-note:"
aliases: "Duty Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.uGQKjk2w4whzomky
tags:
  - JournalEntryPage
---

# Duty Domain
**Deities** [[Abadar]], [[Adanye]], [[Asmodeus]], [[Chohar]], [[Dammerich]], [[Dispater]], [[Droskar]], [[Dwarven Pantheon]], [[Erastil]], [[Iomedae]], [[Kols]], [[Magrim]], [[Moloch]], [[Ragathiel]], [[Shizuru]], [[Tanagaar]], [[The Godclaw]], [[Torag]], [[Trudd]], [[Vildeis]], [[Yaezhing]]

**Domain Spell** _[[Oathkeeper's Insignia]]_; **Advanced Domain Spell** _[[Dutiful Challenge]]_

You defend oaths and carry out your divine missions with great dedication.