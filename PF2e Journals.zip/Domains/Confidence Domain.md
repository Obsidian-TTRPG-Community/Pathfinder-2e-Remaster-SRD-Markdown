---
title: "Confidence Domain"
icon: ":sticky-note:"
aliases: "Confidence Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.flmxRzGxN2rRNyxZ
tags:
  - JournalEntryPage
---

# Confidence Domain
**Deities** [[Adanye]], [[Arazni]], [[Arshea]], [[Asmodeus]], [[Bolka]], [[Chaldira]], [[Count Ranalc]], [[Dispater]], [[Eritrice]], [[General Susumu]], [[Gorum]], [[Grundinnar]], [[Iomedae]], [[Jaidz]], [[Nivi Rhombodazzle]], [[Ragdya]], [[Raumya]], [[Sturovenen]], [[Thamir]], [[Trudd]]

**Domain Spell** _[[Veil of Confidence]]_; **Advanced Domain Spell** _[[Delusional Pride]]_

You overcome your fear and project pride.