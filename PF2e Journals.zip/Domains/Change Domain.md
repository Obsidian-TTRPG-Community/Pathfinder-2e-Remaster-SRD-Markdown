---
title: "Change Domain"
icon: ":sticky-note:"
aliases: "Change Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.7xrNAgAnBqBgE3yM
tags:
  - JournalEntryPage
---

# Change Domain
**Deities** [[Alseta]], [[Belial]], [[Cyth-V'sug]], [[Dagon]], [[Daikitsu]], [[Grandmother Spider]], [[Irori]], [[Korada]], [[Lamashtu]], [[Lubaiko]], [[Lymnieris]], [[Milani]], [[Mother Vulture]], [[Narakaas]], [[Nocticula]], [[Osiris]], [[Saloc]], [[The Lantern King]], [[Tlehar]], [[Tsukiyo]], [[Uvuko]], [[Xhamen-Dor]], [[Ydajisk]]

**Domain Spell** _[[Adapt Self]]_; **Advanced Domain Spell** _[[Adaptive Ablation]]_

You can restructure the physical and metaphysical.