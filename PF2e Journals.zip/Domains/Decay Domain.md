---
title: "Decay Domain"
icon: ":sticky-note:"
aliases: "Decay Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.cAxBEZsej32riaY5
tags:
  - JournalEntryPage
---

# Decay Domain
**Deities** [[Apollyon]], [[Azathoth]], [[Cyth-V'sug]], [[Ghlaunder]], [[Groetus]], [[Kerkamoth]], [[Mother Vulture]], [[Nhimbaloth]], [[Shyka]], [[The Green Mother]], [[Trelmarixian]], [[Urgathoa]], [[Xhamen-Dor]]

**Domain Spell** _[[Withering Grasp]]_; **Advanced Domain Spell** _[[Fallow Field]]_

You have the power to spoil and deteriorate matter.