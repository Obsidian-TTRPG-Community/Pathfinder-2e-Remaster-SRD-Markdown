---
title: "Cities Domain"
icon: ":sticky-note:"
aliases: "Cities Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.QSk78hQR3zskMlq2
tags:
  - JournalEntryPage
---

# Cities Domain
**Deities** [[Abadar]], [[Cayden Cailean]], [[Chohar]], [[Dispater]], [[Findeladlara]], [[Folgrit]], [[Kazutal]], [[Luhar]], [[Matravash]], [[Mazludeh]], [[Tlehar]], [[Zohls]]

**Domain Spell** _[[Face in the Crowd]]_; **Advanced Domain Spell** _[[Pulse of Civilization]]_

You have powers over urban environments and denizens.