---
title: "Dreams Domain"
icon: ":sticky-note:"
aliases: "Dreams Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.0wCEUwABKPdKPj8e
tags:
  - JournalEntryPage
---

# Dreams Domain
**Deities** [[Desna]], [[Imbrex]], [[Luhar]], [[Xhamen-Dor]]

**Domain Spell** _[[Sweet Dream]]_; **Advanced Domain Spell** _[[Dreamer's Call]]_

You have the power to enter and manipulate dreams.