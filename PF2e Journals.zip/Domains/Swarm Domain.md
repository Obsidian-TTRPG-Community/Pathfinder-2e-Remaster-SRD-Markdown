---
title: "Swarm Domain"
icon: ":sticky-note:"
aliases: "Swarm Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.rd0jQwvTK4jpv95o
tags:
  - JournalEntryPage
---

# Swarm Domain
**Deities** [[Apollyon]], [[Ghlaunder]], [[Halcamora]], [[Lahkgya]], [[Lao Shu Po]], [[Pazuzu]], [[Rovagug]], [[Urgathoa]]

**Domain Spell** _[[Swarmsense]]_; **Advanced Domain Spell** _[[Swarm Form]]_

You exert control over masses of creatures.