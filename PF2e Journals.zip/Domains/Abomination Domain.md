---
title: "Abomination Domain"
icon: ":sticky-note:"
aliases: "Abomination Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.qMS6QepvY7UQQjcr
tags:
  - JournalEntryPage
---

# Abomination Domain
**Deities** [[Nhimbaloth]]

**Domain Spell** _[[Lift Nature's Caul]]_; **Advanced Domain Spell** _[[Fearful Feast]]_

You seek to instill abhorrence and horror in those around you.