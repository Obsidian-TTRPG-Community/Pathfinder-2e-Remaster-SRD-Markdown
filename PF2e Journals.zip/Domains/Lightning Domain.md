---
title: "Lightning Domain"
icon: ":sticky-note:"
aliases: "Lightning Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.Kca7UPuMm44tOo9n
tags:
  - JournalEntryPage
---

# Lightning Domain
**Deities** [[Casandalee]], [[Cernunnos]], [[Chamidu]], [[Gozreh]], [[Hei Feng]], [[Lubaiko]], [[Ranginori]]

**Domain Spell** _[[Charged Javelin]]_; **Advanced Domain Spell** _[[Bottle the Storm]]_

You control electricity, thunder, and storms.