---
title: "Darkness Domain"
icon: ":sticky-note:"
aliases: "Darkness Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.CM9ZqWwl7myKn2X1
tags:
  - JournalEntryPage
---

# Darkness Domain
**Deities** [[Ahriman]], [[Ardad Lili]], [[Ashava]], [[Cosmic Caravan]], [[Count Ranalc]], [[Grandmother Spider]], [[Groetus]], [[Kalekot]], [[Kerkamoth]], [[Ketephys]], [[Lao Shu Po]], [[Luhar]], [[Nocticula]], [[Nyarlathotep (Haunter in the Dark)]], [[Nyarlathotep (The Crawling Chaos)]], [[Pulura]], [[Tanagaar]], [[Zon-Kuthon]]

**Domain Spell** _[[Cloak of Shadow]]_; **Advanced Domain Spell** _[[Darkened Eyes]]_

You operate in the darkness and take away the light.