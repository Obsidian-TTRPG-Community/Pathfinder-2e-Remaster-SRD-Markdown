---
title: "Trickery Domain"
icon: ":sticky-note:"
aliases: "Trickery Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.xJtbGqoz3BcCjUik
tags:
  - JournalEntryPage
---

# Trickery Domain
**Deities** [[Achaekek]], [[Ahriman]], [[Asmodeus]], [[Baalzebul]], [[Bastet]], [[Belial]], [[Besmara]], [[Calistria]], [[Chaldira]], [[Dhalavei]], [[Droskar]], [[Erecura]], [[Grandmother Spider]], [[Lahkgya]], [[Lamashtu]], [[Lao Shu Po]], [[Mahathallah]], [[Nivi Rhombodazzle]], [[Norgorber]], [[Nyarlathotep (Haunter in the Dark)]], [[Nyarlathotep (The Crawling Chaos)]], [[Pazuzu]], [[Shax]], [[Sifkesh]], [[Sivanah]], [[Sun Wukong]], [[Thamir]], [[The Lantern King]], [[Yaezhing]], [[Ydajisk]]

**Domain Spell** _[[Sudden Shift]]_; **Advanced Domain Spell** _[[Trickster's Twin]]_

You deceive others and cause mischief.