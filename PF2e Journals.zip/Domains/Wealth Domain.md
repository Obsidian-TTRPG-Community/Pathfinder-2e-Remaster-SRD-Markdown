---
title: "Wealth Domain"
icon: ":sticky-note:"
aliases: "Wealth Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.mJBp4KIszuqrmnp5
tags:
  - JournalEntryPage
---

# Wealth Domain
**Deities** [[Abadar]], [[Besmara]], [[Dwarven Pantheon]], [[Erastil]], [[Falayna]], [[Hanspur]], [[Hastur]], [[Kofusachi]], [[Mammon]], [[Nivi Rhombodazzle]], [[Norgorber]], [[Raumya]], [[Sairazul]], [[Thamir]]

**Domain Spell** _[[Appearance of Wealth]]_; **Advanced Domain Spell** _[[Precious Metals]]_

You hold power over wealth, trade, and treasure.