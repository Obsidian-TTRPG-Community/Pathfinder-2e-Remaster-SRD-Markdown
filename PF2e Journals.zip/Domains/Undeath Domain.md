---
title: "Undeath Domain"
icon: ":sticky-note:"
aliases: "Undeath Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.RIlgBuWGfHC1rzYu
tags:
  - JournalEntryPage
---

# Undeath Domain
**Deities** [[Fumeiyoshi]], [[Kabriri]], [[Mahathallah]], [[Nhimbaloth]], [[Urgathoa]], [[Zura]], [[Zyphus]]

**Domain Spell** _[[Touch of Undeath]]_; **Advanced Domain Spell** _[[Malignant Sustenance]]_

Your magic carries close ties to the undead.