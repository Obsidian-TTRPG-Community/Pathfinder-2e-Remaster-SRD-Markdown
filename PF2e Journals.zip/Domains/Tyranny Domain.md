---
title: "Tyranny Domain"
icon: ":sticky-note:"
aliases: "Tyranny Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.T0JHj79aGphlZ4Mt
tags:
  - JournalEntryPage
---

# Tyranny Domain
**Deities** [[Angazhan]], [[Asmodeus]], [[Barbatos]], [[Dispater]], [[Droskar]], [[Gogunta]], [[Mephistopheles]], [[Pazuzu]], [[The Godclaw]], [[Treerazer]], [[Walkena]]

**Domain Spell** _[[Touch of Obedience]]_; **Advanced Domain Spell** _[[Commanding Lash]]_

You wield power to rule and enslave others.