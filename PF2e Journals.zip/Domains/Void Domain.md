---
title: "Void Domain"
icon: ":sticky-note:"
aliases: "Void Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.xLxrtbsj4acqgsyC
tags:
  - JournalEntryPage
---

# Void Domain
**Deities** [[Azathoth]], [[Black Butterfly]], [[Cosmic Caravan]], [[Desna]], [[Groetus]], [[Hastur]], [[Kerkamoth]], [[Monad]], [[Nhimbaloth]], [[Rovagug]], [[The Path of the Heavens]], [[Yog-Sothoth]], [[Zon-Kuthon]]

**Domain Spell** _[[Empty Inside]]_; **Advanced Domain Spell** _[[Door to Beyond]]_

You draw power from emptiness.