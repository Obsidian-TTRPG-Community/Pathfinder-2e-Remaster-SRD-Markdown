---
title: "Water Domain"
icon: ":sticky-note:"
aliases: "Water Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.U8WVR6EDfmUaMCbu
tags:
  - JournalEntryPage
---

# Water Domain
**Deities** [[Besmara]], [[Charon]], [[Dagon]], [[Diomazul]], [[Geryon]], [[Gogunta]], [[Gozreh]], [[Hanspur]], [[Hei Feng]], [[Kelizandri]], [[Lady Nanbyo]], [[Lysianassa]], [[Matravash]], [[Naderi]], [[Ragadahn]], [[Sobek]], [[Wadjet]], [[Ylimancha]]

**Domain Spell** _[[Tidal Surge]]_; **Advanced Domain Spell** _[[Downpour]]_

You control water and bodies of water.