---
title: "Magic Domain"
icon: ":sticky-note:"
aliases: "Magic Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.DS95vr2zmTsjsMhU
tags:
  - JournalEntryPage
---

# Magic Domain
**Deities** [[Abraxas]], [[Alseta]], [[Arundhat]], [[Baalzebul]], [[Barbatos]], [[Elven Pantheon]], [[Irez]], [[Isis]], [[Korada]], [[Lissala]], [[Nalinivati]], [[Nethys]], [[Ng]], [[Nyarlathotep (The Crawling Chaos)]], [[Qi Zhong]], [[Selket]], [[Sivanah]], [[Soralyon]], [[Urgathoa]], [[Valmallos]], [[Wards of the Pharaoh]], [[Yuelral]]

**Domain Spell** _[[Magic's Vessel]]_; **Advanced Domain Spell** _[[Mystic Beacon]]_

You perform the unexpected and inexplicable.