---
title: "Death Domain"
icon: ":sticky-note:"
aliases: "Death Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.798PFdS8FmefcOl0
tags:
  - JournalEntryPage
---

# Death Domain
**Deities** [[Achaekek]], [[Ahriman]], [[Barzahk]], [[Charon]], [[Dammerich]], [[Hanspur]], [[Imot]], [[Kalekot]], [[Magrim]], [[Mother Vulture]], [[Naderi]], [[Narakaas]], [[Norgorber]], [[Pharasma]], [[Saloc]], [[Shax]], [[Yaezhing]], [[Zyphus]]

**Domain Spell** _[[Death's Call]]_; **Advanced Domain Spell** _[[Eradicate Undeath]]_

You have the power to end lives and destroy undead.