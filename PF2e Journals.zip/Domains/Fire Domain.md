---
title: "Fire Domain"
icon: ":sticky-note:"
aliases: "Fire Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.egSErNozlL3HRK1y
tags:
  - JournalEntryPage
---

# Fire Domain
**Deities** [[Adanye]], [[Angradd]], [[Asmodeus]], [[Atreia]], [[Brigh]], [[Chohar]], [[Dahak]], [[Droskar]], [[Lady Nanbyo]], [[Lubaiko]], [[Moloch]], [[Nurgal]], [[Ra]], [[Ragathiel]], [[Sarenrae]], [[Szuriel]], [[Yamatsumi]], [[Ymeri]]

**Domain Spell** _[[Fire Ray]]_; **Advanced Domain Spell** _[[Flame Barrier]]_

You control flame.