---
title: "Moon Domain"
icon: ":sticky-note:"
aliases: "Moon Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.Y3DFBCWiM9GBIlfl
tags:
  - JournalEntryPage
---

# Moon Domain
**Deities** [[Ashava]], [[Cosmic Caravan]], [[Desna]], [[Findeladlara]], [[Horus]], [[Ketephys]], [[The Path of the Heavens]], [[The Prismatic Ray]], [[Thoth]], [[Tsukiyo]]

**Domain Spell** _[[Moonbeam]]_; **Advanced Domain Spell** _[[Touch of the Moon]]_

You command powers associated with the moon.