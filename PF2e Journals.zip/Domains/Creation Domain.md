---
title: "Creation Domain"
icon: ":sticky-note:"
aliases: "Creation Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.ydbCjJ9PPmRzZhDN
tags:
  - JournalEntryPage
---

# Creation Domain
**Deities** [[Alglenweis]], [[Apsu]], [[Ardad Lili]], [[Brigh]], [[Casandalee]], [[Daikitsu]], [[Doloras]], [[Dwarven Pantheon]], [[Elven Pantheon]], [[Falayna]], [[Findeladlara]], [[Grandmother Spider]], [[Lady Jingxi]], [[Likha]], [[Mammon]], [[Monad]], [[Nocticula]], [[Otolmens]], [[Pillars of Knowledge]], [[Shelyn]], [[Soralyon]], [[The Prismatic Ray]], [[Tlehar]], [[Torag]], [[Uvuko]], [[Yuelral]]

**Domain Spell** _[[Creative Splash]]_; **Advanced Domain Spell** _[[Artistic Flourish]]_

You have divine abilities related to crafting and art.