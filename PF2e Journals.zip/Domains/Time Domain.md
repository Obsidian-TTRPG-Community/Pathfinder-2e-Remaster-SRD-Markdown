---
title: "Time Domain"
icon: ":sticky-note:"
aliases: "Time Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.3P0NWwP3s7bIiidH
tags:
  - JournalEntryPage
---

# Time Domain
**Deities** [[Alseta]], [[Brigh]], [[Pharasma]], [[Pillars of Knowledge]], [[Ra]], [[Shyka]], [[Yog-Sothoth]]

**Domain Spell** _[[Delay Consequence]]_; **Advanced Domain Spell** _[[Stasis]]_

You reign over the flow of time.