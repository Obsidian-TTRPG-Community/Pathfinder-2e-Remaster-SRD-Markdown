---
title: "Plague Domain"
icon: ":sticky-note:"
aliases: "Plague Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.hGoWOjdsUz16oJUm
tags:
  - JournalEntryPage
---

# Plague Domain
**Deities** [[Apollyon]], [[Cyth-V'sug]], [[Ghlaunder]], [[Lady Nanbyo]]

**Domain Spell** _[[Divine Plagues]]_; **Advanced Domain Spell** _[[Foul Miasma]]_

You wield disease and pestilence like a weapon.