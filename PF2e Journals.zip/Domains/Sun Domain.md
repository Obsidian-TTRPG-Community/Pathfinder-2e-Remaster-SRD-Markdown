---
title: "Sun Domain"
icon: ":sticky-note:"
aliases: "Sun Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.CkBvj5y1lAm1jnsc
tags:
  - JournalEntryPage
---

# Sun Domain
**Deities** [[Atreia]], [[Chohar]], [[Hathor]], [[Horus]], [[Jaidi]], [[Luhar]], [[Nurgal]], [[Ra]], [[Sarenrae]], [[Shizuru]], [[Sturovenen]], [[The Path of the Heavens]], [[The Prismatic Ray]], [[Tlehar]], [[Walkena]]

**Domain Spell** _[[Dazzling Flash]]_; **Advanced Domain Spell** _[[Vital Luminance]]_

You harness the power of the sun and other light sources, and punish undead.