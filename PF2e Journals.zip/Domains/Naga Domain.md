---
title: "Naga Domain"
icon: ":sticky-note:"
aliases: "Naga Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.QzsUe3Rt3SifTQvb
tags:
  - JournalEntryPage
---

# Naga Domain
**Deities** [[Ravithra]]

**Domain Spell** _[[Split the Tongue]]_; **Advanced Domain Spell** _[[Ordained Purpose]]_

Like the serpentine nagas, you're in tune with cosmic forces that Ravithra once controlled.