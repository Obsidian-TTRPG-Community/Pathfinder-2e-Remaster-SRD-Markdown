---
title: "Ambition Domain"
icon: ":sticky-note:"
aliases: "Ambition Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.yaMJsfYZmWJLqbFE
tags:
  - JournalEntryPage
---

# Ambition Domain
**Deities** [[Baalzebul]], [[Casandalee]], [[Eiseth]], [[Fumeiyoshi]], [[Gyronna]], [[Lubaiko]], [[Mammon]], [[Ravithra]], [[Shax]], [[Szuriel]], [[Thamir]], [[Ydersius]], [[Zohls]], [[Zon-Kuthon]]

**Domain Spell** _[[Ignite Ambition]]_; **Advanced Domain Spell** _[[Competitive Edge]]_

You strive to keep up with and outpace the competition.