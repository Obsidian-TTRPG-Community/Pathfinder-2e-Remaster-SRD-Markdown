---
title: "Knowledge Domain"
icon: ":sticky-note:"
aliases: "Knowledge Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.0GwpYEjCHWyfQvgg
tags:
  - JournalEntryPage
---

# Knowledge Domain
**Deities** [[Abraxas]], [[Andoletta]], [[Barzahk]], [[Brigh]], [[Casandalee]], [[Charon]], [[Dhalavei]], [[Dranngvit]], [[Eritrice]], [[Followers of Fate]], [[Gruhastha]], [[Irori]], [[Kabriri]], [[Kols]], [[Lady Jingxi]], [[Likha]], [[Ma'at]], [[Magdh]], [[Mazludeh]], [[Mephistopheles]], [[Monad]], [[Narriseminek]], [[Nethys]], [[Ng]], [[Nyarlathotep (Haunter in the Dark)]], [[Nyarlathotep (The Crawling Chaos)]], [[Otolmens]], [[Pharasma]], [[Pillars of Knowledge]], [[Qi Zhong]], [[Raumya]], [[Saloc]], [[The Lost Prince]], [[Valmallos]], [[Wards of the Pharaoh]], [[Winlas]], [[Ydajisk]], [[Yog-Sothoth]], [[Yuelral]], [[Zohls]]

**Domain Spell** _[[Scholarly Recollection]]_; **Advanced Domain Spell** _[[Know the Enemy]]_

You receive divine insights.