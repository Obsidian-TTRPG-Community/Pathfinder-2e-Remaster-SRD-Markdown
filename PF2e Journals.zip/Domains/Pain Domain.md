---
title: "Pain Domain"
icon: ":sticky-note:"
aliases: "Pain Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.FtW1gtbHgO0KofPl
tags:
  - JournalEntryPage
---

# Pain Domain
**Deities** [[Arazni]], [[Calistria]], [[Doloras]], [[Gyronna]], [[Narakaas]], [[Shax]], [[Sifkesh]], [[Stag Mother of the Forest of Stones]], [[Vildeis]], [[Yaezhing]], [[Zon-Kuthon]]

**Domain Spell** _[[Savor the Sting]]_; **Advanced Domain Spell** _[[Retributive Pain]]_

You punish those who displease you with the sharp sting of pain.