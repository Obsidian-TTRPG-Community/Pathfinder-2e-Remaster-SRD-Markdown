---
title: "Sorrow Domain"
icon: ":sticky-note:"
aliases: "Sorrow Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.5TqEbLR9QT3gJGe3
tags:
  - JournalEntryPage
---

# Sorrow Domain
**Deities** [[Andoletta]], [[Arazni]], [[Count Ranalc]], [[Doloras]], [[Likha]], [[Naderi]], [[Narakaas]], [[Pulura]], [[Ravithra]], [[Shizuru]], [[Sifkesh]], [[The Lost Prince]], [[Vildeis]], [[Zyphus]]

**Domain Spell** _[[Lament]]_; **Advanced Domain Spell** _[[Overflowing Sorrow]]_

You have a painful connection to melancholy and sadness.