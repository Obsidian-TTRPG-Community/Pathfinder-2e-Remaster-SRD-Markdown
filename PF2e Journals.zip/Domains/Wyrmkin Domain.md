---
title: "Wyrmkin Domain"
icon: ":sticky-note:"
aliases: "Wyrmkin Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.nuywscaiVGXLQpZ1
tags:
  - JournalEntryPage
---

# Wyrmkin Domain
**Deities** [[Abraxas]], [[Apsu]], [[Ardad Lili]], [[Dahak]], [[Geryon]], [[Kalekot]], [[Nalinivati]], [[Ragadahn]], [[Sobek]], [[Uvuko]], [[Zevgavizeb]]

**Domain Spell** _[[Draconic Barrage]]_; **Advanced Domain Spell** _[[Roar of the Wyrm]]_

You draw on the power of dragons, linnorms, and other powerful reptilian creatures.