---
title: "Repose Domain"
icon: ":sticky-note:"
aliases: "Repose Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.CbsAiY68e8n5vVVN
tags:
  - JournalEntryPage
---

# Repose Domain
**Deities** [[Adanye]], [[Ashava]], [[Ashukharma]], [[Doloras]], [[Folgrit]], [[Lady Jingxi]], [[Lymnieris]], [[Sarenrae]], [[Shelyn]], [[The Lost Prince]], [[Tsukiyo]]

**Domain Spell** _[[Share Burden]]_; **Advanced Domain Spell** _[[Font of Serenity]]_

You ease mental burdens.