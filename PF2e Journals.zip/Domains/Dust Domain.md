---
title: "Dust Domain"
icon: ":sticky-note:"
aliases: "Dust Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.6qTjtFWaBO5b60zJ
tags:
  - JournalEntryPage
---

# Dust Domain
**Deities** [[Hshurha]], [[Nurgal]], [[Trelmarixian]], [[Ymeri]]

**Domain Spell** _[[Parch]]_; **Advanced Domain Spell** _[[Dust Storm]]_

You have the power to dry and crumble what opposes you.