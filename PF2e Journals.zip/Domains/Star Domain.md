---
title: "Star Domain"
icon: ":sticky-note:"
aliases: "Star Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.6bDpXy7pQdGrd2og
tags:
  - JournalEntryPage
---

# Star Domain
**Deities** [[Black Butterfly]], [[Cosmic Caravan]], [[Desna]], [[Findeladlara]], [[Luhar]], [[Ma'at]], [[Pulura]], [[The Path of the Heavens]]

**Domain Spell** _[[Zenith Star]]_; **Advanced Domain Spell** _[[Asterism]]_

You command the power of the stars.