---
title: "Destruction Domain"
icon: ":sticky-note:"
aliases: "Destruction Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.AOQZjqgfafqqtHOB
tags:
  - JournalEntryPage
---

# Destruction Domain
**Deities** [[Abraxas]], [[Ahriman]], [[Angazhan]], [[Ayrzul]], [[Azathoth]], [[Besmara]], [[Dagon]], [[Dahak]], [[Dhalavei]], [[Diomazul]], [[Eiseth]], [[Fumeiyoshi]], [[General Susumu]], [[Gorum]], [[Groetus]], [[Hei Feng]], [[Hshurha]], [[Imot]], [[Kelizandri]], [[Kerkamoth]], [[Kostchtchie]], [[Lady Nanbyo]], [[Lubaiko]], [[Milani]], [[Moloch]], [[Nethys]], [[Nurgal]], [[Ragadahn]], [[Ragathiel]], [[Rovagug]], [[Sekhmet]], [[Szuriel]], [[Treerazer]], [[Ymeri]], [[Zevgavizeb]], [[Zon-Kuthon]]

**Domain Spell** _[[Cry of Destruction]]_; **Advanced Domain Spell** _[[Destructive Aura]]_

You are a conduit for divine devastation.