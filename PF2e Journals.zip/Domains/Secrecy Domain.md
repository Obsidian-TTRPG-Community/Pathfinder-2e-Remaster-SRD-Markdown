---
title: "Secrecy Domain"
icon: ":sticky-note:"
aliases: "Secrecy Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.S1gyomjojgtCdxc3
tags:
  - JournalEntryPage
---

# Secrecy Domain
**Deities** [[Ayrzul]], [[Baphomet]], [[Black Butterfly]], [[Calistria]], [[Dhalavei]], [[Erecura]], [[Hastur]], [[Kalekot]], [[Ketephys]], [[Mephistopheles]], [[Ng]], [[Norgorber]], [[Pillars of Knowledge]], [[Sivanah]]

**Domain Spell** _[[Forced Quiet]]_; **Advanced Domain Spell** _[[Safeguard Secret]]_

You protect secrets and keep them hidden.