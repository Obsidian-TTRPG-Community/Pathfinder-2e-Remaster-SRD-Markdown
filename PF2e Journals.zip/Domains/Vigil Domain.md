---
title: "Vigil Domain"
icon: ":sticky-note:"
aliases: "Vigil Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.StXN6IHR6evRaeXF
tags:
  - JournalEntryPage
---

# Vigil Domain
**Deities** [[Anubis]], [[Barzahk]], [[Chohar]], [[Dammerich]], [[Dranngvit]], [[Irori]], [[Kabriri]], [[Pharasma]], [[Ragadahn]], [[Shizuru]], [[The Lost Prince]], [[Tlehar]], [[Winlas]]

**Domain Spell** _[[Object Memory]]_; **Advanced Domain Spell** _[[Remember the Lost]]_

You watch over those long passed and guard their secrets.