---
title: "Protection Domain"
icon: ":sticky-note:"
aliases: "Protection Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.Dx47K8wpx8KZUa9S
tags:
  - JournalEntryPage
---

# Protection Domain
**Deities** [[Adanye]], [[Alseta]], [[Andoletta]], [[Angradd]], [[Anubis]], [[Apsu]], [[Arazni]], [[Arundhat]], [[Ashukharma]], [[Atreia]], [[Balumbdar]], [[Bastet]], [[Bes]], [[Dwarven Pantheon]], [[Folgrit]], [[Green Man]], [[Grundinnar]], [[Horus]], [[Jaidz]], [[Kazutal]], [[Korada]], [[Lymnieris]], [[Ma'at]], [[Nethys]], [[Qi Zhong]], [[Selket]], [[Shelyn]], [[Sobek]], [[Soralyon]], [[The Godclaw]], [[The Prismatic Ray]], [[Torag]], [[Trudd]], [[Wadjet]], [[Wards of the Pharaoh]], [[Winlas]]

**Domain Spell** _[[Protector's Sacrifice]]_; **Advanced Domain Spell** _[[Protector's Sphere]]_

You ward yourself and others.