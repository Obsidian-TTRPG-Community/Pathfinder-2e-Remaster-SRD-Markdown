---
title: "Perfection Domain"
icon: ":sticky-note:"
aliases: "Perfection Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.Czi3XXuNOSE7ISpd
tags:
  - JournalEntryPage
---

# Perfection Domain
**Deities** [[Arshea]], [[Balumbdar]], [[Casandalee]], [[Gruhastha]], [[Irori]], [[Mazludeh]], [[Narriseminek]], [[Otolmens]], [[Pillars of Knowledge]], [[Ragdya]], [[Shei]], [[Shizuru]], [[The Godclaw]]

**Domain Spell** _[[Perfected Mind]]_; **Advanced Domain Spell** _[[Perfected Body]]_

You strive to perfect your mind, body, and spirit.