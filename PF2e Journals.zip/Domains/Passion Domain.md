---
title: "Passion Domain"
icon: ":sticky-note:"
aliases: "Passion Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.ajCEExOaxuB4C1tY
tags:
  - JournalEntryPage
---

# Passion Domain
**Deities** [[Ardad Lili]], [[Arshea]], [[Bastet]], [[Belial]], [[Bolka]], [[Calistria]], [[Cernunnos]], [[Hathor]], [[Isis]], [[Kofusachi]], [[Likha]], [[Lymnieris]], [[Naderi]], [[Nalinivati]], [[Shelyn]], [[The Green Mother]], [[The Lantern King]], [[Tlehar]]

**Domain Spell** _[[Charming Touch]]_; **Advanced Domain Spell** _[[Captivating Adoration]]_

You evoke passion, whether as love or lust.