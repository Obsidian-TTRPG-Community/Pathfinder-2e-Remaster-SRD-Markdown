---
title: "Indulgence Domain"
icon: ":sticky-note:"
aliases: "Indulgence Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.GiuzDTtkQAgtGW6n
tags:
  - JournalEntryPage
---

# Indulgence Domain
**Deities** [[Baphomet]], [[Cayden Cailean]], [[Gogunta]], [[Halcamora]], [[Hei Feng]], [[Kabriri]], [[Lahkgya]], [[Sekhmet]], [[Sun Wukong]], [[The Green Mother]], [[Urgathoa]], [[Ydersius]], [[Zura]]

**Domain Spell** _[[Overstuff]]_; **Advanced Domain Spell** _[[Take its Course]]_

You feast mightily and can shake off the effects of overindulging.