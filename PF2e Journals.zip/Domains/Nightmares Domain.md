---
title: "Nightmares Domain"
icon: ":sticky-note:"
aliases: "Nightmares Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.R20JXF43vU5RQyUj
tags:
  - JournalEntryPage
---

# Nightmares Domain
**Deities** [[Azathoth]], [[Chamidu]], [[Groetus]], [[Gyronna]], [[Jaidz]], [[Kalekot]], [[Kelizandri]], [[Lamashtu]], [[Nyarlathotep (Haunter in the Dark)]], [[Nyarlathotep (The Crawling Chaos)]], [[Sifkesh]], [[Treerazer]], [[Trelmarixian]], [[Zura]]

**Domain Spell** _[[Waking Nightmare]]_; **Advanced Domain Spell** _[[Shared Nightmare]]_

You fill minds with horror and dread.