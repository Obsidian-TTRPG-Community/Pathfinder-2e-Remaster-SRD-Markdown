---
title: "Family Domain"
icon: ":sticky-note:"
aliases: "Family Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.SAnmegCTIqGW9S7S
tags:
  - JournalEntryPage
---

# Family Domain
**Deities** [[Adanye]], [[Andoletta]], [[Bes]], [[Bolka]], [[Chohar]], [[Daikitsu]], [[Dwarven Pantheon]], [[Erastil]], [[Findeladlara]], [[Folgrit]], [[Followers of Fate]], [[Gendowyn]], [[Grandmother Spider]], [[Grundinnar]], [[Hathor]], [[Imbrex]], [[Isis]], [[Jaidi]], [[Kazutal]], [[Lamashtu]], [[Mazludeh]], [[Nivi Rhombodazzle]], [[Sairazul]], [[Shei]], [[Shelyn]], [[Stag Mother of the Forest of Stones]], [[The Prismatic Ray]], [[Torag]], [[Walkena]], [[Wards of the Pharaoh]]

**Domain Spell** _[[Soothing Words]]_; **Advanced Domain Spell** _[[Unity]]_

You aid and protect your family and community more effectively.