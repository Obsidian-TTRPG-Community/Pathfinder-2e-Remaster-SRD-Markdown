---
title: "Cold Domain"
icon: ":sticky-note:"
aliases: "Cold Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.jq9O1tl76g2AzLOh
tags:
  - JournalEntryPage
---

# Cold Domain
**Deities** [[Alglenweis]], [[Gozreh]], [[Hshurha]], [[Kostchtchie]], [[Pulura]], [[Uvuko]], [[Yamatsumi]]

**Domain Spell** _[[Winter Bolt]]_; **Advanced Domain Spell** _[[Diamond Dust]]_

You control ice, snow, and freezing temperatures.