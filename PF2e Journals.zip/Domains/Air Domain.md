---
title: "Air Domain"
icon: ":sticky-note:"
aliases: "Air Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.T2y0vuYibZCL7CH0
tags:
  - JournalEntryPage
---

# Air Domain
**Deities** [[Apollyon]], [[Baalzebul]], [[Ghlaunder]], [[Gozreh]],[[Hei Feng]],[[Horus]],[[Hshurha]],[[Pazuzu]],[[Ragdya]],[[Ranginori]],[[Rovagug]],[[Sturovenen]],[[Uvuko]],[[Ylimancha]]

**Domain Spell**_[[Pushing Gust]]_;**Advanced Domain Spell**_[[Disperse into Air]]_

You can control winds and the weather.