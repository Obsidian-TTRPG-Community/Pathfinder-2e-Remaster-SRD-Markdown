---
title: "Fate Domain"
icon: ":sticky-note:"
aliases: "Fate Domain"
foundryId: Compendium.pf2e.journals.JournalEntry.EEZvDB1Z7ezwaxIr.JournalEntryPage.EC2eB0JglDG5j1gT
tags:
  - JournalEntryPage
---

# Fate Domain
**Deities** [[Angradd]], [[Cosmic Caravan]], [[Erecura]], [[Followers of Fate]], [[Grandmother Spider]], [[Imot]], [[Irez]], [[Lissala]], [[Luhar]], [[Lysianassa]], [[Magdh]], [[Magrim]], [[Mahathallah]], [[Otolmens]], [[Pharasma]], [[Ravithra]], [[Shyka]], [[Valmallos]]

**Domain Spell** _[[Read Fate]]_; **Advanced Domain Spell** _[[Tempt Fate]]_

You see and understand hidden inevitabilities.