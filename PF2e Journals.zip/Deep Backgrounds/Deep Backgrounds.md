---
title: "Deep Backgrounds"
icon: ":book:"
aliases: "Deep Backgrounds"
foundryId: Compendium.pf2e.journals.JournalEntry.xtrW5GEtPPuXR6k2
tags:
  - JournalEntry
---

# Deep Backgrounds

## Table of Contents

- [[Using Deep Backgrounds]]
- [[Family Background]]
- [[Homeland]]
- [[Major Childhood Event]]
- [[Influential Associate]]
- [[Relationships]]
  - [[Inspiring Relationships]]
  - [[Challenging Relationships]]