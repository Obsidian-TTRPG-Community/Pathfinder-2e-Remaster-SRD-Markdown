---
title: "Grazing Blow"
icon: ":sticky-note:"
aliases: "Grazing Blow"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.MSdKfjoNBj7PjEoo
tags:
  - JournalEntryPage
---
Play after a foe hit you with a Strike.

* * *

If the foe rolled a critical success, it gets a success instead. If the foe rolled a success, it deals minimum damage instead of rolling for damage.