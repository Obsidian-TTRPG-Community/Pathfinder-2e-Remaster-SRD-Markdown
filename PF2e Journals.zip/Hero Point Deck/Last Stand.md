---
title: "Last Stand"
icon: ":sticky-note:"
aliases: "Last Stand"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.jMhD1Z6aagYAYCnb
tags:
  - JournalEntryPage
---
Play when you take damage.

* * *

Until the start of your next turn, any damage that would reduce you to 0 Hit Points leaves you with 1 Hit Point remaining and gives you the [[Doomed 1]] condition, or increases your doomed value by 1 if you're already doomed. As usual, you die when your doomed condition equals the dying value that would kill you (usually doomed 4).