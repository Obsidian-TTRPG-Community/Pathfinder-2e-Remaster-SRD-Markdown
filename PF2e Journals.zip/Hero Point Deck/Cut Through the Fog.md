---
title: "Cut Through the Fog"
icon: ":sticky-note:"
aliases: "Cut Through the Fog"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.eZUSi5q5NnEvCDEk
tags:
  - JournalEntryPage
---
Play before you attempt a Will save.

* * *

You succeed at the saving throw without needing to roll. You gain the [[Stupefied 1]] condition, which lasts until the next time you get a full night's rest.