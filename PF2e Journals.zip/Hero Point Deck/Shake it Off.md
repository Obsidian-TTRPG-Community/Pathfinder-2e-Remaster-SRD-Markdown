---
title: "Shake it Off"
icon: ":sticky-note:"
aliases: "Shake it Off"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.Y20GMjqVbTvGZ87k
tags:
  - JournalEntryPage
---
Play at any time.

* * *

All persistent damage affecting you immediately comes to an end.