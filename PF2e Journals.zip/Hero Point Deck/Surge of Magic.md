---
title: "Surge of Magic"
icon: ":sticky-note:"
aliases: "Surge of Magic"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.oa0wVDfT3dbWwNDf
tags:
  - JournalEntryPage
---
Play during your turn.

* * *

Until the end of your turn, you can Activate one magic item that you have already activated once today. This activation doesn't count against the item's frequency limit if the limit is once per day, or a shorter increment of time. If the item is a wand, activating it this way doesn't overcharge it.