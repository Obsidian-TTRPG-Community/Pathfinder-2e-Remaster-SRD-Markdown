---
title: "Aura of Protection"
icon: ":sticky-note:"
aliases: "Aura of Protection"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.7uERHpfJplGtYf8w
tags:
  - JournalEntryPage
---
Play this after Casting a Spell from your spell slots.

* * *

You surround yourself with an aura of residual magic power. Until the start of your next turn, you gain resistance to all damage equal to the level of the spell that you just cast.