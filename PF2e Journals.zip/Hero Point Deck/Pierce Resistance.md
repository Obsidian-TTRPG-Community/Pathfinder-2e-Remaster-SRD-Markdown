---
title: "Pierce Resistance"
icon: ":sticky-note:"
aliases: "Pierce Resistance"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.lLdAvaOo1rLLg5b4
tags:
  - JournalEntryPage
---
Play after you learn about a foe's resistance.

* * *

Until the end of your next turn, the foe loses a resistance of your choice. You must be aware of the resistance, either from seeing it shrug off damage from an attack or due to a successful Recall Knowledge check.