---
title: "Make Way!"
icon: ":sticky-note:"
aliases: "Make Way!"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.jIs5mtRaqG0aGQ8u
tags:
  - JournalEntryPage
---
Play at the start of a Stride.

* * *

During the Stride, you must move in a straight line, but you can attempt to [[Shove]] any creature in your way, moving it to an adjacent space out of the way of your movement. Your multiple attack penalty doesn't apply to any of these free Shove attempts, nor do they increase your multiple attack penalty. If you fail to Shove a creature out of your way, your movement ends.