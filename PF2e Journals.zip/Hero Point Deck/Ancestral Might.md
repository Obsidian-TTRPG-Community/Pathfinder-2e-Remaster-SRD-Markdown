---
title: "Ancestral Might"
icon: ":sticky-note:"
aliases: "Ancestral Might"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.quxPxuMub8k6abzN
tags:
  - JournalEntryPage
---
Play during your turn.

* * *

Until the start of your next turn, you gain a +2 status bonus to checks based on the ability scores that are boosted by your ancestry (ignoring free boosts). If your ancestry only grants free boosts, select one ability score to gain the bonus to instead.