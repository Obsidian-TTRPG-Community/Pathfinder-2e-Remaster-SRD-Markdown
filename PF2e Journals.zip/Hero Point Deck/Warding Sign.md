---
title: "Warding Sign"
icon: ":sticky-note:"
aliases: "Warding Sign"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.LaNM3BfoZUG2B39v
tags:
  - JournalEntryPage
---
Play at any time.

* * *

Select a creature within sight. That creature is immune to misfortune effects for 1 round. If the creature was already affected by a misfortune effect, it ignores that effect for the duration, then the effect returns.