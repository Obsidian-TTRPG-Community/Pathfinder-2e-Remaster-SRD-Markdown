---
title: "Stoke the Magical Flame"
icon: ":sticky-note:"
aliases: "Stoke the Magical Flame"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.bb4nv44qEdpt0pLq
tags:
  - JournalEntryPage
---
Play when you or an ally is Casting a Spell.

* * *

Heighten that spell by 1 level. This can't heighten a spell above the highest level of spell you or the ally can cast.