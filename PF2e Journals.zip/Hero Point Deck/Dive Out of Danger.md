---
title: "Dive Out of Danger"
icon: ":sticky-note:"
aliases: "Dive Out of Danger"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.O2hME2ilgN9BcEA4
tags:
  - JournalEntryPage
---
Play before you attempt a Reflex save.

* * *

You succeed at the saving throw without needing to roll. You gain the [[Clumsy 1]] condition, which lasts until the next time you get a full night's rest.