---
title: "Channel Life Force"
icon: ":sticky-note:"
aliases: "Channel Life Force"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.odrMigI38k7lgurE
tags:
  - JournalEntryPage
---
Play on your turn after you have spent all of your Focus Points.

* * *

Gain 1 Focus Point that must be spent by the end of your turn or it's lost. If you use this Focus Point, you become [[Drained 1]].