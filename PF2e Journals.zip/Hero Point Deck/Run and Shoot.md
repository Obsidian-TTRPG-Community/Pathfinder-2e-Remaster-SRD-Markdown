---
title: "Run and Shoot"
icon: ":sticky-note:"
aliases: "Run and Shoot"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.zX28AGU1k5sO2Tpd
tags:
  - JournalEntryPage
---
Play when you take a Stride action.

* * *

You make a ranged Strike at any point during this movement.