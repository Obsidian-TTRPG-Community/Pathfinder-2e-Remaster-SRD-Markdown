---
title: "Reckless Charge"
icon: ":sticky-note:"
aliases: "Reckless Charge"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.E4aI0BTV9ATxfjGd
tags:
  - JournalEntryPage
---
Play after taking two consecutive Stride actions.

* * *

Make a melee Strike. You are [[Off-Guard]] until the start of your next turn.