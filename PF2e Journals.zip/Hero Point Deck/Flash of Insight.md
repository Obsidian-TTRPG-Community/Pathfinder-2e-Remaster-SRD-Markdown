---
title: "Flash of Insight"
icon: ":sticky-note:"
aliases: "Flash of Insight"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.EGa7oNFMSLkvkQjL
tags:
  - JournalEntryPage
---
Play at the start of your turn.

* * *

Until the end of your turn, you gain [[Automatic Knowledge]] for any one skill. If you already have Automatic Knowledge, when you use that feat to attempt a Recall Knowledge check this turn, use an outcome one degree of success better than the result of your roll. If you use this to learn about a creature, you gain twice the number of clues about its abilities.