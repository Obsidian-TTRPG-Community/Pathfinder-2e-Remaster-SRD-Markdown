---
title: "Class Might"
icon: ":sticky-note:"
aliases: "Class Might"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.a68Phr1qsqVRPMVp
tags:
  - JournalEntryPage
---
Play during your turn.

* * *

Until the start of your next turn you gain a +2 status bonus to checks based on the key ability score of your class. If your class grants a choice for its key ability, select one of those ability scores to gain the bonus.