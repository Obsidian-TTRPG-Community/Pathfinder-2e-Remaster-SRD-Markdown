---
title: "Drain Power"
icon: ":sticky-note:"
aliases: "Drain Power"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.xsdJIpd9NRLpRZT2
tags:
  - JournalEntryPage
---
Play when you Activate a magic item that Casts a Spell.

* * *

Heighten the spell by 1 level. This can't heighten the item's spell above half your level, rounded up. If the item wasn't consumed on use, you can't use the item again for 24 hours.