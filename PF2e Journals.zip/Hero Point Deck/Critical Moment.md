---
title: "Critical Moment"
icon: ":sticky-note:"
aliases: "Critical Moment"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.P3mSUWRvCCwEouB0
tags:
  - JournalEntryPage
---
Play this after rolling a check.

* * *

Reroll the check twice and take the best result. This is a fortune effect. If you still fail this check, you become [[Doomed 1]].