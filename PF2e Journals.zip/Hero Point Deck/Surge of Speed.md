---
title: "Surge of Speed"
icon: ":sticky-note:"
aliases: "Surge of Speed"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.8w220Bvj6W2Ui8Ae
tags:
  - JournalEntryPage
---
Play at the start of a creature's turn.

* * *

That creature is [[Quickened]] on its turn and can use the extra action only to take a single action with the move trait.