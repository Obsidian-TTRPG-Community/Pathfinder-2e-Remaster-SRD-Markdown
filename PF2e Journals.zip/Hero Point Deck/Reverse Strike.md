---
title: "Reverse Strike"
icon: ":sticky-note:"
aliases: "Reverse Strike"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.ox9mFGY50NEzRR12
tags:
  - JournalEntryPage
---
Play after you fail an attack roll.

* * *

You get a success on the attack roll rather than a failure.