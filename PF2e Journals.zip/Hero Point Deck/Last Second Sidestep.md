---
title: "Last Second Sidestep"
icon: ":sticky-note:"
aliases: "Last Second Sidestep"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.AeGcoQNaZ1BUmWvu
tags:
  - JournalEntryPage
---
Play when you are targeted by a ranged Strike.

* * *

The Strike automatically misses.