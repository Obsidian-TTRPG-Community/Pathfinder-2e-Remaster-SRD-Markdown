---
title: "Endure the Onslaught"
icon: ":sticky-note:"
aliases: "Endure the Onslaught"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.TU21DvdpQG7U2Q9Y
tags:
  - JournalEntryPage
---
Play at any time.

* * *

Give a creature you can see resistance 5 to all damage until the start of your next turn. If you are 7th level or higher, the resistance is 10, and if you are 12th level or higher, the resistance is 15.