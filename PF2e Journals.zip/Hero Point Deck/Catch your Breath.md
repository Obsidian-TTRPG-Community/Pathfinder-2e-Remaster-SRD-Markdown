---
title: "Catch your Breath"
icon: ":sticky-note:"
aliases: "Catch your Breath"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.LafJ1PXfnR4Ogyzh
tags:
  - JournalEntryPage
---
Play at the end of your turn.

* * *

Select yourself or an ally within 30 feet. The creature you choose must have fewer than half their total Hit Points. The creature gains a number of temporary Hit Points equal to twice your level, which last until the end of the combat.