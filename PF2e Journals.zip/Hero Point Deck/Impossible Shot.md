---
title: "Impossible Shot"
icon: ":sticky-note:"
aliases: "Impossible Shot"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.k0ue81dFKH4OKxed
tags:
  - JournalEntryPage
---
Play when making a ranged attack, either with a Strike or a spell.

* * *

If you're attempting a Strike, double the range increment of the weapon or unarmed attack. If you're Casting a Spell, increase the range of the spell by half.