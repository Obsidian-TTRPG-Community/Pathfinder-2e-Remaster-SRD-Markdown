---
title: "Push Through the Pain"
icon: ":sticky-note:"
aliases: "Push Through the Pain"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.lJe2uRM1wNJw4Mgr
tags:
  - JournalEntryPage
---
Play before you attempt a Fortitude save.

* * *

You succeed at the saving throw without needing to roll. You gain the [[Drained 1]] condition.