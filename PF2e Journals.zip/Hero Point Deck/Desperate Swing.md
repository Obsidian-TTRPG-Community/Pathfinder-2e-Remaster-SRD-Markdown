---
title: "Desperate Swing"
icon: ":sticky-note:"
aliases: "Desperate Swing"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.d15Zjdqplmj7ZTKK
tags:
  - JournalEntryPage
---
Play during your turn.

* * *

Make a Strike, ignoring the multiple attack penalty. If you roll a critical success, you get a normal success instead. If the attack fails, you release your weapon, or drop [[Prone]] if you were using an unarmed attack or otherwise can't release your weapon.