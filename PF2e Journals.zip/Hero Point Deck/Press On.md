---
title: "Press On"
icon: ":sticky-note:"
aliases: "Press On"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.zcBCxlvPCpmjt5IS
tags:
  - JournalEntryPage
---
Play at the start of your turn.

* * *

Until the end of your turn, ignore penalties to checks and DCs from conditions.