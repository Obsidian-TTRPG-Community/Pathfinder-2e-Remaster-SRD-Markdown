---
title: "Rampage"
icon: ":sticky-note:"
aliases: "Rampage"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.VSZGUtcr5NGNPtlB
tags:
  - JournalEntryPage
---
Play at the start of your turn.

* * *

Make a Strike against each foe within reach. The multiple attack penalty applies as normal. At the end of these attacks, your turn ends and you are [[Fatigued]].