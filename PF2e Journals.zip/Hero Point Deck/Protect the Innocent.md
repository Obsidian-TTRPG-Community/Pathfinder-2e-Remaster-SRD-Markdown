---
title: "Protect the Innocent"
icon: ":sticky-note:"
aliases: "Protect the Innocent"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.ftdrUGjW8A4TPkMa
tags:
  - JournalEntryPage
---
Play when an incapacitated ally or noncombatant NPC within sight takes damage from an attack or effect.

* * *

Prevent all of the damage. You take half of the damage they would have taken (in addition to the damage you would normally take from the attack or effect, if any). You can only use this to prevent damage to an ally if that ally is unable to act, such as when they are [[Unconscious]] or [[Paralyzed]].