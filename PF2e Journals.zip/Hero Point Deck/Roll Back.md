---
title: "Roll Back"
icon: ":sticky-note:"
aliases: "Roll Back"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.6xnJaS3qRZGdDHtr
tags:
  - JournalEntryPage
---
Play after an attack or effect causes you to become [[Grabbed]] or knocks you [[Prone]].

* * *

You roll backward from the attack, landing on your feet. Take a Step away from the source of the attack (if any), and you're no longer prone or grabbed.