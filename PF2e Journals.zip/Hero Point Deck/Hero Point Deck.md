---
title: "Hero Point Deck"
icon: ":book:"
aliases: "Hero Point Deck"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko
tags:
  - JournalEntry
---

# Hero Point Deck

## Table of Contents

- [[Ancestral Might]]
- [[Aura of Protection]]
- [[Rage and Fury]]
- [[I Hope This Works]]
- [[Endure the Onslaught]]
- [[Battle Cry]]
- [[Catch your Breath]]
- [[Last Stand]]
- [[Shoot Through]]
- [[Reckless Charge]]
- [[Roll Back]]
- [[Warding Sign]]
- [[Called Foe]]
- [[Class Might]]
- [[Hold the Line]]
- [[Tumble Through]]
- [[Fluid Motion]]
- [[Magical Reverberation]]
- [[Spark of Courage]]
- [[Pierce Resistance]]
- [[Press On]]
- [[Impossible Shot]]
- [[Protect the Innocent]]
- [[Healing Prayer]]
- [[Make Way!]]
- [[Rending Swipe]]
- [[Stay in the Fight]]
- [[Strike True]]
- [[Drain Power]]
- [[Shake it Off]]
- [[Dive Out of Danger]]
- [[Push Through the Pain]]
- [[Hasty Block]]
- [[Distract Foe]]
- [[Last Second Sidestep]]
- [[Reverse Strike]]
- [[Critical Moment]]
- [[Channel Life Force]]
- [[Stoke the Magical Flame]]
- [[Desperate Swing]]
- [[Cut Through the Fog]]
- [[Surge of Speed]]
- [[Opportune Distraction]]
- [[Run and Shoot]]
- [[Flash of Insight]]
- [[Rampage]]
- [[Misdirected Attack]]
- [[Grazing Blow]]
- [[Last Ounce of Strength]]
- [[Tuck and Roll]]
- [[Surge of Magic]]
- [[Daring Attempt]]