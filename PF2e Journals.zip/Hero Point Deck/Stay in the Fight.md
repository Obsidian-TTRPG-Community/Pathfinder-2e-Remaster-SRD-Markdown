---
title: "Stay in the Fight"
icon: ":sticky-note:"
aliases: "Stay in the Fight"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.QUhXVsUDujUTYz7F
tags:
  - JournalEntryPage
---
Play at the start of a turn when you or an ally is affected by an ongoing incapacitation effect.

* * *

The creature ignores that incapacitation effect until the end of their turn. This turn doesn't count as part of the duration for that effect.