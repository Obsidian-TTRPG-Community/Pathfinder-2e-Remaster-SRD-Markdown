---
title: "Magical Reverberation"
icon: ":sticky-note:"
aliases: "Magical Reverberation"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.gmwyfTlk0BGZLdCt
tags:
  - JournalEntryPage
---
Play this after Casting a Spell.

* * *

The spell's power reverberates in your mind. You can Cast this Spell one additional time without having it prepared or expending a spell slot. If you don't Cast the Spell by the end of your next turn, it is lost. After Casting the Spell again, you become [[Stupefied 1|Stupefied 2]] for 1 minute.