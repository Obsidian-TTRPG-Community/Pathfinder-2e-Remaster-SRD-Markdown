---
title: "Rending Swipe"
icon: ":sticky-note:"
aliases: "Rending Swipe"
foundryId: Compendium.pf2e.journals.JournalEntry.BSp4LUSaOmUyjBko.JournalEntryPage.XHSXMcRaMOsbjoO1
tags:
  - JournalEntryPage
---
Play after making two successful consecutive melee Strikes against the same target with two different weapons.

* * *

The target takes @Damage\[1d6\[bleed]] and is [[Sickened 1]] until the bleeding stops. If you are 7th level or higher, increase the bleed to @Damage\[2d6\[bleed]]. If you are 12th level or higher, increase the bleed to @Damage\[3d6\[bleed]].