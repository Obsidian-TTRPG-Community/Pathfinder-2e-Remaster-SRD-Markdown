---
title: "Quick Adventure Groups"
icon: ":sticky-note:"
aliases: "Quick Adventure Groups"
foundryId: Compendium.pf2e.journals.JournalEntry.S55aqwWIzpQRFhcq.JournalEntryPage.zVcfWP1ac0JhNEhY
tags:
  - JournalEntryPage
---

# Quick Adventure Groups
| **Quick Adventure Groups** |  |
| --- | --- |
| If you want an easy framework for building an encounter, you can use one of the following basic structures and slot in monsters and NPCs. |  |
| **Boss and Lackeys (120 XP)** | One creature of party level + 2, four creatures of party level - 4 |
| **Boss and Lieutenant (120 XP)** | One creature of party level + 2, one creature of party level |
| **Elite Enemies (120 XP)** | Three creatures of party level |
| **Lieutenant and Lackeys (80 XP)** | One creature of party level, four creatures of party level - 4 |
| **Mated Pair (80 XP)** | Two creatures of party level |
| **Troop (80 XP)** | One creature of party level, two creatures of party level - 2 |
| **Mook Squad (60 XP)** | Six creatures of party level - 4 |