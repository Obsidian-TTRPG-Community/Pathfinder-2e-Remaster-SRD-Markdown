---
title: "Structures"
icon: ":sticky-note:"
aliases: "Structures"
foundryId: Compendium.pf2e.journals.JournalEntry.S55aqwWIzpQRFhcq.JournalEntryPage.FOI43M8DJe2lkMwl
tags:
  - JournalEntryPage
---

# Structures

| **Door** | **Climb DC** | **Hardness, HP (BT)** |
| --- | --- | --- |
| Wood | 20 | 10, 40 (20) |
| Stone | 30 | 14, 56 (28) |
| Reinforced Wood | 15 | 15, 60 (30) |
| Iron | 30 | 18, 72 (36) |
| **Wall** | **Climb DC** | **Hardness, HP (BT)** |
| Crumbling Masonry | 15 | 10, 40 (20) |
| Wooden Slats | 15 | 10, 40 (20) |
| Masonry | 20 | 14, 56 (28) |
| Hewn Stone | 30 | 14, 56 (28) |
| Iron | 40 | 18, 72 (36) |
| **Portcullis** | **Climb DC** | **Hardness, HP (BT)** |
| Wood | 10 | 10, 40 (20) |
| Iron | 10 | 18, 72 (36) |