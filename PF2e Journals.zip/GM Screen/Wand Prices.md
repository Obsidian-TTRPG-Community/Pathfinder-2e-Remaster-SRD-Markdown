---
title: "Wand Prices"
icon: ":sticky-note:"
aliases: "Wand Prices"
foundryId: Compendium.pf2e.journals.JournalEntry.S55aqwWIzpQRFhcq.JournalEntryPage.BsaTOw6p74DW5d8t
tags:
  - JournalEntryPage
---

# Wand Prices
| Name | Level | Price | Bulk |
| --- | --- | --- | --- |
| Magic Wand (1st-Level Spell) | 3 | 60 gp | L |
| Magic Wand (2nd-Level Spell) | 5 | 160 gp | L |
| Magic Wand (3rd-Level Spell) | 7 | 360 gp | L |
| Magic Wand (4th-Level Spell) | 9 | 700 gp | L |
| Magic Wand (5th-Level Spell) | 11 | 1,500 gp | L |
| Magic Wand (6th-Level Spell) | 13 | 3,000 gp | L |
| Magic Wand (7th-Level Spell) | 15 | 6,500 gp | L |
| Magic Wand (8th-Level Spell) | 17 | 15,000 gp | L |
| Magic Wand (9th-Level Spell) | 19 | 40,000 gp | L |