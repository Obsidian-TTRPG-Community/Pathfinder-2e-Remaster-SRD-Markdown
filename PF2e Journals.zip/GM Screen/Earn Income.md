---
title: "Earn Income"
icon: ":sticky-note:"
aliases: "Earn Income"
foundryId: Compendium.pf2e.journals.JournalEntry.S55aqwWIzpQRFhcq.JournalEntryPage.aBALUjLyOqXKlhrP
tags:
  - JournalEntryPage
---

# Earn Income
**INCOME EARNED**

| Task Level | Failure | Trained | Expert | Master | Legendary |
| --- | --- | --- | --- | --- | --- |
| **0** | 1 cp | 5 cp | 5 cp | 5 cp | 5 cp |
| **1** | 2 cp | 2 sp | 2 sp | 2 sp | 2 sp |
| **2** | 4 cp | 3 sp | 3 sp | 3 sp | 3 sp |
| **3** | 8 cp | 5 sp | 5 sp | 5 sp | 5 sp |
| **4** | 1 sp | 7 sp | 8 sp | 8 sp | 8 sp |
| **5** | 2 sp | 9 sp | 1 gp | 1 gp | 1 gp |
| **6** | 3 sp | 1 gp, 5 sp | 2 gp | 2 gp | 2 gp |
| **7** | 4 sp | 2 gp | 2 gp, 5 sp | 2 gp, 5 sp | 2 gp, 5 sp |
| **8** | 5 sp | 2 gp, 5 sp | 3 gp | 3 gp | 3 gp |
| **9** | 6 sp | 3 gp | 4 gp | 4 gp | 4 gp |
| **10** | 7 sp | 4 gp | 5 gp | 6 gp | 6 gp |
| **11** | 8 sp | 5 gp | 6 gp | 8 gp | 8 gp |
| **12** | 9 sp | 6 gp | 8 gp | 10 gp | 10 gp |
| **13** | 1 gp | 7 gp | 10 gp | 15 gp | 15 gp |
| **14** | 1 gp, 5 sp | 8 gp | 15 gp | 20 gp | 20 gp |
| **15** | 2 gp | 10 gp | 20 gp | 28 gp | 28 gp |
| **16** | 2 gp, 5 sp | 13 gp | 25 gp | 36 gp | 40 gp |
| **17** | 3 gp | 15 gp | 30 gp | 45 gp | 55 gp |
| **18** | 4 gp | 20 gp | 45 gp | 70 gp | 90 gp |
| **19** | 6 gp | 30 gp | 60 gp | 100 gp | 130 gp |
| **20** | 8 gp | 40 gp | 75 gp | 150 gp | 200 gp |
| **20 (critical success)** | — | 50 gp | 90 gp | 175 gp | 300 g |