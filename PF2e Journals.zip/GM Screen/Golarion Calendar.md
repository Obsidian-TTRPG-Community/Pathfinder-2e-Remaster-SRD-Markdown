---
title: "Golarion Calendar"
icon: ":sticky-note:"
aliases: "Golarion Calendar"
foundryId: Compendium.pf2e.journals.JournalEntry.S55aqwWIzpQRFhcq.JournalEntryPage.KXAxZfdMpnHQZQoc
tags:
  - JournalEntryPage
---

# Golarion Calendar
| # | Day |
| --- | --- |
| 1 | Moonday |
| 2 | Toilday |
| 3 | Wealday |
| 4 | Oathday |
| 5 | Fireday |
| 6 | Starday |
| 7 | Sunday |

| # | Month | Number of Days |
| --- | --- | --- |
| 1 | Abadius | 31 |
| 2 | Calistril | 28 (Leap Month) |
| 3 | Pharast | 31 |
| 4 | Gozran | 30 |
| 5 | Desnus | 31 |
| 6 | Sarenith | 30 |
| 7 | Erastus | 31 |
| 8 | Arodus | 31 |
| 9 | Rova | 30 |
| 10 | Lamashan | 31 |
| 11 | Neth | 30 |
| 12 | Kuthona | 31 |