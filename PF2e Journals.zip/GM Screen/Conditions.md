---
title: "Conditions"
icon: ":sticky-note:"
aliases: "Conditions"
foundryId: Compendium.pf2e.journals.JournalEntry.S55aqwWIzpQRFhcq.JournalEntryPage.duqPy1VMQYNJrw7q
tags:
  - JournalEntryPage
---

# Conditions
| **Group** | **Conditions** |  |  |  |
| --- | --- | --- | --- | --- |
| **Degrees of Detection** | **[[Observed]]** | **[[Hidden]]** | **[[Undetected]]** | **[[Unnoticed]]** |
| **Senses** | [[Blinded]] | [[Concealed]] | [[Dazzled]] | [[Deafened]] |
|  | [[Invisible]] |  |  |  |
| **Death and Dying** | [[Doomed 1\|Doomed]] | [[Dying 1\|Dying]] | [[Unconscious]] | [[Wounded 1\|Wounded]] |
| **Attitudes** | [[Hostile]] | [[Unfriendly]] | [[Indifferent]] | [[Friendly]] |
|  | [[Helpful]] |  |  |  |
| **Lowered Ability** | [[Broken]] | [[Clumsy 1\|Clumsy]] | [[Confused]] | [[Controlled]] |
|  | [[Drained 1\|Drained]] | [[Encumbered]] | [[Enfeebled 1\|Enfeebled]] | [[Fascinated]] |
|  | [[Fatigued]] | [[Off-Guard]] | [[Fleeing]] | [[Frightened 1\|Frightened]] |
|  | [[Grabbed]] | [[Immobilized]] | [[Paralyzed]] | [[Persistent Damage]] |
|  | [[Petrified]] | [[Prone]] | [[Quickened]] | [[Restrained]] |
|  | [[Sickened 1\|Sickened]] | [[Slowed 1\|Slowed]] | [[Stunned 1\|Stunned]] | [[Stupefied 1\|Stupefied]] |