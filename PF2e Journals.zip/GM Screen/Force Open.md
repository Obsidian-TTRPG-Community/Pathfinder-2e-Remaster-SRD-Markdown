---
title: "Force Open"
icon: ":sticky-note:"
aliases: "Force Open"
foundryId: Compendium.pf2e.journals.JournalEntry.S55aqwWIzpQRFhcq.JournalEntryPage.oM0DobZe9uEkz9kb
tags:
  - JournalEntryPage
---

# Force Open
| **Structure** | **Force Open DC** |
| --- | --- |
| **Stuck door or window** | 15 |
| **Exceptionally stuck** | 20 |
| **Lift wooden portcullis** | 20\* |
| **Lift iron portcullis** | 30\* |
| **Bend metal bars** | 30 |
| \* Use the Thievery DC of the locking mechanism if it's higher. |  |