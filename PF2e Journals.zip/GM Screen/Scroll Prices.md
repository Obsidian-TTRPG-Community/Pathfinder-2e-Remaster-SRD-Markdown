---
title: "Scroll Prices"
icon: ":sticky-note:"
aliases: "Scroll Prices"
foundryId: Compendium.pf2e.journals.JournalEntry.S55aqwWIzpQRFhcq.JournalEntryPage.l0rlB52Pzy6Vt1Ic
tags:
  - JournalEntryPage
---

# Scroll Prices
| **Name** | **Level** | **Price** | **Bulk** |
| --- | --- | --- | --- |
| 1st-Level Scroll | 1 | 4 gp | L |
| 2nd-Level Scroll | 3 | 12 gp | L |
| 3rd-Level Scroll | 5 | 30 gp | L |
| 4th-Level Scroll | 7 | 70 gp | L |
| 5th-Level Scroll | 9 | 150 gp | L |
| 6th-Level Scroll | 11 | 300 gp | L |
| 7th-Level Scroll | 13 | 600 gp | L |
| 8th-Level Scroll | 15 | 1,300 gp | L |
| 9th-Level Scroll | 17 | 3,000 gp | L |
| 10th-Level Scroll | 19 | 8,000 gp | L |