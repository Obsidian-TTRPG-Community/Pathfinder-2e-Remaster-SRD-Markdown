---
title: "Spell Trickster"
icon: ":sticky-note:"
aliases: "Spell Trickster"
foundryId: Compendium.pf2e.journals.JournalEntry.vx5FGEG34AxI2dow.JournalEntryPage.DztQF2FexWvnzcaE
tags:
  - JournalEntryPage
---

# Spell Trickster
Just as Golarion's merchants scour busy marketplaces for newfound goods, scholars of magic congregate in teahouses, debate at symposia, and haunt the back rooms of esoteric shops to swap secrets of their trade. In such meetings, a different kind of magic may strike: the spark of innovation! The mixing of magical techniques produces fascinating and unpredictable results. As one of these innovators, sometimes called a spell trickster, you have a knack for pioneering magical techniques and discovering new effects from spells most novice spellcasters take for granted. Whether your unique abilities are the result of weeks of experimentation or a secret passed to you by a traveling practitioner, you delight in surprising others with your tricks.

#### The Fruits of Research

While magic can spring from many sources, from wizard tutors to self-taught savants, the art of the spell trickster often springs from sophisticated magical research. The magical academies in Golarion have no claim to magic as a whole but can often teach lesser-known variants of a spell to their students. At the Magaambya academy in the Mwangi Expanse, for instance, initiates study multiple traditions of magic, adapting the techniques of harnessing magical essence from one tradition to create new methods of casting spells in another. The Arclords of Nex have spent thousands of years honing spells in both wartime and peace, demonstrating a fine control over the arcane by effortlessly changing their magic to suit their whims. The return of New Thassilon brought thousands of magical dabblers and scholars, each with their own unique tricks and each eager to see what new spell variants have developed in their long absence.

This isn't to say that spell tricksters come solely from high academia. A sorcerer might demonstrate aberrant powers in her bloodline magic, hinting at a background more complex than a single eldritch influence acting upon her. An oracle might grope at a divine power that they poorly understand and cast a spell in a unique manner simply because they were never taught otherwise. A witch's patron or a whimsical deity might grant a favored servant a special power for whatever strange motives such beings might possess. Magic in Golarion isn't entirely predictable, no matter how many practitioners wish that it was so. While most spellcasters follow predictable patterns in their art, there are always exceptions.

The rules in this section are presented as part of an archetype, meant for a character dedicated to the art of innovating magic—but you don't have to limit yourself to this premise. At the GM's discretion, a spell trickster feat could be made available to a character as a class feat without the character taking the archetype. In most cases, this option should only be offered as a reward or story element that the character, GM, or group has dedicated a significant amount of time to developing—a character who wishes to partake in these options without GM permission or involvement should simply take the spell trickster archetype. These feats could be used to represent the payoff from extended magical research; finding forgotten or forbidden lore in a lost corner of Golarion; pleasing a god, patron, or other notable power; a magical plane or artifact exerting its influence; or any other number of situations that an adventurer might encounter while exploring. Keep in mind, however, that these feats were created and balanced to be part of an archetype. If allowing spell trickster feats as general class feats begins to negatively impact the game, the players should be willing to walk the decision back and rebuild characters as necessary.

## [[Spell Trickster Dedication]] Feat 2

**Prerequisites** Able to cast spells; trained in Arcana, Nature, Occultism, or Religion

* * *

Your experience with magic and its traditions lets you specialize in the casting of certain spells, customizing familiar spells to create novel effects. Whenever you gain a feat from this archetype, you either learn to modify the effects of a single spell, or you change one of the modifications from a previous feat. Each time you Cast the Spell corresponding to the feat you chose, you decide whether to cast its normal or modified version. You can only apply one modification to a spell at a time, even if you know more than one modification for that spell. Besides modifications mentioned in the feat, the spell functions as normal.

Choose up to two 4th-level spell trickster archetype feats for which you meet the spell-casting prerequisite. You gain those feats, ignoring their level prerequisite.

**Special** You can't select another dedication feat until you have gained two other feats from the spell trickster archetype. The two feats you gain from taking the dedication don't count toward this total.

## [[Agile Hand]] Feat 4

**Prerequisites**[[Spell Trickster Dedication]], ability to cast _[[Telekinetic Hand]]_

* * *

When you cast mage hand, you can modify its target to be a set of thieves' tools. When you Cast the Spell in this way, the tools move up to 20 feet towards a device or lock. After you Sustain the Spell on future turns, you can use the tools to attempt Thievery checks to Disable a Device or Pick a Lock within the spell's range, but you take a -2 penalty to your Thievery check. If you critically fail, the spell ends and you can't use this modification again for 24 hours.

## [[Barrier Shield]] Feat 4

**Prerequisites**[[Spell Trickster Dedication]], ability to cast _[[Shield]]_

* * *

When you cast shield, you can modify the spell to create a solid barrier you can use for cover, but not for blocking. You can't use the Shield Block reaction when the spell is modified in this way, but you (and only you) can spend an action to Take Cover to gain standard cover from it.

## [[Forceful Push]] Feat 4

**Prerequisites**[[Spell Trickster Dedication]], ability to cast _[[Telekinetic Hand]]_

* * *

When you cast mage hand, you can modify its target to be 1 creature. If you do, replace its standard effects with the following: You push your foe telekinetically. Make a spell attack roll against the target's Fortitude DC. On a success, you push the target 5 feet away from you. On a critical success, you push the target 10 feet away from you.

## [[Shining Arms]] Feat 4

**Prerequisites**[[Spell Trickster Dedication]], ability to cast _[[Light]]_

* * *

When you cast light, you can modify its target to be 1 melee weapon, either unattended or possessed by you or a willing ally, and modify its duration to be 1 minute. If you do, add the following to its effects: When a creature wielding the weapon critically hits a foe, you can Dismiss the Spell as a reaction, causing the foe to be [[Dazzled]] for 1 round. After you use this reaction, you can't use this modification again for 10 minutes.

## [[Summon Ensemble]] Feat 4

**Prerequisites**[[Spell Trickster Dedication]], ability to cast _[[Summon Instrument]]_

* * *

When you cast summon instrument, you can modify its duration to be sustained, up to 1 minute. When you do, you summon a number of instruments equal to your spellcasting ability modifier that hover around you and play of their own accord. Once per turn when you Sustain the Spell, choose an opponent within 30 feet who can hear your performance. The target must attempt a Will save against the spell's DC; on a failure, it becomes distracted by your performance and becomes [[Off-Guard]] for 1 round. The target is then temporarily immune for 24 hours.

## [[Tracing Sigil]] Feat 4

**Prerequisites**[[Spell Trickster Dedication]], ability to cast _[[Sigil]]_

* * *

When you cast sigil, you can modify the spell to add the following to its standard effects: The target leaves a magical trail that you and others can try to follow. You and other creatures can attempt to Track the target, substituting an Arcana, Nature, Occultism, or Religion check (whichever matches the magical tradition of your sigil spell) for the Survival check. Much like Tracking with Survival, this must take place somewhere the target has been and follow the trail; it doesn't allow anyone to find the target from a distance. You can only have a single target marked with a modified sigil in this way. If you use this ability again on a second target, the sigil spell on the first target ends, and your mark fades.

## [[Wild Lights]] Feat 4

**Prerequisites**[[Spell Trickster Dedication]], ability to cast _[[Light]]_

* * *

When you cast dancing lights, you can modify its duration to be 1 minute and modify its standard effects to create a single floating light in the shape of a Tiny creature, instead of up to four floating lights. The creature hovers over your head unless you spend a single action that has the concentrate trait to direct the light to move up to 30 feet, in which case it remains there until you direct it again. If you direct it back to your head, it hovers there and follows you again until you direct it elsewhere. If the light ever moves beyond 120 feet of you, it winks out immediately.

## [[Animate Net]] Feat 6

**Prerequisites**[[Spell Trickster Dedication]], ability to cast _[[Animate Rope]]_

* * *

When you cast animate rope, you can modify its target to be 1 net. If you do, replace the spell's standard effects with the following: You cause a net to animate and throw itself at a Medium or smaller creature within 20 feet of the net. Attempt a spell attack roll against the target's Reflex DC. On a success, the target is [[Off-Guard]] and takes a -10-foot circumstance penalty to its Speeds until it Escapes; on a critical success, it's also [[Immobilized]] until it Escapes. The Escape DC is equal to your spell DC as long as the spell lasts. Once the spell ends, the Escape DC returns to the normal DC for a net (usually 16), and a creature adjacent to the target can Interact to remove the net.

## [[Confounding Image]] Feat 6

**Prerequisites**[[Spell Trickster Dedication]], ability to cast _[[Mirror Image]]_

* * *

When you cast mirror image, you can modify its duration to be sustained up to 1 minute and modify its range to 30 feet. If you do, replace the spell's standard effects with the following: You create an illusory duplicate of yourself that appears in an unoccupied square within range. The image takes up space and has a reach of 5 feet, and your allies can flank with the image. It doesn't have any other attributes a creature would normally have other than an AC equal to your spell DC and saving throw modifiers equal to your spell DC - 10. If the image is hit by an attack or fails a save, or if you ever move more than 30 feet from it, the spell ends. Creatures can move through its space without hindrance. When you Sustain the Spell, you can move the image to an unoccupied square within range.

## [[Disk Rider]] Feat 6

**Prerequisites**[[Spell Trickster Dedication]], ability to cast _[[Floating Disk]]_

* * *

When you cast floating disk, you can modify its duration to be sustained, up to 10 minutes. If you do, add the following heightened entry to its effects.

* * *

**Heightened (3rd)** The disk can hold up to 10 Bulk. The spell no longer ends if you ride atop the disk (though it does if any other creature rides atop it, including if the creature is riding on you). If you are riding the disk, it changes its capacity to hold you, plus additional Bulk equal to the maximum you could carry without being encumbered. If you ride atop the disk, you can direct it to move along the ground up to 30 feet or your Speed, whichever is slower, each time you Sustain the Spell. While you ride atop it, the disk can move over liquids as long as it ends its movement on solid ground. If it ends its movement on a surface that can't support it, the spell ends.

## [[Drenching Mist]] Feat 6

**Prerequisites**[[Spell Trickster Dedication]], ability to cast _[[Mist]]_

* * *

When you cast obscuring mist, you can modify it to add the following heightened entry to its effects.

* * *

**Heightened (3rd)** Your mist is particularly laden with moisture. Non-magical fires within the area are automatically extinguished. Choose one magical fire or fire spell in the area and attempt to counteract it.

## [[Obscured Terrain]] Feat 6

**Prerequisites**[[Spell Trickster Dedication]], ability to cast _[[Mist]]_

* * *

When you cast obscuring mist, you can modify the spell to replace its standard effects with the following: You cause a cloud of thick fog to blanket the area, making it difficult to see the ground. The area within the fog is difficult terrain for creatures that can't see through fog or mist. You can Dismiss the cloud.

## [[Uneasy Rest]] Feat 6

**Prerequisites**[[Spell Trickster Dedication]], ability to cast _[[Sleep]]_

* * *

When you cast sleep, you can modify the spell to add the following to its standard effects: Subjects of your spell experience troubled dreams. When a target that failed or critically failed its saving throw wakes up, it is [[Frightened 1]].

## [[Volatile Grease]] Feat 6

**Prerequisites**[[Spell Trickster Dedication]], ability to cast _[[Grease]]_

* * *

When you cast grease, you can modify its target to be 1 creature. If you do, replace the spell's standard effects with the following: You splash the target with combustible grease. The target must attempt a Reflex save.

* * *

**Critical Success** The target is unaffected.

**Success** The target is splattered with grease and gains weakness 2 to fire until the end of your next turn. The target or an adjacent creature can rub off the combustible grease with an Interact action, ending the effect.

**Failure** As success, except the weakness to fire lasts for 1 minute.

* * *

**Heightened (+2)** The weakness increases by 1.

## [[Beacon Mark]] Feat 8

**Prerequisites [[Tracing Sigil]]**

* * *

When you cast sigil, you can modify the spell to add the following heightened entry.

* * *

**Heightened (4th)** You attune yourself to the marked target. While the spell lasts, you can spend a single action, which has the concentrate, detection, and divination traits, to attempt to locate the target, learning the direction to the target as long as you are within 1 mile of it. If the target is a creature or a creature is in possession of the target object, the creature can attempt a Will saving throw against your spell DC. If it succeeds, your attempt to locate the target fails and you can't attempt this again for 1 day. You can only have a single target marked with a sigil modified in this way. If you Cast this Spell again on a second target, the sigil spell on the first target ends, and your mark fades.

## [[Larcenous Hand]] Feat 8

**Prerequisites** [[Agile Hand]], [[Pickpocket]] skill feat

* * *

When you cast mage hand, you can remove its duration, modify its range to 20 feet, and modify its target to be an attended object within the spell's Bulk limit that wouldn't be time-consuming to remove. Add the following to the spell's standard effects: If the creature attending the object is willing to have you take the item, mage hand carries the item to you. If the creature is unwilling, you must attempt to Steal the target object with a Thievery check. The usual restrictions on attempts to Steal an object apply, including the restrictions that you can't steal objects that would be extremely noticeable or time-consuming to remove (like worn shoes or armor or actively wielded objects) and you can't Steal from a creature in combat or otherwise on guard. On a successful Steal check, the mage hand carries the item to you, and on a critical failure, you can't use this modification again for 1 hour. If you're a master in Thievery, you can attempt to Steal from a creature in combat or otherwise on guard, though if you do so, the spell's casting time increases by 1 action.

## [[Lingering Flames]] Feat 8

**Prerequisites** [[Spell Trickster Dedication]] ability to cast _[[Fireball]]_

* * *

When you cast fireball, you can modify its effects, decreasing the base damage to 5d6 and causing it to deal 2 persistent fire damage to creatures that fail their save, doubled as normal on a critical failure. If you do, replace its heightened entry with the following.

* * *

**Heightened (+1)** The damage is increased by 1d6 and the persistent fire damage is increased by 2.

## [[Scattered Fire]] Feat 8

**Prerequisites** [[Spell Trickster Dedication]] ability to cast _[[Fireball]]_

* * *

When you cast fireball, you can modify its area to be two non-overlapping @Template\[type:burst|distance:10\]{10-foot bursts}.

## [[Siphoning Touch]] Feat 8

**Prerequisites** [[Spell Trickster Dedication]] ability to cast _[[Vampiric Feast]]_

* * *

When you cast vampiric touch, you can modify its standard effects as follows: Instead of gaining the temporary Hit Points yourself, you can grant the temporary Hit Points to an ally within 30 feet. After 1 minute, the ally loses any of these temporary Hit Points that remain.

## [[Smoldering Explosion]] Feat 8

**Prerequisites** [[Spell Trickster Dedication]] ability to cast _[[Fireball]]_

* * *

When you cast fireball heightened to at least 4th level, you can modify the spell to add the following to its standard effects: Your fireball leaves behind a brief cloud of smoke in its area. While it's smoke instead of mist, this cloud otherwise has the effects of obscuring mist, except that it lasts only 1 round.

## [[Steal Vitality]] Feat 8

**Prerequisites** [[Spell Trickster Dedication]] ability to cast _[[Vampiric Feast]]_

* * *

When you cast vampiric touch, you can modify its standard effects as follows: Instead of gaining temporary Hit Points, if your target fails or critically fails its saving throw, you can attempt a counteract check to remove the clumsy or enfeebled conditions on yourself, using the source of that condition to determine the counteract level and DC. If the condition was caused by an ongoing effect and you don't remove that effect, the condition returns at the end of your next turn.

## [[Surrounding Flames]] Feat 10

**Prerequisites** [[Spell Trickster Dedication]] ability to cast _[[Wall of Fire]]_

* * *

When you cast wall of fire, you can modify its standard effects as follows: Instead of a 5-foot-thick, 10-foot-radius ring of flame, you can form the wall into a 10-foot-radius hemisphere of fire.

## [[Toppling Tentacles]] Feat 10

**Prerequisites** [[Spell Trickster Dedication]] ability to cast _[[Black Tentacles]]_

* * *

When you cast black tentacles, replace the spell's standard effects with the following: Tentacles slither along the ground in the area, attempting to hinder anyone within. Sticky black tentacles attempt to Trip each creature in the area. Attempt spell attack rolls against the Reflex DCs of each affected creature. Any creature you succeed against is knocked [[Prone]] and takes @Damage\[3d6\[bludgeoning]] damage. Whenever a creature ends its turn in the area, the tentacles attempt to Trip that creature if it isn't already prone, and they deal @Damage\[1d6\[bludgeoning]] damage to any creature already prone. Creatures treat the spell's area as difficult terrain.

## [[Choking Smoke]] Feat 12

**Prerequisites** [[Smoldering Explosion]]

* * *

When you cast fireball heightened to at least 6th level, you can modify the spell's standard effects as follows: Reduce the spell's damage by 6d6. Your fireball leaves behind a lingering cloud of toxic smoke in its area. While it's smoke instead of mist, this cloud otherwise has the effects of stinking cloud.

## [[Directed Poison]] Feat 12

**Prerequisites** [[Spell Trickster Dedication]], ability to cast _[[Toxic Cloud]]_

* * *

When you cast _[[Toxic Cloud]]_, modify its duration to be sustained up to 1 minute, and modify its standard effect to include the following: The cloud doesn't move away from you each round. Once per round when you Sustain the Spell, you can move the cloud 10 feet in the direction of your choice.