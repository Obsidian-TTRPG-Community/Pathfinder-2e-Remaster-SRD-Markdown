---
title: "Vigilante"
icon: ":sticky-note:"
aliases: "Vigilante"
foundryId: Compendium.pf2e.journals.JournalEntry.vx5FGEG34AxI2dow.JournalEntryPage.rtAFOZOjWHC2zRNO
tags:
  - JournalEntryPage
---

# Vigilante
As a vigilante, you have two faces: a public persona, and a secret identity that lets you hide your extralegal actions from polite society. Your secret identity lets you adventure and carry out clandestine missions while keeping the civilians you care about safe. Whatever your purpose- fighting crime, inciting rebellion, sowing chaos-your vigilante identity makes you both hard to pin down and a mysterious, intriguing subject of gossip.

**Additional Feats** 4th [[Quick Draw]]

## [[Vigilante Dedication]] Feat 2

**Prerequisites** trained in Deception

* * *

You have two identities, each with its own name, alignment, and abilities. Your social identity is an upstanding member of society, while your vigilante identity is a skilled and cunning warrior. Neither of these identities is a false front; you really are both of these people, and as such, your two identities can be at most one alignment step from each other (for instance, you could be neutral in one identity and neutral evil in the other, but not chaotic evil in the other). If someone attempts to discern your other identity, they must use a Seek action to attempt a Perception check against your Deception DC, as if you were using the Impersonate action. Your Deception DC against such attempts is 20 + your proficiency modifier instead of the normal DC. Unlike with Impersonate, you don't have to attempt a Deception check to interact with someone to conceal your other identity-a check happens only if someone else specifically tries to uncover your other identity.

Changing from one identity to the other takes 1 minute and must be done out of sight from other creatures. As this process involves both physical changes such as clothing and makeup along with an altered state of mind, other effects that change your appearance don't reduce the time required to change identities.

Your two identities are completely distinct. You have your current identity's alignment for effects that rely on alignment, though you are eligible for abilities that require a certain alignment (such as a cleric's deity) only if both of your identities qualify. Checks to Recall Knowledge about one of your identities don't reveal information about the other unless the person attempting the check knows both identities are the same person. Effects that detect you based on your identity, such as the detect alignment spell, work only if you are currently in the identity the effect is trying to detect; otherwise, the effect fails as if the target didn't exist.

To maintain the separation between your identities, some of your abilities have one of two traits: social or vigilante. You can use social feats only while in your social identity. Your class feats and vigilante feats are associated with your vigilante identity, and using them while in your social identity risks exposing you as a vigilante. This means that if you were particularly meek or inconspicuous before you took this feat, your identity could be at greater risk of exposure. If your identity is exposed to the public, you lose the benefits of Vigilante Dedication to disguising yourself, but you can otherwise use both social and vigilante abilities in either identity unless they rely on your identity being a secret. You can use feats that don't have either trait regardless of your current identity.

**Special** You can't select another dedication feat until you have gained two other feats from the Vigilante archetype.

## [[Hidden Magic]] Feat 4

**Prerequisites** expert in Arcana, Nature, Occultism, or Religion; Vigilante Dedication

* * *

You've learned to hide the magical auras of your gear. During your daily preparations, you carefully tweak any or all of your magic items to appear non-magical. Objects adjusted in this way remain so until your next preparations. A spellcaster using detect magic or read aura must succeed at a Perception check against your Deception DC to see through your obfuscations.

## [[Minion Guise]] Feat 4

**Prerequisites** animal companion or familiar, expert in Deception, Vigilante Dedication

* * *

When you are in your social identity, you can also grant a social identity to an animal companion, familiar, or other minion you gained from a class feature. When changing to your social identity, you also change your minion's appearance to that of a socially acceptable creature of its type, such as grooming a wolf to appear as a large dog or disguising a familiar to appear as an exotic pet. Commanding your minion to use unusual magical or combat abilities it gained from your class features or feats while in this social identity risks exposing your vigilante identity.

## [[Safe House]] Feat 4

**Prerequisites** Vigilante Dedication

* * *

You establish a safe house-a secure space in which to hide your secrets from the outside world. This safe house is roughly the size of a 10-foot cube. It's in a location you have access to, and it can be part of a larger building or structure, like a hidden room or an underground cave. The safe house protects objects and people inside it from magical detection. This has the effects of nondetection, using your Deception modifier for the counteract DC and half your level rounded up for the counteract level. Setting up or moving your safe house takes a week of downtime. The size of the safe house expands to four 10-foot cubes if you're an expert in Deception, eight cubes if you're a master, and 16 cubes if you're legendary.

## [[Social Purview]] Feat 4

**Prerequisites** Vigilante Dedication

* * *

You have built a reputation for yourself in your social identity. Choose one archetype that you meet the prerequisites for. You gain that archetype's dedication feat and can select feats from that archetype, even if you haven't yet gained enough feats in the vigilante archetype to take another dedication feat. These feats become part of your social identity and gain the social trait-for instance, a fighter vigilante could take the wizard dedication feat and have a wizard social identity. Using these feats in your social identity doesn't risk exposing your vigilante identity, but using them in your vigilante identity could put you at risk for exposure.

## [[Startling Appearance (Vigilante)|Startling Appearance]] Feat 6

**Prerequisites** Vigilante Dedication

**Requirements** You are completely unnoticed by the target creature.

* * *

You can startle foes who are unaware of your presence. Make a Strike against your target. That creature is off-guard against this Strike, as normal. If your Strike hits, the target remains off-guard for the rest of your turn and is frightened 1 (frightened 2 on a critical hit).

## [[Quick Change]] Feat 7

**Prerequisites** master in Deception, Vigilante Dedication

* * *

You can shift between your identities with ease. Instead of spending 1 minute to change your identity, you can now do so as a 3-action activity. If you are legendary in Deception, you can perform this change as a 1-action activity.

## [[Subjective Truth]] Feat 7

**Prerequisites** master in Deception, Vigilante Dedication

* * *

Your disparate identities allow you to defeat magic that detects lies. As long as what you say is true from the point of view of your current identity, you can say it even under effects like zone of truth that force you to speak the truth.

## [[Many Guises]] Feat 8

**Prerequisites** master in Deception, Vigilante Dedication

* * *

You can take on any number of mundane guises. Whenever you change your identity, instead of taking on your social or vigilante identity, you can become someone completely ordinary. This identity isn't a specific individual-rather, you become a nondescript member of your ancestry, of any gender, with a neutral alignment and a mundane occupation such as common laborer, farmer, or peasant. Spells and abilities detect you as if you were this ordinary identity, rather than either of your two real identities, unless they succeed at a counteract check against your Deception DC. You can't use either social abilities or vigilante abilities while in this identity.

## [[Frightening Appearance]] Feat 12

**Prerequisites** expert in Intimidation, Startling Appearance

* * *

Your dramatic appearances can frighten bystanders. When you make a Startling Appearance, you can also attempt to Demoralize each opponent within 10 feet to whom you were unnoticed before your Strike.

## [[Stunning Appearance]] Feat 16

**Prerequisites** Startling Appearance

* * *

Your sudden appearance leaves your foe unable to respond. When you use Startling Appearance, if your foe's level is equal to or lower than yours, they are also stunned 1 on a hit, or stunned 2 on a critical hit.