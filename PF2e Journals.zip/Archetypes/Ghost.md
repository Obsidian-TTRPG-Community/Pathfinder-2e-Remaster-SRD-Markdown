---
title: "Ghost"
icon: ":sticky-note:"
aliases: "Ghost"
foundryId: Compendium.pf2e.journals.JournalEntry.vx5FGEG34AxI2dow.JournalEntryPage.aIpIUbupTjw2863C
tags:
  - JournalEntryPage
---

# Ghost
Your ties to the living world cling to you in death, your unfinished business reducing you to a spirit. Your soul carries on, but your body is gone. Your mind, too, may have changed: though death can impact thoughts and desires in all sorts of ways, most ghosts experience stronger, more volatile emotions and are frequently overcome by their past ties. A need to reconcile the past overwhelms other needs. Motivations can change over time but are always strong. Pragmatism, compassion, and foresight fall before a ghost's fundamental desires.

## [[Ghost Dedication]] Feat 2

**Prerequisites** You died and returned as a ghost.

* * *

You have risen as a shell of your former self, a spirit of mist and anguish. You gain the ghost, spirit, and undead traits, and the [[Basic Undead Benefits]]. Your undead craving is to settle your unfinished business. You also gain the incorporeal trait, as described on page 218, except you can't pass through solid objects unless you select the [[Pass Through]] feat. Being a ghost has the following major effects.

**Floating** You can float but are still tethered to the ground. Replace your land Speed with an equal fly Speed. You can't rise more than a few inches above the ground when you Fly. This means you can move above many types of difficult or hazardous terrain without moving slowly or being damaged, even though you can't fly without limit. You can Leap, High Jump, Long Jump, and take similar actions, and use your fly Speed for any calculations that would normally require your land Speed.

**Items** You can transmute physical items to make them part of your incorporeal form. This requires spending 10 minutes with the items within reach, during which you transform the items into part of your form; you can return items you already have incorporated to a corporeal state at the same time. The items retain all their runes and other abilities, need to be invested normally if they have the invested trait, and need to be worn, held, or stowed appropriately. Once you've incorporated the items, you and other incorporeal creatures can use them normally—you can Interact with them, Release them, and so on. Your incorporated weapons gain the benefits of the ghost touch property rune, allowing you to use them normally against both corporeal and incorporeal creatures. Incorporated items become corporeal again only if you transmute them back or are destroyed, in which case, they drop to the ground under you.

**Attacks** Your unarmed attacks become magical and deal void damage instead of their normal type.

**Strength** Unlike most incorporeal creatures, your Strength modifier is not -5; you keep the same Strength score you had before you became a ghost, though you can only attempt Strength-based skill checks—typically Athletics checks—against other incorporeal creatures, as normal for an incorporeal creature. Against incorporeal creatures, use your Strength normally to determine the results of Athletics checks, Strikes with melee weapons, and any other checks or damage rolls dependent on Strength.

**Ties that Bind** When you become a ghost, work with your GM to choose a bound site and unfinished business, both of which matter for your character's story, as well as some ghost archetype feats. Your bound site tethers you to the physical world and is typically either a location important to you in life or the place where you died. Unfinished business keeps you from passing to the afterlife. If someone resolves your unfinished business, you decide whether to accept the change and pass on, or to fight it. If you pass on, you get a few minutes to say your goodbyes, and then move into the River of Souls and the afterlife. Your character ceases to be. If you fight the change, you remain, though you and the GM might determine a new unfinished business. If you are physically destroyed, you cease your existence as a ghost but still might not be able to pass on to the afterlife if your unfinished business is incomplete. In this liminal state, you might come across strange energies and become another sort of creature, or anchor to a summoner and become an eidolon.

## [[Frightful Moan]] Feat 4

**Prerequisites** Ghost Dedication

**Frequency** Once per 10 minutes

* * *

You lament your fate, forcing each living creature in a 30-foot emanation to attempt a Will save against your class DC or spell DC, whichever is higher.

**Success** The creature is unaffected and temporarily immune to Frightful Moans for 1 minute.

**Failure** The creature is frightened 1.

**Critical Failure** The creature is frightened 2.

## [[Ghostly Resistance]] Feat 4

**Prerequisites** Ghost Dedication

* * *

Your ghostly form becomes innately weaker but also gains resistance to many forms of damage. Your maximum HP is reduced by your level. You gain resistance 1 to all damage except for force, vitality, and any damage done by a weapon with the ghost touch rune (or any other source that acts like a ghost touch rune). This resistance increases to 2 if the source is non-magical. At 10th level, the resistance increases to 2, or 4 if the source is non-magical. At 16th level, the resistance increases to 3, or 5 if the source is non-magical.

## [[Ghostly Grasp]] Feat 6

**Prerequisites** Ghost Dedication

* * *

Your control over your ghostly form grows. You gain the [[Advanced Undead Benefits]] and can interact with physical objects, with limits. You can attempt Strength-based skill checks against physical creatures and objects. You can Interact with physical objects, but the action has no effect unless you succeed at a DC 20 Athletics or DC 20 Thievery check.

## [[Ghost Flight]] Feat 8

**Prerequisites** Ghost Dedication

**Frequency** Once per day

* * *

You can suppress your tether to the ground, overcoming your resistance to fly free. For 10 minutes, your fly Speed doesn't restrict you to only a few inches off the ground, allowing you to travel to any height you choose.

## [[Pass Through]] Feat 10

**Prerequisites** master in Acrobatics, Ghost Dedication

**Frequency** Once per 10 minutes

* * *

Filtering your form through the substance of an object, you can pass through walls, doors, and more. You Fly up to your Speed. During this movement, you can try to move through one object. Attempt an Acrobatics check as you try to enter its space. The DC is typically 30 to move through a wall of up to 5 feet, 15 for an ordinary door, and 10 for thinner structures like windows; the GM might set the DC higher for especially dense materials like adamantine or lead, or for barriers that are magically reinforced. You can't Pass Through an obstacle made of magical force, such as a wall of force.

**Success** You move through the object, treating the square within it as difficult terrain. If you end your turn inside an object, you can move out of it only if you Pass Through again or use some other means of moving through a solid object. As normal for being incorporeal, starting your turn inside an object makes you slowed 1 for that turn.

**Failure** Your movement ends, and you trigger reactions as if you moved out of the square you started in.

## [[Rejuvenation]] Feat 12

**Prerequisites** Ghost Dedication

* * *

The call of your unfinished business recreates you after destruction. When you're destroyed, you reform after 2d4 days within your bound site, fully healed. If your unfinished business is resolved while you're waiting, you pass on immediately unless you and the GM determine you have new unfinished business.

## [[Unlimited Ghost Flight]] Feat 14

**Prerequisites** Ghost Flight

* * *

You put your connection to the material world farther behind you. Your fly Speed no longer restricts the height you can fly. When you use Ghost Flight, instead of its normal effect, you gain a +10-foot status bonus to your fly Speed for 10 minutes.