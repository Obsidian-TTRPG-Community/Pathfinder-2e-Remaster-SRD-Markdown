---
title: "Beastmaster"
icon: ":sticky-note:"
aliases: "Beastmaster"
foundryId: Compendium.pf2e.journals.JournalEntry.vx5FGEG34AxI2dow.JournalEntryPage.4VMzG36Pm1oivS6Y
tags:
  - JournalEntryPage
---

# Beastmaster
You attract the loyalty of animals, and as your powers increase you can command more of them, briefly inhabit their body to perceive what they perceive, and even communicate with them over vast distances. Your animals may see you as a beloved parent, teacher, and mentor, or they may consider you a poor, defenseless cub that needs protection. Regardless, they will fight for you and alongside you, even sacrificing their lives for you if necessary.

**Additional Feats** 4th [[Magic Hide]], [[Animal Empathy (Ranger)]]; 6th [[Companion's Cry]]; 10th [[Enlarge Companion]]; 14th [[Side by Side (Ranger)|Side by Side]]. Warden spells granted by these feats are beastmaster focus spells for you.

* * *

**BEASTMASTER ANIMAL COMPANIONS**

If you're playing a beastmaster, you determine the statistics and abilities of your animal companions according to the basic rules for animal companions. As a beastmaster, it's possible for you to have more than one animal companion at one time-up to four companions-but only one of those companions, your "active companion," follows you during exploration and in encounters; the rest are nearby, usually foraging or hunting for food. As soon as you gain a second animal companion from the Beastmaster archetype, you also gain [[Call Companion]] to switch your active companion. These rules apply to all your companions, regardless of whether you got the animal companion from the beastmaster archetype or from another source.

## [[Beastmaster Dedication]] Feat 2

**Prerequisites** trained in Nature

* * *

You gain the service of a young animal companion that travels with you and obeys your commands. Contrary to the usual rules for animal companions, this feat can grant you a second animal companion. If you ever have more than one animal companion, you gain the Call Companion action. See the Beastmaster Animal Companions sidebar for details on this action.

Certain beastmaster feats give you primal focus spells. When you gain your first beastmaster focus spell, you become trained in primal spell attack rolls and spell DCs, and your spellcasting ability for these spells is Charisma. Feats that grant beastmaster focus spells tell you to increase the number of Focus Points in your pool, but if you don't already have a focus pool, you instead get a focus pool with 1 Focus Point. You can Refocus by grooming, feeding, playing with, or otherwise tending to an animal companion.

**Special** You can't select another dedication feat until you have gained two other feats from the beastmaster archetype.

## [[Additional Companion]] Feat 4

**Prerequisites** Beastmaster Dedication

* * *

Another animal joins you in your travels. It is a young animal companion that has the minion trait. See Beastmaster Animal Companions for rules on how having multiple animal companions works.

**Special** You can select this feat more than once, gaining an additional animal companion each time, to a maximum of four total companions (including the one you gained from Beastmaster Dedication and possibly one you gained from sources other than the beastmaster archetype).

## [[Heal Animal]] Feat 4

**Prerequisites** Beastmaster Dedication

* * *

You can heal your animal companion's wounds. You can cast heal animal as a beastmaster focus spell. Increase the number of Focus Points in your focus pool by 1.

## [[Mature Beastmaster Companion]] Feat 4

**Prerequisites** Beastmaster Dedication

* * *

All of your animal companions grow up, becoming mature animal companions and gaining additional capabilities. During an encounter, even if you don't use the Command an Animal action, your animal companion can still use 1 action on your turn to either Stride or Strike.

## [[Beastmaster's Trance]] Feat 6

**Prerequisites** Beastmaster Dedication

* * *

You can enter a trance that allows you to briefly inhabit the body of one of your animal companions and share its senses. You gain the focus spell beastmaster trance. Increase the number of Focus Points in your focus pool by 1.

## [[Incredible Beastmaster Companion]] Feat 8

**Prerequisites** Mature Beastmaster Companion

* * *

Your mature animal companions continue to grow and develop. They each become nimble or savage animal companions (your choice, choose for each companion, including those that become mature after you take this feat), gaining additional capabilities determined by the type of companion.

## [[Beastmaster Bond]] Feat 10

**Prerequisites** Beastmaster Dedication

* * *

You can communicate telepathically with your animal companions within 100 feet. If you're legendary in Nature, you can communicate telepathically with your animal companions anywhere on the planet.

## [[Beastmaster's Call]] Feat 12

**Prerequisites** Beastmaster Dedication, Call Companion

**Frequency** once per turn

* * *

You quickly call in a primal projection of a non-active companion to provide the companion's support benefit. The projection arrives in an unoccupied square of your choice within 30 feet of you, grants you its support benefit, and then disappears on your next turn. The projection has the same AC and saving throw modifiers as the real companion, and if it would take any damage before your next turn, it disappears and the support benefit ends immediately.

## [[Specialized Beastmaster Companion]] Feat 14

**Prerequisites** Incredible Beastmaster Companion

* * *

Your nimble and savage animal companions become cunning enough to become specialized. Each companion gains one specialization of your choice (choose separately).

**Special** You can select this feat more than once. Each time, add a different specialization to your nimble and savage companions. Your nimble and savage companions can have up to three specializations each.

## [[Lead The Pack]] Feat 16

**Prerequisites** Mature Beastmaster Companion, you chave multiple animal companions

* * *

You can have up to two animal companions active at once. However, when you do, it's slightly more difficult to Command them. If you don't Command either of your companions, one of the two (your choice) can still use 1 action on your turn to Stride or Strike, as per Mature Beastmaster Companion, but not both. When you Command an Animal, either choose one of the companions to take 2 actions, as normal, or else both companions can take 1 action to Stride or Strike. Either way, you can't Command an Animal to make either companion act again until your next turn.