---
title: "Duelist"
icon: ":sticky-note:"
aliases: "Duelist"
foundryId: Compendium.pf2e.journals.JournalEntry.vx5FGEG34AxI2dow.JournalEntryPage.BwPUY2X7TSmlJj5c
tags:
  - JournalEntryPage
---

# Duelist
Across the world, students in martial academies practice with their blades to master one-on-one combat. The libraries of such schools hold deep troves of information detailing hundreds of combat techniques, battle stances, and honorable rules of engagement. Those who gain admission to such schools might train in formalized duels-and that's certainly the more genteel route to take. However, others assert that there's no better place to try out dueling techniques than in the life-and-death struggles common to an adventurer's life.

**Additional Feats** 4th [[Dueling Parry (Fighter)|Dueling Parry]]; 8th [[Disarming Stance]]; 10th [[Dueling Riposte]]; 12th [[Disarming Twist]]; 14th [[Dueling Dance (Fighter)|Dueling Dance]], [[Improved Dueling Riposte]]; 16th [[Guiding Riposte]]

## [[Duelist Dedication]] Feat 2

**Prerequisites** trained in light armor and simple weapons

* * *

You are always ready to draw your weapon and begin a duel, no matter the circumstances. You gain the Quick Draw ranger feat, enabling you to both draw and attack with a weapon as 1 action. This serves as Quick Draw for the purpose of meeting prerequisites.

**Special** You can't select another dedication feat until you have gained two other feats from the duelist archetype.

## [[Duelist's Challenge]] Feat 4

**Prerequisites** Duelist Dedication

* * *

Select one foe that you can see and proclaim a challenge. That foe is your dueling opponent until they are defeated, flee, or the encounter ends. Any time you hit that enemy using a single one-handed melee weapon while your other hand or hands are free, you gain a circumstance bonus to the Strike's damage equal to the number of damage dice your weapon deals.

If you attack a creature other than your dueling opponent, you take a circumstance penalty to damage equal to the number of damage dice your weapon deals.

## [[Selfless Parry]] Feat 8

**Prerequisites** Dueling Parry, Duelist Dedication

* * *

You protect those near you with a flash of steel. When you're benefiting from Dueling Parry, allies adjacent to you gain a +1 circumstance bonus to AC. If you have Dueling Riposte, you can use it when an enemy within your reach critically fails a Strike against an ally adjacent to you, not just against yourself.

## [[Student Of The Dueling Arts]] Feat 12

**Prerequisites** Duelist Dedication

* * *

You have studied a great many combat techniques, which you can review each day. During your daily preparations, you can swap out any number of your duelist archetype feats for other duelist archetype feats of the appropriate level for which you are qualified. You can't swap out Duelist Dedication or Student of the Dueling Arts in this way.

In addition, you can enter a stance from a duelist archetype feat you don't have (such as one listed under Additional Feats) by increasing the number of actions it takes to enter the stance by 1 (typically to 2 actions). You must still meet the feat's prerequisites.