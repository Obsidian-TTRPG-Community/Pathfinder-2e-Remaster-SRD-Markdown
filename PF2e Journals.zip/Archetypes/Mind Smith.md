---
title: "Mind Smith"
icon: ":sticky-note:"
aliases: "Mind Smith"
foundryId: Compendium.pf2e.journals.JournalEntry.vx5FGEG34AxI2dow.JournalEntryPage.mXywYJJCM9IVItZz
tags:
  - JournalEntryPage
---

# Mind Smith
“The mind makes it real.” Though uttered in many parts of Golarion, nowhere is this more literal than perhaps among mind smiths—those with a mysterious mental talent that allows them to manifest their mind into a physical object. Some gain this power through magical training from an ancestor or mentor, while others earn it as a gift or reward from some greater being, or by inexplicable chance. Whatever the source, you have mastered the ability to form a mental image into a corporeal figment solid enough to affect the physical world. You trained the power to aid you in battle by shaping itself into a potent weapon, bound by only the reaches of your own imagination.

## [[Mind Smith Dedication]] Feat 2

You've learned to imagine a shape in your mind, to envision it so strongly it takes form in the material world. You gain a single melee weapon of your choosing, called a mind weapon. Your mind weapon is a martial melee weapon. The overall shape and design of your mind weapon can be of your choosing but it has one of the following four basic statistics:

*   A one-handed weapon that deals 1d4 damage and has the agile and finesse traits
*   A one-handed weapon that deals 1d6 damage and has the finesse trait
*   A one-handed weapon that deals d8 damage
*   A two-handed weapon that deals 1d10 damage and has the reach trait

Each day during your daily preparations, you can decide if you want your weapon to deal bludgeoning damage and be in the club weapon group, deal piercing damage and be in the spear weapon group, or deal slashing damage and be in the sword weapon group. Your mind weapon is an extension of your mind-it has no Hardness, and any ability that would damage your mind weapon instead damages you directly, pushing back against the weapon's corporeal form and becoming mental damage of the same amount the weapon would have taken.

You can project your mind weapon using an Interact action, just as you would draw any other weapon. Only you can hold, carry, or wield your mind weapon; if held by another person, it quickly disappears from their hand, reforming in your mind for you to project again. If you're disarmed of your mind weapon, it dematerializes, but you can draw it again with an Interact action starting at the beginning of your next turn.

Upon creating your mind weapon, you also learn to use a mind smith's keepsake: an object of light Bulk, such as a bracelet or figurine, that you wear or keep on your person and inscribe with weapon runes. Your keepsake can't be a magic item, nor can it have any significant monetary value beyond the value of any runes you inscribe on it. You can buy and inscribe fundamental runes and weapon property runes onto your keepsake in the same way you would for a regular weapon, and you can move runes to and from your keepsake to other weapons or runestones for the usual cost. Any runes inscribed on the keepsake apply to your mind weapon when you create it. If your keepsake is ever lost or destroyed, you can spend 1 week of downtime imprinting a new object with your weapon's mental properties, though this new keepsake won't have any of the runes that were inscribed on the prior keepsake.

* * *

**Special** You can't select another dedication feat until you have gained two other feats from the mind smith archetype.

## [[Malleable Movement]] Feat 2

**Prerequisites** Mind Smith Dedication; expert in Athletics

**Trigger** You Leap.

* * *

You shift the shape of your weapon to help you Leap farther and faster. You shift your weapon into a long flexible pole, climbing hook, or similar aid, adding an extra 5 feet to the distance you're able to Leap. As normal, this can't increase the distance of your Leap beyond your Speed.

## [[Ghost Blade]] Feat 4

**Prerequisites** Mind Smith Dedication

**Frequency** once per hour

* * *

You alter your weapon's phase so it can more easily strike incorporeal creatures. Your mind weapon gains the effects of a _[[Ghost Touch]]_ property rune for 1 minute

## [[Just the Tool]] Feat 4

**Prerequisites** Mind Smith Dedication

* * *

You temporarily change your weapon's shape to assist you in the field. You morph your weapon into a single simple tool, such as a shovel or crowbar, to help with a mundane task. You can't replicate entire tool kits with this ability. You can use this action again to change your mind weapon back to a weapon.

## [[Mental Forge]] Feat 4

**Prerequisites** Mind Smith Dedication

* * *

Your experiences in combat shape your mind's capability to strengthen and shape your weapon to match the way you move in combat. Choose two of the following weapon traits to give your mind weapon: grapple, modular (B, P, S), nonlethal, shove, or trip. Once chosen, these weapon traits can't be changed unless you spend 1 week retraining your fighting style to swap one property for another from the list.

## [[Mind Shards]] Feat 6

**Prerequisites** Mind Smith Dedication

* * *

With a swing and a thought, you detonate your mind weapon into a burst of psychic shards that shred the mind. You concentrate and unleash a @Template\[type:cone|distance:15\] that deals @Damage\[3d6\[mental]] damage to all creatures in the area, with a @Check\[type:will|dc:resolve(@actor.system.attributes.classOrSpellDC.value)|basic:true\] save against the higher of your class DC or spell DC. After the attack, your mind weapon automatically re-forms, and you can't use this ability again for 1 minute. Mind Shards' damage increases by 1d6 at level 7 and every two levels thereafter.

[[/r (ceil(@actor.level/2)d6)\[mental]]\]{Leveled Mental Damage}

## [[Malleable Mental Forge]] Feat 8

**Prerequisites** Mental Forge

* * *

You open your mind to further weapon customization. During your daily preparations, you can choose any two weapon traits from the Mental Forge feat to place on your weapon for 24 hours or until your next daily preparations (whichever comes first), replacing the traits you chose from the Mental Forge feat. Each day you can swap the choices with any other options on the list.

## [[Mind Projectiles]] Feat 8

**Prerequisites** Mind Smith [[Metallic Envisionment|Dedication]]

* * *

You have learned to stretch your mind's influence further, releasing projectiles with a swing of your mind weapon. You can make ranged mind weapon Strikes; these are ranged Strikes with a maximum range of 30 feet that deal [[/r 1d6]]{1d6} damage of the same type as your mind weapon. Your ranged mind weapon Strike gains all the benefits of your mind weapon's runes as long as they still apply to a ranged weapon. For example, if your weapon had _+1_, _striking_, and _spell storing_ runes, you would get a +1 item bonus to hit with your ranged mind weapon Strike, and it would deal the additional damage from the _striking_ rune, but it wouldn't be able to unleash a spell from the _spell storing_ rune, as that rune can be etched onto only melee weapons.

## [[Runic Mind Smithing]] Feat 10

**Prerequisites** Mind Smith Dedication

* * *

You focus your mind on thoughtforms of fundamental magical forces, shaping them into a property rune that you mentally etch onto your mind weapon. During your daily preparations, choose one rune from the following list of weapon property runes: _corrosive_, _disrupting_, _flaming_, _frost_, _shock_, and _thundering_. You enhance your weapon with the chosen rune until your next daily preparations. This rune counts toward your maximum limit of runes as normal.

## [[Metallic Envisionment]] Feat 12

**Prerequisites** Mind Smith Dedication

* * *

You always account for every weakness, allowing your mind to imagine just the right physical form to take advantage of your opponents. Choose between cold iron or silver; all your mind weapon Strikes are treated as the chosen type of metal.

## [[Advanced Runic Mind Smithing]] Feat 16

**Prerequisites** Runic Mind Smithing

* * *

Your mind can hold onto more complicated patterns than ever before. You can etch the greater forms of any runes on the list from the Runic Mind Smithing feat and add them to the list of options you can choose during your daily preparations, as well as the _anarchic_, _axiomatic_, _holy_, or _unholy_ runes.

In addition, once per day, you can spend 10 minutes of uninterrupted focus to swap your daily prepared rune from Runic Mind Smithing to another rune from the same list. Once this swap is made, that second rune remains on the weapon until your next daily preparations.