---
title: "Artillerist"
icon: ":sticky-note:"
aliases: "Artillerist"
foundryId: Compendium.pf2e.journals.JournalEntry.vx5FGEG34AxI2dow.JournalEntryPage.bkTCYlTFNifrM3sh
tags:
  - JournalEntryPage
---

# Artillerist
The artillerist's maxim holds that while fights might be won with swords, battles are won with cannons. Or in a pinch, with trebuchets, siege towers, catapults, hwachas, and all other lethal miscellanea of a combat engineers' corp. As a true artillerist, you leave the penny-ante pistols and knives to those who only need to operate on a small scale. You're a consummate professional in the art of big guns, a maestro at merging mathematics and manpower to transform whatever castle wall, infantry battalion, or rampaging dragon offends you into a smoking crater in the ground.

You're not just some daredevil demolitionist, though. You're part of a team, accustomed to coordinating with your unit to maximize your time and effectiveness. Whether jumping in to help your crew load the next round, quickly calculating the trajectory of the engine's next shot, or taking the shot yourself, your presence on the team ensures their chances of success are maximized, creating a whole that is greater than the sum of its parts.

#### Leading with a Cannon

A proper artillerist is more than an engineer, though their skills in that field certainly shouldn't be underestimated. When a war becomes unavoidable, the presence of knights and pikemen might decide a skirmish or battle, but a well-trained artillerist with a reliable squad and a few good siege weapons can make the difference between prolonged months of battle with countless lives lost and a shorter, less bloody affair with fewer deaths and a more lasting victory.

Castles and fortifications are critical tools for holding land in a world full of empires, kingdoms, and duchies all vying for power. Many wars are won or lost not based on the military might of either side, but on a castle's ability to withstand an extended siege. Without a team of engineers capable of penetrating a castle or keep's defenses, the occupants can wait out an invading force for as long as they have enough food and water to keep their citizens and defenders healthy and fed. Many wars have been “won” when the besieged force manages to last through a single winter. Besieging armies whose supply lines break down due to snow-clogged passes or insufficient cold weather gear are forced to retreat due to losses from poor hygiene or hypothermia long before attrition has had an opportunity to impact their opponents.

An artillerist changes this dynamic, completely rewriting the rules of war. Rather than time being on the side of the besieged, it becomes the tool of the besieger. Each day that passes while a skilled artillerist hammers the castle walls with cannon fire and catapult stones brings the fortifications ever closer to crumbling down. Some wise nobles and warlords who realize their opponents have brought siege weapons, especially powerful black powder siege weapons like cannons, will choose to negotiate surrender before battle is even started, recognizing an inevitable defeat that can be staved off temporarily by sacrificing many soldiers but not thwarted without outside intervention.

Ruthless or evil artillerists, or the warlords they follow, might take things a step further, specifically targeting granaries to starve enemies out or launching rotting food, corpses, or diseased livestock into parts of the town near water sources. As food and water supplies dwindle, so too does the morale of the castle's inhabitants and defenders. Even a stubborn noble or warlord will find it hard to continue resisting a siege when their own troops mutiny and their citizens begin seeking a way out.

## [[Artillerist Dedication]] Feat 2

**Prerequisites** trained in martial weapons

* * *

Artillery is a team sport, where every member of the crew has to rely on the other members. At best, a mistake might just waste time. At worst, a misaligned fuse or a badly set pin could cause the whole thing to explode. You've taken these lessons to heart, and so your presence on an artillery team assists the entire team at every aspect of the siege weapon's deployment and usage. If you're serving on a siege weapon crew, you and all other members gain a +2 circumstance bonus to any checks to Load, Aim, move, or Repair the weapon. When you Aim a siege weapon, you can move the weapon's aim twice as far as normal.

**Special** You can't select another dedication feat until you've gained at least two other feats from the artillerist archetype.

## [[Named Artillery]] Feat 4

**Prerequisites** trained in Crafting

* * *

It is a tradition among artillerists to name the siege weapon most important to them and closest to their heart—much as a sailor on a ship, the weapon is their livelihood. You've gone a step further, and you always make sure that your named artillery has the best possible maintenance and upkeep. You can spend a full day adjusting and working on a single siege weapon to designate it as your named artillery. The siege weapon you designated as your named artillery gains a +2 circumstance bonus to AC, Fortitude saves, and Reflex saves as well as additional Hit Points equal to twice your level.

During your daily preparations, you must spend at least one hour on maintenance to service your named artillery. If you fail to do so, or if you spend a full day designating a new piece of named artillery, the previous named artillery loses any benefits from this feat. Only one artillerist can designate a particular siege weapon as their named artillery, even if several artillerists are serving on the same siege weapon's crew (though it's typically more efficient for a group with several artillerists to divide them up, assigning one to each siege weapon).

## [[Shorthanded]] Feat 4

* * *

Typically, a siege weapon is meant to be run by a crew with a very specific minimum number of members designed to ensure that your crew can account for every possible variable and necessity in loading, aiming, and firing the weapon. In a pinch, however, you can operate it with fewer people, provided you know what you're doing. You can operate a siege weapon with fewer than the minimum number of crew, at an increasing penalty. You and your crew take a -2 penalty to checks to Load, Aim, Launch, move, or Repair the weapon for each person below the minimum crew. The maximum number of missing minimum crew members you can handle with this feat is 5. For example, if a siege weapon had a minimum crew size of 8, you would still need a crew of 3, and you would take a -10 penalty when doing so.

## [[Cannon Corner Shot]] Feat 6

* * *

By loading special ammunition in a particular way, you can make your siege weapons do all manner of tricks that other siege engineers can barely even imagine. If you personally contribute an additional Load action to the siege weapon's loading, above the minimum, you can change a burst into a line twice as long as the size of the burst, or vice versa (so a 10-foot burst turns into a 20-foot line, or a 20-foot line turns into a 10-foot burst).

## [[Field Artillery]] Feat 6

**Prerequisites** expert in Crafting

* * *

While castles are generally obliging enough to stay in one place, out in the field positioning is of paramount importance—a gun in the wrong place is worse than useless. You can Interact with an adjacent mounted siege weapon to increase its Speed by 10 feet for one round.

## [[Live Ammunition]] Feat 8

* * *

There are generally few things as ill-advised as being shot out of a cannon or launched by a trebuchet, but people use the tactic every so often in a desperate situation. While it's more humane to use this strategy with mindless constructs or undead, occasionally an exceedingly foolhardy adventurer demands the opportunity to try it. Loading a creature requires two additional Load actions, which you must conduct personally. The creature must be willing, unconscious, or restrained throughout the process, and the siege weapon must be physically capable of firing the creature in question, based on their size and shape. Typically, that means ballistas don't qualify, for example—nor do auto-catapults which require specifically-sized balls—but normal catapults and onagers work just fine. When you Launch the weapon, if the weapon usually targets an area, you target a single 5-foot square instead. The siege weapon deals its normal damage to its target, or to the modified area, and to the creature fired.

## [[Master Siege Engineer]] Feat 16

* * *

What you don't know about artillery isn't worth knowing and your mastery allows you to perform an impossible number of actions as part of a siege weapon's crew. You're permanently quickened. You can only use the extra action to Aim or Launch a siege weapon.