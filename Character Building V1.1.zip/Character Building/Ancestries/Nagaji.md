---
title: "Nagaji"
icon: ":luggage:"
aliases: "Nagaji"
foundryId: Item.Vu33AzDfUlrYuWfw
tags:
  - Item
---

# Nagaji
![[systems-pf2e-icons-default-icons-ancestry.svg|150]]

With humanoid figures and serpentine heads, nagaji are heralds, companions, and servitors of powerful nagas. They hold a deep reverence for holy areas and spiritual truths, an aspect many others find as intimidating as a nagaji's appearance.

[[Nagaji]]
