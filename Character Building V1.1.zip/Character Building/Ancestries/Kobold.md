---
title: "Kobold"
icon: ":luggage:"
aliases: "Kobold"
foundryId: Item.4Q845UE4JYoeWYbd
tags:
  - Item
---

# Kobold
![[systems-pf2e-icons-default-icons-alternatives-ancestries-kobold.svg|150]]

_Every kobold knows that their slight frame belies true, mighty draconic power. They are ingenious crafters and devoted allies within their warrens, but those who trespass into their territory find them to be inspired skirmishers, especially when they have the backing of a draconic sorcerer or true dragon overlord. However, these reptilian opportunists prove happy to cooperate with other humanoids when it's to their benefit, combining caution and cunning to make their fortunes in the wider world._

_[[Kobold]]_
