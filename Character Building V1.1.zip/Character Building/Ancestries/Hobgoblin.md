---
title: "Hobgoblin"
icon: ":luggage:"
aliases: "Hobgoblin"
foundryId: Item.BcL8SY2SQuKBdH1f
tags:
  - Item
---

# Hobgoblin
![[systems-pf2e-icons-default-icons-alternatives-ancestries-hobgoblin.svg|150]]

_Taller and stronger than their goblin kin, hobgoblins are equals in strength and size to humans, with broad shoulders and long, powerful arms._

_[[Hobgoblin]]_
