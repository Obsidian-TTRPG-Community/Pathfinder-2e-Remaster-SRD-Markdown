---
title: "Vishkanya"
icon: ":luggage:"
aliases: "Vishkanya"
foundryId: Item.S0oav4EsZ8rorUHF
tags:
  - Item
---

# Vishkanya
![[systems-pf2e-icons-default-icons-ancestry.svg|150]]

Vishkanyas are ophidian humanoids who carry potent venom within their blood and saliva. Largely misunderstood due to old tales of their toxicity and natural finesse, vishkanyas work to grow into more than just what stories paint them to be.

[[Vishkanya]]
