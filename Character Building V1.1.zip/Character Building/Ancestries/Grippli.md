---
title: "Grippli"
icon: ":luggage:"
aliases: "Grippli"
foundryId: Item.vSpmAyF5T8DgRHIe
tags:
  - Item
---

# Grippli
![[systems-pf2e-icons-default-icons-alternatives-ancestries-grippli.svg|150]]

_Gripplis are a shy and cautious people who generally seek to avoid being drawn into the complicated and dangerous affairs of others. Despite their outlook and small stature, gripplis often take bold and noble action when the situation demands it._

_[[Grippli]]_
