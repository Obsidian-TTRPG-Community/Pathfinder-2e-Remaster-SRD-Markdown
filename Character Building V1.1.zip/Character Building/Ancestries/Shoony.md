---
title: "Shoony"
icon: ":luggage:"
aliases: "Shoony"
foundryId: Item.PCIKbqzMSRHJOkme
tags:
  - Item
---

# Shoony
![[systems-pf2e-icons-default-icons-alternatives-ancestries-shoony.webp|150]]

_Diminutive humanoids who resemble squat, bipedal dogs, shoonies are sometimes mistaken for weak and insular pacifists. However, their sheer perseverance, incredible work ethic, and resourceful use of diplomacy make shoonies far from helpless._

_[[Shoony]]_
