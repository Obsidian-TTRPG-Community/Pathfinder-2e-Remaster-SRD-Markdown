---
title: "Dwarf"
icon: ":luggage:"
aliases: "Dwarf"
foundryId: Item.lgxTk1YsPhuIl5RF
tags:
  - Item
---

# Dwarf
![[systems-pf2e-icons-default-icons-alternatives-ancestries-dwarf.svg|150]]

_Dwarves have a well-earned reputation as a stoic and stern people, ensconced within citadels and cities carved from solid rock. While some see them as dour and humorless crafters of stone and metal, dwarves and those who have spent time among them understand their unbridled zeal for their work, caring far more about quality than quantity. To a stranger, they can seem untrusting and clannish, but to their friends and family, they are warm and caring, their halls filled with the sounds of laughter and hammers hitting anvils._

_[[Dwarf]]_
