---
title: "Keen Eyes"
icon: ":luggage:"
aliases: "Keen Eyes"
foundryId: Item.HhtSLiGT2FKiPCbo
tags:
  - Item
---

# Keen Eyes
![[systems-pf2e-icons-features-ancestry-keen-eyes.webp|150]]

Your eyes are sharp, allowing you to make out small details about [[Concealed]] or even [[Invisible]] creatures that others might miss. You gain a +2 circumstance bonus when using the [[Seek]] action to find [[Hidden]] or [[Undetected]] creatures within 30 feet of you. When you target an opponent that is concealed from you or hidden from you, reduce the DC of the flat check to 3 for a concealed target or 9 for a hidden one.
