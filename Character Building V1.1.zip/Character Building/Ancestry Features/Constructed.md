---
title: "Constructed"
icon: ":luggage:"
aliases: "Constructed"
foundryId: Item.tgJioGIY1XZgrogf
tags:
  - Item
---

# Constructed
![[systems-pf2e-icons-features-feats-effect-repair-module.webp|150]]

Your synthetic body resists ailments better than those of purely biological organisms. You gain a +1 circumstance bonus to saving throws against diseases, poisons, and radiation.
