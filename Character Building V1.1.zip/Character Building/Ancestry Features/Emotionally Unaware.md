---
title: "Emotionally Unaware"
icon: ":luggage:"
aliases: "Emotionally Unaware"
foundryId: Item.4Nx1Ex9ltXugSebT
tags:
  - Item
---

# Emotionally Unaware
![[icons-magic-control-fear-fright-white.webp|150]]

You find it difficult to understand and express complex emotions. You take a -1 circumstance penalty to Diplomacy and Performance checks, and on Perception checks to Sense Motive.
