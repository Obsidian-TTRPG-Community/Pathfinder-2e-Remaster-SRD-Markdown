---
title: "Constructed (Poppet)"
icon: ":luggage:"
aliases: "Constructed (Poppet)"
foundryId: Item.RmNTj6gswNDkcUfH
tags:
  - Item
---

# Constructed (Poppet)
![[icons-magic-control-voodoo-doll-pain-damage-yellow.webp|150]]

The materials of your body resist ailments that assail the flesh. You gain a +1 circumstance bonus to saving throws against death effects, disease, and poison as well as to saving throws against effects that would give you the drained, paralyzed, or sickened conditions. Your spark of life means that you're a living creature, and you can be healed by vitality energy and harmed by void energy as normal.
