---
title: "Land on Your Feet"
icon: ":luggage:"
aliases: "Land on Your Feet"
foundryId: Item.GAhR7UdllHRkPmJu
tags:
  - Item
---

# Land on Your Feet
![[systems-pf2e-icons-features-ancestry-land-on-your-feet.webp|150]]

When you fall, you take only half the normal damage and don't land [[Prone]].
