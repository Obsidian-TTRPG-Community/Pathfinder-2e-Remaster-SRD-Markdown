---
title: "Flammable"
icon: ":luggage:"
aliases: "Flammable"
foundryId: Item.RRW6QCes3lZGeW9T
tags:
  - Item
---

# Flammable
![[icons-magic-fire-flame-burning-skeleton-explosion.webp|150]]

You have weakness to fire damage equal to one-third your level (minimum 1).
