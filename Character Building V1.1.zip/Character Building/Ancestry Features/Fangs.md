---
title: "Fangs"
icon: ":luggage:"
aliases: "Fangs"
foundryId: Item.NXlOrwQtSoJNEMax
tags:
  - Item
---

# Fangs
![[systems-pf2e-icons-unarmed-attacks-mandibles.webp|150]]

You were born with a natural means for hunting and self-defense. You gain a fangs unarmed attack that deals 1d6 piercing damage. Your fangs are in the brawling group and have the finesse and unarmed traits.
