---
title: "Broken Tusk Recruiter"
icon: ":luggage:"
aliases: "Broken Tusk Recruiter"
foundryId: Item.N3JUF7TB1IGnRbI3
tags:
  - Item
---

# Broken Tusk Recruiter
![[systems-pf2e-icons-default-icons-background.svg|150]]

Your gifted tongue, friendly demeanor, and deep knowledge of Broken Tusk culture and traditions make you an ideal recruiter for new followers. Whenever Broken Tusks come upon weak, weary, or wandering souls, you're often the first sent to meet these folks and determine if they would be a good fit for the following.

Choose two ability boosts. One must be to **Constitution** or **Charisma**, and one is a free ability boost.

You're trained in the Diplomacy skill and the Hillcross Lore skill. You gain the [[Group Impression]] skill feat.
