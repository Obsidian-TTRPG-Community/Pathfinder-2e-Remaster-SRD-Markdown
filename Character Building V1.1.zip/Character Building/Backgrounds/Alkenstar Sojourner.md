---
title: "Alkenstar Sojourner"
icon: ":luggage:"
aliases: "Alkenstar Sojourner"
foundryId: Item.M5o0SvxPpKxcJ8sa
tags:
  - Item
---

# Alkenstar Sojourner
![[systems-pf2e-icons-default-icons-background.svg|150]]

You came to Alkenstar because you heard they had guns, but you stayed because of the atmosphere. Or the guns. Either way, journalism and scientific curiosity opened the door to a life of adventure. Now you continue to adventure in the Alkenstar area, using your skills to deal with whatever situations present themselves.

Choose two ability boosts. One must be to **Intelligence** or **Charisma**, and one is a free ability boost.

You're trained in Society and Engineering Lore. You gain the [[Streetwise]] skill feat.
