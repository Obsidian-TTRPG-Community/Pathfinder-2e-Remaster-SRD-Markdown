---
title: "Butcher"
icon: ":luggage:"
aliases: "Butcher"
foundryId: Item.YlKZlvW6FyRZAZf8
tags:
  - Item
---

# Butcher
![[systems-pf2e-icons-default-icons-background.svg|150]]

You've spent uncounted hours walking up and down crowded and noisy circus stands, inventing innovative means to sell refreshments, food, and novelties at inflated prices. (You might know very little about slaughtering animals; "butcher" is a circus slang term for a vendor.) The Celestial Menagerie constantly pushed you to figure out how to sell increasingly shoddy toys to children and how to conceal the taste of spoiled treats that should have been discarded days earlier. You peddled disappointment and hated it, so you left to seek a new line of work-although you're not yet willing to leave the circus life altogether.

Choose two ability boosts. One must be to **Constitution** or **Intelligence**, and one is a free ability boost.

You're trained in the Society skill and the Mercantile Lore skill. You gain the [[Read Lips]] skill feat.
