---
title: "Bonuwat Wavetouched"
icon: ":luggage:"
aliases: "Bonuwat Wavetouched"
foundryId: Item.ACkVytBpBGDIzwXc
tags:
  - Item
---

# Bonuwat Wavetouched
![[systems-pf2e-icons-default-icons-background.svg|150]]

**Prerequisite** Region - Mwangi Expanse

* * *

You are a child of the Bonuwat people, and the sea's salt flows through your veins. You've taken to sailing and swimming gracefully and with ease, earning you the honorific "wavetouched."

Choose two ability boosts. One must be to **Strength** or **Wisdom**, and one is a free ability boost.

You're trained in the Athletics skill and the Ocean Lore skill. You gain the [[Underwater Marauder]] skill feat.
