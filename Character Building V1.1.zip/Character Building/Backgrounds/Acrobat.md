---
title: "Acrobat"
icon: ":luggage:"
aliases: "Acrobat"
foundryId: Item.VnCq8Minpz7isH5m
tags:
  - Item
---

# Acrobat
![[systems-pf2e-icons-default-icons-background.svg|150]]

In a circus or on the streets, you earned your pay by performing as an acrobat. You might have turned to adventuring when the money dried up, or simply decided to put your skills to better use.

Choose two attribute boosts. One must be to **Strength** or **Dexterity**, and one is a free attribute boost.

You're trained in the Acrobatics skill and the Circus Lore skill. You gain the [[Steady Balance]] skill feat.
