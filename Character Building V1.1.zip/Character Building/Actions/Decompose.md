---
title: "Decompose"
icon: ":luggage:"
aliases: "Decompose"
foundryId: Item.4k2MZrBSNFKQm2mC
tags:
  - Item
---

# Decompose `pf2:2`

**Frequency** once per day

* * *

**Effect** Void energy seeps out of you, decaying everything within a 5 foot emanation and causing plants and foliage to age and decompose. Natural difficult terrain is destroyed, and creatures in the area with the plant or wood trait take 1d6 void damage with a DC resolve fortitude save against your class DC or spell DC, whichever is higher.
