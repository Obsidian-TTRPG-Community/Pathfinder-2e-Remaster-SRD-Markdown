---
title: "Influence"
icon: ":luggage:"
aliases: "Influence"
foundryId: Item.mUAcxOTVowzgzLfx
tags:
  - Item
---

# Influence
![[systems-pf2e-icons-actions-Passive.webp|150]]

You attempt to make a favorable impression on an NPC to convince the NPC to support your cause. Attempt a skill check to impress that NPC. The DC and skills which can apply can be found in the NPC's stat block.

* * *

**Critical Success** You gain 2 Influence Points with the chosen NPC.

**Success** You gain 1 Influence Point with the chosen NPC.

**Failure** You gain no Influence Points with the chosen NPC.

**Critical Failure** You lose 1 Influence Point with the chosen NPC.
