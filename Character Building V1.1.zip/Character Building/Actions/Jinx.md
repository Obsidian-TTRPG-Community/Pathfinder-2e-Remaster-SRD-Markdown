---
title: "Jinx"
icon: ":luggage:"
aliases: "Jinx"
foundryId: Item.rJDbYpFCJ95JOtpt
tags:
  - Item
---

# Jinx `pf2:2`

**Frequency** once per day

* * *

**Effect** You can curse another creature with clumsiness. This curse has a range of 30 feet, and you must be able to see your target. The target gets a DC resolve will saving throw against your class DC or spell DC, whichever is higher.

* * *

**Success** The target is unaffected and temporarily immune for 24 hours.

**Failure** The target is [[Clumsy 1]] for 1 minute.

**Critical Failure** The target is [[Clumsy 1|Clumsy 2]] for 1 minute.
