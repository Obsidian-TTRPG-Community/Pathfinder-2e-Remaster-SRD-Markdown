---
title: "Breath Weapon (Cold) (Cone)"
icon: ":luggage:"
aliases: "Breath Weapon (Cold) (Cone)"
foundryId: Item.cVFZRXa33JmEA9iA
tags:
  - Item
---

# Breath Weapon (Cold) (Cone) `pf2:2`

Your eidolon exhales a blast of destructive energy. Your eidolon deals 1d6 cold damage to all creatures in a 30 foot cone, with a basic Reflex save against your spell DC.

Your eidolon then can't use their Breath Weapon again for the next 1d4 rounds.

At 3rd level and every 2 levels thereafter, the damage increases by 1d6. 
