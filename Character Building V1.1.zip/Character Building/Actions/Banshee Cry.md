---
title: "Banshee Cry"
icon: ":luggage:"
aliases: "Banshee Cry"
foundryId: Item.G3K5HEAX5MhLnVyl
tags:
  - Item
---

# Banshee Cry `pf2:r`

**Trigger** A creature within 30 feet Casts a Spell that has a verbal component or Activates an Item using a command Activation

* * *

**Effect** You set off a firework to explode with a loud screech near the creature. The creature must attempt a Will save.

* * *

**Success** The creature is unaffected.

**Failure** The creature must use an additional action on the triggering action or activity, or it's disrupted.

**Critical Failure** The triggering action is disrupted.
