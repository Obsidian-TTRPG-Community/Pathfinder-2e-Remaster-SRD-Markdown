---
title: "Covered Reload"
icon: ":luggage:"
aliases: "Covered Reload"
foundryId: Item.sf7ghkFrZK7o0rhe
tags:
  - Item
---

# Covered Reload `pf2:1`

You duck into a safe position or minimize your profile while reloading to make your next attack. Either [[Take Cover]] or attempt to [[Hide]], then Interact to reload. As normal, you must meet the requirements to Take Cover or Hide; you must be [[Prone]], benefiting from cover, or near a feature that allows you to Take Cover, and you need to be benefiting from cover or [[Concealed]] to a creature to Hide from that creature.
