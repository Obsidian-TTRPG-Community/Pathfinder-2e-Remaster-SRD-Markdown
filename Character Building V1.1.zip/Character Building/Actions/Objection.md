---
title: "Objection"
icon: ":luggage:"
aliases: "Objection"
foundryId: Item.wcJDciZG5UqFCyPL
tags:
  - Item
---

# Objection `pf2:r`

**Frequency** once per minute

**Trigger** You're about to attempt a saving throw against a linguistic effect

* * *

**Effect** Your devil's eye crackles with infernal glee as you discover a loophole in the wording of the triggering effect. You roll your saving throw twice, taking the higher result.
