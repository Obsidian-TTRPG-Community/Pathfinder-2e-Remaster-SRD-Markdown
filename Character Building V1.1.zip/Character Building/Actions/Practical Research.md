---
title: "Practical Research"
icon: ":luggage:"
aliases: "Practical Research"
foundryId: Item.HEXwK2G1WbpBcl6K
tags:
  - Item
---

# Practical Research
![[systems-pf2e-icons-actions-Passive.webp|150]]

**Requirement** You are a conversant or lore-speaker.

* * *

You identify something interesting in the field and perform special research on it. This requires an appropriate check, which the GM will describe when the opportunity arises. The results of the check vary. While they typically include all the benefits of the Study activity, some opportunities for Practical Research also offer unique benefits, such as access to new character options.
