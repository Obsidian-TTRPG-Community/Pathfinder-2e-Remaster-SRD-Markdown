---
title: "Cleanse Soul Path"
icon: ":luggage:"
aliases: "Cleanse Soul Path"
foundryId: Item.Lny34Pa7YtCOYlYf
tags:
  - Item
---

# Cleanse Soul Path
![[systems-pf2e-icons-actions-Passive.webp|150]]

You meditate, pray, or otherwise try to reinforce your soul's connection to your soulforged armament. This takes 10 minutes. Attempt a counteract check against your _soulforged corruption_. The counteract level is half your level rounded up, and the counteract check modifier is your Religion modifier. If successful, reduce the stage of your _soulforged corruption_ by 1 (to a minimum of Stage 1).
