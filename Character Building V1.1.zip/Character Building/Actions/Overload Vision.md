---
title: "Overload Vision"
icon: ":luggage:"
aliases: "Overload Vision"
foundryId: Item.iJzg5cq4K0VN11kB
tags:
  - Item
---

# Overload Vision `pf2:r`

**Trigger** A creature within 60 feet would make an attack roll against you

* * *

**Effect** The triggering creature must attempt a Fortitude save.

* * *

**Critical Success** The target is unaffected.

**Success** The target is [[Dazzled]] until the end of the current turn.

**Failure** The target is [[Blinded]] until the end of the current turn.

**Critical Failure** The target is blinded until the end of the current turn and dazzled for 1 minute.
