---
title: "Palm an Object"
icon: ":luggage:"
aliases: "Palm an Object"
foundryId: Item.D3Bybxoe2TLG9RJ5
tags:
  - Item
---

# Palm an Object `pf2:1`

Palming a small, unattended object without being noticed requires you to roll a single Thievery check against the Perception DCs of all creatures who are currently observing you. You take the object whether or not you successfully conceal that you did so. You can typically only Palm Objects of negligible Bulk, though the GM might determine otherwise depending on the situation.

* * *

**Success** The creature does not notice you Palming the Object.

**Failure** The creature notices you Palming the Object, and the GM determines the creature's response.
