---
title: "Toxic Skin"
icon: ":luggage:"
aliases: "Toxic Skin"
foundryId: Item.NvTRHp2zxutHzXlR
tags:
  - Item
---

# Toxic Skin `pf2:r`

**Frequency** once per hour

**Trigger** A creature touches you, such as by Grappling you, successfully hitting you with an unarmed attack, or using a touch-range spell against you.

* * *

You exude a deadly toxin. The triggering creature takes 1d4 poison damage (DC resolve fortitude using your class DC or spell DC, whichever is higher). At 3rd level and every 2 levels thereafter, the damage increases by 1d4.
