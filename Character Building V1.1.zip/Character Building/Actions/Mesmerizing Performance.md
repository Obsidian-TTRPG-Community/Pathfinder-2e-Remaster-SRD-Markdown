---
title: "Mesmerizing Performance"
icon: ":luggage:"
aliases: "Mesmerizing Performance"
foundryId: Item.Ql3irDRmmZdzhZ97
tags:
  - Item
---

# Mesmerizing Performance `pf2:1`

**Requirements** The companion's last action was a successful Performance check to [[Perform]]. The companion maintains its performance to captivate a single target within 30 feet that witnessed its successful performance. The target must attempt a Will save.

* * *

**Success** The target is unaffected and temporarily immune for 1 hour.

**Failure** The target is [[Fascinated]] by the companion for its next action and then is temporarily immune for 1 hour.

**Critical Failure** The target is fascinated by the companion for 1 round. While it remains fascinated, it can't use reactions.
