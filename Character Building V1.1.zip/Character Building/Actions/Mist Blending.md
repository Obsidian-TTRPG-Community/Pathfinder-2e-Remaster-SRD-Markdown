---
title: "Mist Blending"
icon: ":luggage:"
aliases: "Mist Blending"
foundryId: Item.dbFglxNwZuiG6SjV
tags:
  - Item
---

# Mist Blending `pf2:r`

**Trigger** A creature attempts a flat check to target you because you're [[Concealed]] or [[Hidden]] due to fog, haze, mist, or smoke

* * *

**Effect** You shroud yourself in mist, making it harder for your foe to hit you. If you're concealed, the DC of the flat check increases from 5 to DC 7 flat.
