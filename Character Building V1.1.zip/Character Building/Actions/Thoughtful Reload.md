---
title: "Thoughtful Reload"
icon: ":luggage:"
aliases: "Thoughtful Reload"
foundryId: Item.7580xXQk8BgQtzbR
tags:
  - Item
---

# Thoughtful Reload `pf2:1`

As you sink deep into a state of analytical calm and focus on the foe before you, your hands reload a bullet instinctively. Attempt a Recall Knowledge check against an opponent you can see and then Interact to reload.
