---
title: "Tail Toxin"
icon: ":luggage:"
aliases: "Tail Toxin"
foundryId: Item.tbeZwQzZpxS74eWU
tags:
  - Item
---

# Tail Toxin
![[systems-pf2e-icons-features-ancestry-venomtail-kobold.webp|150]]

**Frequency** once per day

**Requirements** You are wielding a piercing or slashing weapon

* * *

You apply your tail's venom to a piercing or slashing weapon. If your next Strike with that weapon before the end of your next turn hits and deals damage, you deal persistent poison damage equal to your level to the target.
