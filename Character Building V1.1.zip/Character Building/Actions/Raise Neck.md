---
title: "Raise Neck"
icon: ":luggage:"
aliases: "Raise Neck"
foundryId: Item.zPDyMcZocCbfSGz8
tags:
  - Item
---

# Raise Neck `pf2:1`

You raise your head into a striking position. The fangs Strike granted by your nagaji ancestry gains a reach of 10 feet until the end of your turn.
