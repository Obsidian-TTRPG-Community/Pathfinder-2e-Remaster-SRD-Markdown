---
title: "Catharsis"
icon: ":luggage:"
aliases: "Catharsis"
foundryId: Item.QYQhAhWmAtjW3zRZ
tags:
  - Item
---

# Catharsis `pf2:r`

**Trigger** determined by your catharsis emotion

* * *

**Effect** You gain the catharsis activation effects listed for your catharsis emotion. You gain that emotion's emotional fervor benefits for 3 rounds. When your emotional fervor ends, you suffer the listed emotional fallout. After using Catharsis, you can't use it again until you use the [[Settle Emotions]] activity.


