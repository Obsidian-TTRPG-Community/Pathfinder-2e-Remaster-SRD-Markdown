---
title: "Dismiss"
icon: ":luggage:"
aliases: "Dismiss"
foundryId: Item.VDHEYaasljnf72zW
tags:
  - Item
---

# Dismiss `pf2:1`

You end an effect that states you can Dismiss it. Dimissing ends the entire effect unless noted otherwise.
