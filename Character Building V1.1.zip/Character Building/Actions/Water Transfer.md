---
title: "Water Transfer"
icon: ":luggage:"
aliases: "Water Transfer"
foundryId: Item.Xt8aJq5pb6J7WOXK
tags:
  - Item
---

# Water Transfer `pf2:2`

**Frequency** once per minute

**Requirements** You're on land and adjacent to a body of water

* * *

**Effect** You sink into the water and emerge back onto land in another space within 120 feet that's adjacent to the same body of water. You can transport yourself, any items you're wearing and holding, and up to one other willing creature.
