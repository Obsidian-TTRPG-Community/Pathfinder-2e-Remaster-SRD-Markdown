---
title: "Lay Down Arms"
icon: ":luggage:"
aliases: "Lay Down Arms"
foundryId: Item.20A4zItUQWqFuE97
tags:
  - Item
---

# Lay Down Arms `pf2:1`

You pull your arm off, harmlessly severing it from your body and dropping it in an adjacent square. You can also use this action to reattach your severed arm if it's adjacent to you; it immediately functions normally. If the detached limb was at 0 Hit Points, it takes 10 minutes to reattach it instead of a single action.
