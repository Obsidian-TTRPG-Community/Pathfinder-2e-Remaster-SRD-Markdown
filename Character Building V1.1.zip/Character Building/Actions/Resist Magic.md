---
title: "Resist Magic"
icon: ":luggage:"
aliases: "Resist Magic"
foundryId: Item.Dv5nhnWmAs0HL2j9
tags:
  - Item
---

# Resist Magic `pf2:r`

**Trigger** You attempt a saving throw against a harmful magical effect but haven't rolled yet.

* * *

Your innate magic protects you. You gain a +1 circumstance bonus to the triggering saving throw. Additionally, if the triggering effect is arcane, if you roll a success, you get a critical success instead.
