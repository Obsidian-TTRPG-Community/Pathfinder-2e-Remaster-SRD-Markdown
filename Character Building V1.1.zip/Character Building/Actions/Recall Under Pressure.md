---
title: "Recall Under Pressure"
icon: ":luggage:"
aliases: "Recall Under Pressure"
foundryId: Item.Ztbpgya3PFyOr6vc
tags:
  - Item
---

# Recall Under Pressure `pf2:0`

**Trigger** You attempt to Recall Knowledge during a combat

**Frequency** once per day

* * *

**Effect** Rather than roll a different skill to Recall Knowledge during the fight, your memory flashes back to something you read in some old book. You instead attempt this Recall Knowledge check with an Academia Lore check. If the information you recall ends up being helpful and positive in an obvious way before you take your next turn, draw a random harrow card. You gain a +1 status bonus to saving throws for the remainder of the combat encounter as your morale soars or a +2 status bonus if the card you drew was from the suit of Books.


