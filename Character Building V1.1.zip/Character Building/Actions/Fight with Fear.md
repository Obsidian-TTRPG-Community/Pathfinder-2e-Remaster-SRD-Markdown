---
title: "Fight with Fear"
icon: ":luggage:"
aliases: "Fight with Fear"
foundryId: Item.CTQ5YLcgOFfkaJTq
tags:
  - Item
---

# Fight with Fear `pf2:r`

**Trigger** A creature that you can see uses a mental effect against you

* * *

**Effect** The triggering creature must attempt a Will save, which has the following effects.

* * *

**Success** The creature is unaffected.

**Failure** The creature is [[Frightened|Frightened 2]], and you gain a +2 status bonus to your saving throw or other defense against the triggering mental effect.

**Critical Failure** The creature is frightened 2, and you're unaffected by the triggering mental effect.
