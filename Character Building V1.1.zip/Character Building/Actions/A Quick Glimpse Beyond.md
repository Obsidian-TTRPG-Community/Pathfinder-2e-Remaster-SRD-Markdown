---
title: "A Quick Glimpse Beyond"
icon: ":luggage:"
aliases: "A Quick Glimpse Beyond"
foundryId: Item.e6MnKaTpqVNJKb8r
tags:
  - Item
---

# A Quick Glimpse Beyond `pf2:0`

**Trigger** You attempt a secret check

**Frequency** once per day

* * *

**Effect** You can roll the secret check yourself rather than have the GM roll it. As you roll, draw a harrow card. If the card drawn is from the suit of Stars, the next secret check you make during the next 24 hours can also be rolled by you. Each time you roll your own additional secret check in this way, draw a new harrow card, and each time you draw a card from the suit of Stars, your next secret check in the next 24 hours can also be rolled by you. If you ever critically fail a secret check that you roll yourself as a result of this ability, fate turns away from you, and your Pilgrim's Token no longer functions until the next time you make your daily preparations.
