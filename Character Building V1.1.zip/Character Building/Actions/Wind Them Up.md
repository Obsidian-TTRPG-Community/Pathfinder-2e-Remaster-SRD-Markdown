---
title: "Wind Them Up"
icon: ":luggage:"
aliases: "Wind Them Up"
foundryId: Item.WBGoHE2txKXX6Ws1
tags:
  - Item
---

# Wind Them Up `pf2:2`

Should foes parry your blade or dodge your bullets? Neither—they should be watching their purse. Make a melee Strike with your combination weapon, and then attempt a Thievery check with a –5 penalty to [[Steal]] from your target; you can't Steal closely guarded objects or objects that would take a long time to pilfer. You don't need a free hand to attempt to Steal something in this manner. If your Thievery check succeeds, the target is [[Off-Guard]] against your ranged attacks until the start of your next turn, and you don't trigger reactions that are normally triggered by movement or a ranged attack. These effects occur even if your target has no objects to Steal.
