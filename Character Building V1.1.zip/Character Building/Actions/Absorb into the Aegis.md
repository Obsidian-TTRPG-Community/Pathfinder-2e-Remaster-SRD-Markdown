---
title: "Absorb into the Aegis"
icon: ":luggage:"
aliases: "Absorb into the Aegis"
foundryId: Item.zgUTS31Yt8p8MfIZ
tags:
  - Item
---

# Absorb into the Aegis `pf2:r`

**Trigger** An enemy casts a spell that targets you or an ally within 15 feet of you

* * *

You interpose your shield's ward against the spell. Attempt a counteract check, using your Religion modifier as your counteract modifier. On a success, the spell is counteracted and your shield takes damage equal to four times the spell level as it absorbs and disperses the magical energy. On a failure, the shield takes damage equal to twice the spell's level.
