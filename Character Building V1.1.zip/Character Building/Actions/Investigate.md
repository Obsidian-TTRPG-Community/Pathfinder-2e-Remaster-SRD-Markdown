---
title: "Investigate"
icon: ":luggage:"
aliases: "Investigate"
foundryId: Item.svnwgpEDakjjbz1d
tags:
  - Item
---

# Investigate
![[systems-pf2e-icons-actions-Passive.webp|150]]

You seek out information about your surroundings while traveling at half speed. You use Recall Knowledge as a secret check to discover clues among the various things you can see and engage with as you journey along. You can use any skill that has a Recall Knowledge action while Investigating, but the GM determines whether the skill is relevant to the clues you could find.
