---
title: "Change Tradition Focus"
icon: ":luggage:"
aliases: "Change Tradition Focus"
foundryId: Item.EGJhiI70qcqNw1zJ
tags:
  - Item
---

# Change Tradition Focus `pf2:1`

**Requirements** You are in a duel and are trained in the skill for the tradition you're changing your focus to (Arcana for arcane, Occultism for occult, Nature for primal, or Religion for divine).

* * *

You change your tradition focus to another magical tradition.
