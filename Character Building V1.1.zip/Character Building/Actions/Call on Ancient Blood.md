---
title: "Call on Ancient Blood"
icon: ":luggage:"
aliases: "Call on Ancient Blood"
foundryId: Item.xPzkYz1NQFeHgNaK
tags:
  - Item
---

# Call on Ancient Blood `pf2:r`

**Trigger** You attempt a saving throw against a magical effect, but you haven't rolled yet

* * *

Your ancestors' innate resistance to magic surges, before slowly ebbing down. You gain a +1 circumstance bonus to the triggering saving throw and until the end of this turn.
