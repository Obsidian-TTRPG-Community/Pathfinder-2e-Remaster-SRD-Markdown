---
title: "Spellsling"
icon: ":luggage:"
aliases: "Spellsling"
foundryId: Item.z0Q6PUPhIYO5DpjM
tags:
  - Item
---

# Spellsling `pf2:3`

**Requirements** You're wielding your bonded beast gun

* * *

**Effect** You Cast a Spell that takes 1 or 2 actions to cast and requires a spell attack roll. The effects of the spell do not occur immediately but are imbued into the beast gun you're wielding. Make a Strike with that beast gun. Your spell flies with the ammunition, using your attack roll result to determine the effects of both the Strike and the spell. This counts as two attacks for the purposes of determining your multiple attack penalty, but you don't apply the penalty until after you've completed resolving the attack and spell.
