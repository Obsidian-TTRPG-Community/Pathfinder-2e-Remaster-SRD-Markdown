---
title: "Empty Vessel"
icon: ":luggage:"
aliases: "Empty Vessel"
foundryId: Item.go4IYoBXa52qwRoq
tags:
  - Item
---

# Empty Vessel `pf2:r`

**Frequency** once per day

**Trigger** You would take mental damage or be affected by a mental effect

* * *

**Effect** You gain a +2 circumstance bonus to Will saves and resistance to mental damage equal to your level against the triggering effect. This applies only to the initial effect, not successive saves, persistent mental damage, or other repeated effects.
