---
title: "Stop"
icon: ":luggage:"
aliases: "Stop"
foundryId: Item.SuxK3f1TvLp9LGW6
tags:
  - Item
---

# Stop `pf2:1`

**Requirements** You are piloting a vehicle in motion.

You bring the vehicle to a stop.
