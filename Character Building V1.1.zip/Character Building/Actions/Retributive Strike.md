---
title: "Retributive Strike"
icon: ":luggage:"
aliases: "Retributive Strike"
foundryId: Item.KsqvXyYjXeqs89O5
tags:
  - Item
---

# Retributive Strike `pf2:r`

**Trigger** An enemy damages your ally, and both are within 15 feet of you

* * *

You protect your ally and strike your foe. The ally gains resistance to all damage against the triggering damage equal to 2 + your level. If the foe is within reach, make a melee Strike against it.


