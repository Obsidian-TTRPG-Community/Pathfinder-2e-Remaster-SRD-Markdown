---
title: "Take Control"
icon: ":luggage:"
aliases: "Take Control"
foundryId: Item.5RE7v4GZAECSHTIN
tags:
  - Item
---

# Take Control `pf2:1`

**Requirements** You are aboard the vehicle and adjacent to its controls.

You grab the reins, the wheel, or some other mechanism to control the vehicle. Attempt a piloting check; on a success, you become the vehicle's pilot, or regain control of the vehicle if it was uncontrolled. Some vehicles have complicated controls that cause this action to become a multi-action activity.
