---
title: "Primal Roar"
icon: ":luggage:"
aliases: "Primal Roar"
foundryId: Item.ygm0vvhyDwPz3dAw
tags:
  - Item
---

# Primal Roar `pf2:2`

Your eidolon unleashes a primal roar or other such terrifying noise that fits your eidolon's form. Your eidolon attempts Intimidation checks to [[Demoralize]] each enemy that can hear the roar; these Demoralize attempts don't take any penalty for not sharing a language.
