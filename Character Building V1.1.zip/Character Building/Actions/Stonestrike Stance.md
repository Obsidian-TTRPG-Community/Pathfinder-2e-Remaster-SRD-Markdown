---
title: "Stonestrike Stance"
icon: ":luggage:"
aliases: "Stonestrike Stance"
foundryId: Item.LqLnF3ldycGncutx
tags:
  - Item
---

# Stonestrike Stance `pf2:1`

**Requirements** You are standing on the ground

* * *

**Effect** You enter the stance of unyielding stone and draw upon the power of the living rock, encasing your fists in stone and allowing you to make stonestrike attacks. These deal 1d8 bludgeoning damage, are in the brawling group, and have the forceful, magical, and unarmed traits.
