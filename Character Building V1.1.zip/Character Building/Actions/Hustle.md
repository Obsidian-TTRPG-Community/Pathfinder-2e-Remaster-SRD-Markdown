---
title: "Hustle"
icon: ":luggage:"
aliases: "Hustle"
foundryId: Item.U6oniRtdSeGPkOI6
tags:
  - Item
---

# Hustle
![[systems-pf2e-icons-actions-Passive.webp|150]]

You strain yourself to move at double your travel speed. You can Hustle only for a number of minutes equal to your Constitution modifier × 10 (minimum 10 minutes). If you are in a group that is Hustling, use the lowest Constitution modifier among everyone to determine how fast the group can Hustle together.
