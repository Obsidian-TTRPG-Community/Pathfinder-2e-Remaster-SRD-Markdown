---
title: "Shadow Step"
icon: ":luggage:"
aliases: "Shadow Step"
foundryId: Item.Jdy8C1ovJ12J2IcP
tags:
  - Item
---

# Shadow Step `pf2:1`

**Requirements** The familiar is in dim light or darkness.

* * *

**Effect** The familiar teleports itself up to 30 feet. The destination must be in dim light or darkness and must be within your familiar's line of sight and line of effect.

This action has the trait matching your tradition of magic, or occult if you aren't a spellcaster.
