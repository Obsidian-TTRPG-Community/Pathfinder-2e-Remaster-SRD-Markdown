---
title: "Verdant Rest"
icon: ":luggage:"
aliases: "Verdant Rest"
foundryId: Item.GgOT86m5mPjZx6Km
tags:
  - Item
---

# Verdant Rest `pf2:1`

You turn into a tree or other non-creature plant. This has the effect of using [[One with Plants]] to turn into a plant, except that your AC is 30. You can Dismiss this effect to turn back. If you rest for 10 minutes in this form in natural sunlight, you recover half your maximum Hit Points. If you take your daily rest in this form, the rest restores you to maximum Hit Points and removes all non-permanent [[Drained 1|Drained]], [[Enfeebled 1|Enfeebled]], [[Clumsy 1|Clumsy]], and [[Stupefied]] conditions, as well as all poisons and diseases of 19th level or lower.
