---
title: "Break Them Down"
icon: ":luggage:"
aliases: "Break Them Down"
foundryId: Item.qMnmYFWpof48gzLp
tags:
  - Item
---

# Break Them Down `pf2:2`

Your foes are but dross from which you carve and shoot your legend. Make a melee Strike and then a ranged Strike with a combination weapon, both against the same enemy; you don't need to change modes to do so. If the melee Strike hits, you gain a +1 circumstance bonus to the attack roll with the ranged Strike. Each attack counts toward your multiple attack penalty, but your multiple attack penalty doesn't increase until you've made both attacks. If both Strikes hit, you deal an additional 2d6 bleed damage to the enemy, and they're [[Dazzled]] until this persistent bleed damage ends.
