---
title: "Breath Weapon (Riding Drake)"
icon: ":luggage:"
aliases: "Breath Weapon (Riding Drake)"
foundryId: Item.UVVDO0pJhCKHKFqP
tags:
  - Item
---

# Breath Weapon (Riding Drake) `pf2:2`

The riding drake breathes a 30 foot cone{30-foot cone} of fire, dealing 1d6 fire damage for every 2 levels the drake has to all creatures in the area (basic Reflex save). This uses a trained DC using the drake's Constitution modifier or an expert DC if the drake is specialized.
