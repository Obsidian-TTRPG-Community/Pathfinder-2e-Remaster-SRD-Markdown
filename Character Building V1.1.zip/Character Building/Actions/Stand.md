---
title: "Stand"
icon: ":luggage:"
aliases: "Stand"
foundryId: Item.GyPhYoiigY6DwiKJ
tags:
  - Item
---

# Stand `pf2:1`

You stand up from [[Prone]].
