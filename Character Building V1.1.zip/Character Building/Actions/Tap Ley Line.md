---
title: "Tap Ley Line"
icon: ":luggage:"
aliases: "Tap Ley Line"
foundryId: Item.PoVnJstuBkxdtFLv
tags:
  - Item
---

# Tap Ley Line `pf2:1`

You attempt to manipulate the magical essence of a ley line that you're aware of within 30 feet. The GM determines the DC based on the hard DC for the ley line's level.

* * *

**Critical Success** You gain the ley line's benefits until the end of your next turn.

**Success** You gain the ley line's benefits until the end of your turn.

**Failure** You take mental damage equal to 1d6 × the ley line's level. You can't Tap the Ley Line again for 1 hour.

**Critical Failure** As failure, and you're subject to the ley line's backlash effect. You can't Tap the Ley Line again for 24 hours.
