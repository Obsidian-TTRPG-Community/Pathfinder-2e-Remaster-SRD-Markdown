---
title: "Stride"
icon: ":luggage:"
aliases: "Stride"
foundryId: Item.EYlePPmxvcwz7YzV
tags:
  - Item
---

# Stride `pf2:1`

You move up to your Speed.
