---
title: "Compose Missive"
icon: ":luggage:"
aliases: "Compose Missive"
foundryId: Item.UtSTVBen7wE0EozL
tags:
  - Item
---

# Compose Missive
![[systems-pf2e-icons-actions-Passive.webp|150]]

You spend 10 minutes drawing, writing, or inscribing, covering the missive's surface with text, images, or embossing.
