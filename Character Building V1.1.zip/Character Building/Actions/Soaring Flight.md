---
title: "Soaring Flight"
icon: ":luggage:"
aliases: "Soaring Flight"
foundryId: Item.fVR7vML0JWxGMKuL
tags:
  - Item
---

# Soaring Flight `pf2:2`

**Frequency** Once per day

* * *

To be a tengu is to be unburdened by the concerns of the world below. You grow a pair of magical wings or expand your existing ones. For 5 minutes, you gain a [[Fly]] Speed equal to your land Speed or 20 feet, whichever is greater.
