---
title: "Wicked Thorns"
icon: ":luggage:"
aliases: "Wicked Thorns"
foundryId: Item.2P5KpaFZ6wvGF8Bd
tags:
  - Item
---

# Wicked Thorns `pf2:r`

**Trigger** You're hit with an unarmed Strike or a Strike with a non-reach melee weapon.

**Frequency** once per day

* * *

Several of your thorns break off and hook into your attacker's body. You deal 1d8 piercing damage to the triggering creature. It attempts a DC resolve reflex save against the higher of your class DC or spell DC. On a critical failure, the creature also takes 1d4 bleed damage as your thorns embed in its flesh.

At 3rd level, and every 2 levels thereafter, this damage increases by 1d8, and the persistent bleed damage increases by 1.
