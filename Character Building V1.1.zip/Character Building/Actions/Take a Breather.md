---
title: "Take a Breather"
icon: ":luggage:"
aliases: "Take a Breather"
foundryId: Item.IweqkAhoNgsFRIDI
tags:
  - Item
---

# Take a Breather
![[systems-pf2e-icons-actions-Passive.webp|150]]

**Cost** 1 Resolve Point

* * *

You rest for 10 minutes and recover your stamina. After you complete this activity, you regain all your Stamina Points.
