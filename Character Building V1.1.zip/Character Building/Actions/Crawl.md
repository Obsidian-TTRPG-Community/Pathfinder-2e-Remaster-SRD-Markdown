---
title: "Crawl"
icon: ":luggage:"
aliases: "Crawl"
foundryId: Item.qPgXtdWXMUa53gnX
tags:
  - Item
---

# Crawl `pf2:1`

**Requirements** You are prone and your Speed is at least 10 feet.

* * *

You move 5 feet by crawling and continue to stay [[Prone]].
