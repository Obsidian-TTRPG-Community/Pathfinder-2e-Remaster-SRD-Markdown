---
title: "Drop Prone"
icon: ":luggage:"
aliases: "Drop Prone"
foundryId: Item.2UALM3ykKxn4Fg9s
tags:
  - Item
---

# Drop Prone `pf2:1`

You fall [[Prone]].
