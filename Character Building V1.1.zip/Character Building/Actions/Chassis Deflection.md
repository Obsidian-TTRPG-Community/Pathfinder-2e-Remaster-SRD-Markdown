---
title: "Chassis Deflection"
icon: ":luggage:"
aliases: "Chassis Deflection"
foundryId: Item.iFMzR9VqTDQDE8C6
tags:
  - Item
---

# Chassis Deflection `pf2:r`

**Trigger** A critical hit deals physical damage to you.

* * *

Attempt a DC 17 flat. If you are successful, the attack becomes a normal hit.
