---
title: "Drain Familiar"
icon: ":luggage:"
aliases: "Drain Familiar"
foundryId: Item.XRMJGtbVCue7rpH9
tags:
  - Item
---

# Drain Familiar `pf2:0`

**Frequency** once per day

**Requirements** Your familiar is on your person.

* * *

You expend the magical power stored in your familiar. During the current turn, you can cast one spell you prepared today and already cast, without spending a spell slot. You must still Cast the Spell and meet the spell's other requirements.
