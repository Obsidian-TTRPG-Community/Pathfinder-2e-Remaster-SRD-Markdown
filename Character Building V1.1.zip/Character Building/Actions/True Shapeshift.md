---
title: "True Shapeshift"
icon: ":luggage:"
aliases: "True Shapeshift"
foundryId: Item.48ABD925dqHFvTjL
tags:
  - Item
---

# True Shapeshift `pf2:2`

**Requirements** You're under the effects of [[Untamed Form]]

* * *

**Effect** You change into any other shape on your _untamed form_ list. If the duration of that shape is different from the one you were previously in, use the shorter duration to determine your duration remaining.
