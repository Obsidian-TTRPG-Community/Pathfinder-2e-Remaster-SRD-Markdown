---
title: "Share Life"
icon: ":luggage:"
aliases: "Share Life"
foundryId: Item.2u45J0WahxSNNpBF
tags:
  - Item
---

# Share Life `pf2:r`

**Trigger** Your linked ally takes damage and is within 60 feet

* * *

**Effect** The ally takes half damage from the triggering effect (rounded down), and you lose a number of Hit Points equal to the remainder of the damage. You can't trigger this reaction to share damage caused by your ally using this reaction.
