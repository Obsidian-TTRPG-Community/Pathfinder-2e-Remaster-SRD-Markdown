---
aliases: 
tags: 
obsidianUIMode: preview
---
```statblock
columns: 2
forcecolumns: true
layout: Basic Pathfinder 2e Layout

source: Pathfinder
name: "Wight Commander"

ac: 32
armorclass:
  - name: AC
    desc: "32; 34 with shield raised);; __Fort__: +24 (1d20+24); __Ref__: +19 (1d20+19); __Will__: +21 (1d20+21);"




```
