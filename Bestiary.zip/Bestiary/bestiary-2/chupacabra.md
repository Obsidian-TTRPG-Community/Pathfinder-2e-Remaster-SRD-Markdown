---
obsidianUIMode: preview
noteType: pf2eMonster
aliases: "Chupacabra"
tags: 
  - pf2e/creature/type/beast
  - pf2e/creature/level/3
statblock: inline
name: "Chupacabra"
level: 3
---

```statblock
columns: 2
forcecolumns: true
layout: Basic Pathfinder 2e Layout
source: "B2"
name: "Chupacabra"
level: "Creature 3"
alignment: "N"
size: "Small"
trait_03: "Beast"
modifier: 9
perception:
  - name: "Perception"
    desc: "Perception +9; __darkvision__;"
languages: "Aklo (can't speak any language); "
skills:
  - name: "Skills"
    desc: "__Acrobatics__: +9 (1d20+9), (Acrobatics: +11 (1d20+11) to Leap); __Stealth__: +9 (1d20+9); "
abilityMods: [3, 4, 2, -3, 2, -2]

abilities_bot:
  - name: "Chupar"
    desc: "⬻ __Requirements__ The chupacabra has a creature [[rules/conditions.md#Grabbed|grabbed]]  __Effect__  The chupacabra sucks blood from the [[rules/conditions.md#Grabbed|grabbed]] creature. The chupacabra gains the [[rules/conditions.md#Quickened|quickened]] condition for 1 minute and can use the extra action only for [[Strike]] and [[Stride]] actions. A chupacabra can't use Chupar again while it is [[rules/conditions.md#Quickened|quickened]] in this way. A creature that has its blood [[rules/conditions.md#Drained|drained]] by a chupacabra is [[rules/conditions.md#Drained|drained 1]] until it receives healing (of any kind or amount)."
  - name: "Pounce"
    desc: "⬻  The chupacabra [[Stride|Strides]] and makes a [[Strike]] at the end of that movement. If the chupacabra began this action [[rules/conditions.md#Hidden|hidden]], it remains [[rules/conditions.md#Hidden|hidden]] until after this ability's [[Strike]]."

speed: 25 feet

ac: 20
armorclass:
  - name: AC
    desc: "20; __Fort__: +9 (1d20+9); __Ref__: +11 (1d20+11); __Will__: +7 (1d20+7);"
hp: 45
health:
  - name: HP
    desc: "45; "


attacks:
  - name: Melee
    desc: "⬻ jaws +11 ([[finesse]]); __Damage__ 1d10+5 (1d10+5) piercing plus Grab"
  - name: Melee
    desc: "⬻ claw +11 ([[agile]], [[finesse]]); __Damage__ 1d6+5 (1d6+5) slashing"

sourcebook: "_Bestiary 2_, page 52."
```

```encounter-table
name: Chupacabra
creatures:
  - 1: Chupacabra
```
