---
title: "Leshy"
noteType: ":luggage:"
aliases: "Leshy"
foundryId: Item.2Ell14S6ezezXT3v
tags:
  - Item
---

# Leshy
![[systems-pf2e-icons-default-icons-alternatives-ancestries-leshy.svg|150]]

_Guardians and emissaries of the environment, leshies are immortal spirits of nature temporarily granted a physical form._

_[[Leshy]]_
