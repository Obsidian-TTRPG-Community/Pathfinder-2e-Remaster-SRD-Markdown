---
title: "Fleshwarp"
noteType: ":luggage:"
aliases: "Fleshwarp"
foundryId: Item.Im67uf6RLFuM0Qx3
tags:
  - Item
---

# Fleshwarp
![[systems-pf2e-icons-default-icons-alternatives-ancestries-fleshwarp.svg|150]]

_Fleshwarps are people whose forms were created or radically transformed by magic, alchemy, or unnatural energies. Their unorthodox appearance can make it difficult for them to find a place for themselves in the world._

_[[Fleshwarp]]_
