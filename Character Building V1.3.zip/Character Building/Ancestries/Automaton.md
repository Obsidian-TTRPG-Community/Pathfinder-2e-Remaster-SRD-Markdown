---
title: "Automaton"
noteType: ":luggage:"
aliases: "Automaton"
foundryId: Item.DMgFRm2wT5AKd3BQ
tags:
  - Item
---

# Automaton
![[systems-pf2e-icons-default-icons-alternatives-ancestries-automaton.svg|150]]

_These intelligent constructs house actual souls and represent what remains of a dying empire's last attempt at greatness. Automatons combine technological ingenuity with magical power, creating a blended being wholly unique to Golarion._

[[Automaton]]
