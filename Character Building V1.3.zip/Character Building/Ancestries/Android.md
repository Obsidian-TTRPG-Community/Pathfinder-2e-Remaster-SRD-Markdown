---
title: "Android"
noteType: ":luggage:"
aliases: "Android"
foundryId: Item.YWA4yimQI4Eap9dG
tags:
  - Item
---

# Android
![[systems-pf2e-icons-default-icons-alternatives-ancestries-android.svg|150]]

_Technological wonders from another world, androids have synthetic bodies and living_ _souls. Their dual nature makes them quick-thinking and calm under pressure, but_ _comfortable in stillness and solitude._

_[[Android]]_
