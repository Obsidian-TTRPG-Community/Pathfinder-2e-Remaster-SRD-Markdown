---
title: "Goblin"
noteType: ":luggage:"
aliases: "Goblin"
foundryId: Item.AcOhxJneZhDB7zge
tags:
  - Item
---

# Goblin
![[systems-pf2e-icons-default-icons-alternatives-ancestries-goblin.svg|150]]

_The convoluted histories other people cling to don't interest goblins. These small folk live in the moment, and they prefer tall tales over factual records. The wars of a few decades ago might as well be from the ancient past. Misunderstood by other people, goblins are happy how they are. Goblin virtues are about being present, creative, and honest. They strive to lead fulfilled lives, rather than worrying about how their journeys will end. To tell stories, not nitpick the facts. To be small, but dream big._

_[[Goblin]]_
