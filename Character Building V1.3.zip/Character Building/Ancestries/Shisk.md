---
title: "Shisk"
noteType: ":luggage:"
aliases: "Shisk"
foundryId: Item.VpmXNEFuAEACr1u4
tags:
  - Item
---

# Shisk
![[systems-pf2e-icons-default-icons-alternatives-ancestries-shisk.svg|150]]

_Shisks are secretive mountain-dwellers, bone-feathered humanoids who lurk underground in dark tunnels and caverns. Their fascination with collecting and protecting esoteric knowledge is one of the few things that can persuade them to explore the outside world._

_[[Shisk]]_
