---
title: "Goloma"
noteType: ":luggage:"
aliases: "Goloma"
foundryId: Item.txcUA1riqfGSJvDZ
tags:
  - Item
---

# Goloma
![[systems-pf2e-icons-default-icons-alternatives-ancestries-goloma.svg|150]]

_Golomas fear most other people and deliberately use their unusual biology to frighten off those they consider to be dangerous predators. Rarely seen and poorly understood, golomas' many-eyed and wooden faced visages instill terror in most they meet._

_[[Goloma]]_
