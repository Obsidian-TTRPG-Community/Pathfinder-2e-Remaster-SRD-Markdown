---
title: "Conrasu"
noteType: ":luggage:"
aliases: "Conrasu"
foundryId: Item.1uDJQ854CttgO0Wz
tags:
  - Item
---

# Conrasu
![[systems-pf2e-icons-default-icons-alternatives-ancestries-conrasu.svg|150]]

_Conrasus are shards of cosmic force given consciousness who construct intricate exoskeletons to interface with the mortal world. Both an integral part of the underlying processes of the universe and strangely set apart, conrasus look to aeons to understand their existence._

_[[Conrasu]]_
