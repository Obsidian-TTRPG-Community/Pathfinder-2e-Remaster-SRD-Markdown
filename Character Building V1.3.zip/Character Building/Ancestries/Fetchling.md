---
title: "Fetchling"
noteType: ":luggage:"
aliases: "Fetchling"
foundryId: Item.DCLZAfwOwa2FVexy
tags:
  - Item
---

# Fetchling
![[systems-pf2e-icons-default-icons-alternatives-ancestries-fetchling.svg|150]]

_Once human and now something apart, fetchlings display the Shadow Plane's ancient influence through monochrome complexions, glowing eyes, and the casting of supernatural shadows._

_[[Fetchling]]_
