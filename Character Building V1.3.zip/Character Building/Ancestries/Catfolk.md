---
title: "Catfolk"
noteType: ":luggage:"
aliases: "Catfolk"
foundryId: Item.SIoAlqnvLSHPjxRQ
tags:
  - Item
---

# Catfolk
![[systems-pf2e-icons-default-icons-alternatives-ancestries-catfolk.svg|150]]

_Curious and gregarious wanderers, catfolk combine features of felines and humanoids in both appearance and temperament. They enjoy learning new things, collecting new tales and trinkets, and ensuring their loved ones are safe and happy. Catfolk view themselves as chosen guardians of natural places in the world and are often recklessly brave, even in the face of overwhelming opposition._

_[[Catfolk]]_
