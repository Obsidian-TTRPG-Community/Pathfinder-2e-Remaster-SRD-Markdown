---
title: "Ghoran"
noteType: ":luggage:"
aliases: "Ghoran"
foundryId: Item.hxcZYmRRo5nb9AT1
tags:
  - Item
---

# Ghoran
![[systems-pf2e-icons-default-icons-ancestry.svg|150]]

These intelligent plant people, created by a long-dead druid, possess a sort of immortality through their seeds—unless these are destroyed by external events other than merely the ravages of time.

[[Ghoran]]
