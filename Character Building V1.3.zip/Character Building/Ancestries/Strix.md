---
title: "Strix"
noteType: ":luggage:"
aliases: "Strix"
foundryId: Item.JfeKALEOyyainWgl
tags:
  - Item
---

# Strix
![[systems-pf2e-icons-default-icons-alternatives-ancestries-strix.svg|150]]

_Known as itarii in their own language, strix are reclusive avian humanoids devoted to their homelands and their tribes. They defend their precious communities with broad wingspans and razor talons._

_[[Strix]]_
