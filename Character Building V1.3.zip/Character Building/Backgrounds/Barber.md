---
title: "Barber"
noteType: ":luggage:"
aliases: "Barber"
foundryId: Item.OHyvTPoSPRaYNKnH
tags:
  - Item
---

# Barber
![[systems-pf2e-icons-default-icons-background.svg|150]]

Haircuts, dentistry, bloodletting, and surgery-if it takes a steady hand and a razor, you do it. You may have taken to the road to expand your skills, or to test yourself against a world that leaves your patients so battered and bruised.

Choose two ability boosts. One must be to **Dexterity** or **Wisdom**, and one is a free ability boost.

You're trained in the Medicine skill and the Surgery Lore skill. You gain the [[Risky Surgery]] skill feat.
