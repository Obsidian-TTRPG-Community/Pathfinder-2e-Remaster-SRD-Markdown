---
title: "Aiudara Seeker"
noteType: ":luggage:"
aliases: "Aiudara Seeker"
foundryId: Item.xKzPaSF765D9qBW5
tags:
  - Item
---

# Aiudara Seeker
![[systems-pf2e-icons-default-icons-background.svg|150]]

**\[Legacy - Age of Ashes\]**

The aiudara of Alseta's Ring have become more well known, and you are interested in learning more about them.

Choose two ability boosts. One must be to **Intelligence** or **Wisdom**, and one is a free ability boost.

You're trained in the Arcana skill and the Portal Lore skill. You gain the [[Quick Identification]] skill feat.
