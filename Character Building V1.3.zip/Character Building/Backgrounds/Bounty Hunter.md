---
title: "Bounty Hunter"
noteType: ":luggage:"
aliases: "Bounty Hunter"
foundryId: Item.4KeoCgmwT8eJh9wK
tags:
  - Item
---

# Bounty Hunter
![[systems-pf2e-icons-default-icons-background.svg|150]]

Bringing in lawbreakers lined your pockets. Maybe you had an altruistic motive and sought to bring in criminals to make the streets safer, or maybe the coin was motivation enough. Your techniques for hunting down criminals transfer easily to the life of an adventurer.

Choose two attribute boosts. One must be to **Strength** or **Wisdom**, and one is a free attribute boost.

You're trained in the Survival skill and the Legal Lore skill. You gain the [[Experienced Tracker]] skill feat.
