---
title: "Belkzen Slayer"
noteType: ":luggage:"
aliases: "Belkzen Slayer"
foundryId: Item.kDmYawSosndOxgxQ
tags:
  - Item
---

# Belkzen Slayer
![[systems-pf2e-icons-default-icons-background.svg|150]]

**Prerequisite** Region - Eye of Dread

* * *

You are a fearsome warrior from the Hold of Belkzen, and your clan counts on you for support, counsel, and defense. With the rising threat of the Whispering Tyrant threatening the safety of your home, you must not let your people down.

Choose two ability boosts. One must be to **Strength** or **Charisma**, and one is a free ability boost.

You're trained in the Intimidation skill and the Orc Lore skill. You gain the [[Intimidating Glare]] skill feat.
