---
title: "Bibliophile"
noteType: ":luggage:"
aliases: "Bibliophile"
foundryId: Item.lO4qYxlsynAQGiH6
tags:
  - Item
---

# Bibliophile
![[systems-pf2e-icons-default-icons-background.svg|150]]

You love few things more than a good book, and as a result, Odd Stories is your favorite shop in Otari. The bookseller Morlibint supplies you with fiction, anthologies, and other delightful reads, and he's always eager to discuss his latest finds with you. You know that imagination is the greatest magic, but a working knowledge of actual magic helps, too.

Choose two ability boosts. One must be to **Intelligence** or **Charisma**, and one is a free ability boost.

You're trained in the Arcana skill and the Library Lore skill. You gain the [[Arcane Sense]] skill feat.
