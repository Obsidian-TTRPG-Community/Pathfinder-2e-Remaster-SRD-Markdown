---
title: "Atteran Rancher"
noteType: ":luggage:"
aliases: "Atteran Rancher"
foundryId: Item.pOxaNsXWxV93enGM
tags:
  - Item
---

# Atteran Rancher
![[systems-pf2e-icons-default-icons-background.svg|150]]

**Prerequisite** Region - Old Cheliax

* * *

You grew up breeding and training the famous horses of the Atteran Ranches in northern Nidal. You may even be sympathetic to the Desnan dissidents who hide there from the Umbral Court.

Choose two ability boosts. One must be to **Strength** or **Dexterity**, and one is a free ability boost.

You're trained in the Nature skill and the Animal Lore skill. You gain the [[Train Animal]] skill feat.
