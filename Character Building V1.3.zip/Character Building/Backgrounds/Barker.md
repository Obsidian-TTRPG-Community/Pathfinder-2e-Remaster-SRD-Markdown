---
title: "Barker"
noteType: ":luggage:"
aliases: "Barker"
foundryId: Item.nmvA833ZiXEPuEWr
tags:
  - Item
---

# Barker
![[systems-pf2e-icons-default-icons-background.svg|150]]

You're skilled at shouting to catch and keep the attention of passersby. A few well-timed and forcefully spoken words not only get people to notice you but also engage them to respond to you. You may have previously worked as a crier or in a more formal barker capacity with Mistress Dusklight's Celestial Menagerie. Either way, your ability to bully a crowd is impressive.

Choose two ability boosts. One must be to **Constitution** or **Charisma**, and one is a free ability boost.

You're trained in the Intimidation skill, and the Crowd Lore skill. You gain the [[Group Coercion]] skill feat.
