---
title: "Awful Scab"
noteType: ":luggage:"
aliases: "Awful Scab"
foundryId: Item.DMp2oJEdE5BLvNMu
tags:
  - Item
---

# Awful Scab
![[systems-pf2e-icons-default-icons-background.svg|150]]

Prior to the Evisceration of 4707, the district of V'drysha was a lovely borough on the southern edge of Ecanus. Now, it's the Awful, a vast morass of spell-resistant flesh and sinew, ever threatening to engulf the city. You were once a Scab working to push back its influence. It's a nasty, dangerous job, and poorly paid as well, but at least you learned enough to mimic a viscerasuit, the enchanted, airtight suit that protected you from the poisons and plagues of the Awful.

Choose two ability boosts. One must be to **Dexterity** or **Constitution**, and one is a free ability boost.

You're trained in Medicine and Fleshforged Lore. You also know how to seal your clothing or armor like a viscerasuit. During your daily preparations, you can seal your outfit. The first time each day you are introduced to poison or disease without taking physical damage, the sealed outfit attempts to counteract it using your Medicine modifier as the counteract modifier.
