---
title: "Artist"
noteType: ":luggage:"
aliases: "Artist"
foundryId: Item.mdHdA1UyXdMperxf
tags:
  - Item
---

# Artist
![[systems-pf2e-icons-default-icons-background.svg|150]]

Your art is your greatest passion, whatever form it takes. Adventuring might help you find inspiration, or simply be a way to survive until you become a world-famous artist.

Choose two attribute boosts. One must be to **Dexterity** or **Charisma**, and one is a free attribute boost.

You're trained in the Crafting skill and the Art Lore skill. You gain the [[Specialty Crafting]] skill feat.
