---
title: "Detect Magic"
noteType: ":luggage:"
aliases: "Detect Magic"
foundryId: Item.Wy0FfC2QxYDTX9XO
tags:
  - Item
---

# Detect Magic
![[systems-pf2e-icons-actions-Passive.webp|150]]

You cast detect magic at regular intervals. You move at half your travel speed or slower. You have no chance of accidentally overlooking a magic aura at a travel speed up to 300 feet per minute, but must be traveling no more than 150 feet per minute to detect magic auras before the party moves into them.
