---
title: "Tenacious Stance"
noteType: ":luggage:"
aliases: "Tenacious Stance"
foundryId: Item.vXANBCafLHS6DItp
tags:
  - Item
---

# Tenacious Stance
![[icons-magic-earth-strike-fist-stone-light.webp|150]]

**Requirements** You are wearing armor

* * *

**Effect** You steady yourself, as tough and immutable as stone. You gain a number of temporary Hit Points equal to half your level (minimum 1) and a +2 circumstance bonus to DCs against being Shoved and Tripped. However, you no longer negate your armor check penalty or Speed penalty for having a high Strength while in this stance. After you leave Tenacious Stance, you lose any remaining temporary Hit Points from the stance, and you become temporarily immune to gaining temporary Hit Points from Tenacious Stance for 1 minute.
