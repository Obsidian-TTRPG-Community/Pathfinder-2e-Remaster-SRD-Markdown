---
title: "Call Gun"
noteType: ":luggage:"
aliases: "Call Gun"
foundryId: Item.utokRbpX0D1fS7lX
tags:
  - Item
---

# Call Gun `pf2:1`

**Effect** You hold aloft a free hand and call the firearm or crossbow you chose during your daily preparations into your hand. As long as the weapon you chose is on the same plane, it appears in your hand.
