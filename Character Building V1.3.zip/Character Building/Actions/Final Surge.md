---
title: "Final Surge"
noteType: ":luggage:"
aliases: "Final Surge"
foundryId: Item.dMG1ZmzShTPHGP0l
tags:
  - Item
---

# Final Surge `pf2:1`

You Stride twice. The [[Drakeheart Mutagen (Lesser)|Drakeheart Mutagen]]'s duration ends.
