---
title: "Finish The Job"
noteType: ":luggage:"
aliases: "Finish The Job"
foundryId: Item.iC9x7CpaBEd8feWA
tags:
  - Item
---

# Finish The Job `pf2:1`

**Requirements** On your last action, you failed (but didn't critically fail) a Strike with a firearm or crossbow you're holding in one hand, and your other hand is either wielding a melee weapon or empty.

* * *

Your last attack failed, but it set you up for another. Make a Strike with your other hand, using a one-handed melee weapon or unarmed attack. This Strike uses the same multiple attack penalty as the Strike that failed on the last action. Afterward, increase your multiple attack penalty normally.
