---
title: "Dispelling Bullet"
noteType: ":luggage:"
aliases: "Dispelling Bullet"
foundryId: Item.rNF27Lv23SDy4dlb
tags:
  - Item
---

# Dispelling Bullet `pf2:2`

You imprint a bullet with a field of abjuration built upon your magical signature, disrupting the magic of whatever it hits. Make a firearm or crossbow Strike against a foe you can see. If you hit, you attempt to counteract a spell effect active on the target (your choice, or the highest-level effect if you don't choose). Your counteract level is equal to half your level (rounded up), and your counteract check modifier is equal to your class DC - 10.
