---
title: "Research"
noteType: ":luggage:"
aliases: "Research"
foundryId: Item.76rZt1yqgkivPJtn
tags:
  - Item
---

# Research
![[systems-pf2e-icons-actions-Passive.webp|150]]

You comb through information to learn more about the topic at hand. Choose your research topic, section of the library, or other division depending on the form of research, and attempt a skill check. The skills to use and the DC for the check depend on the choice you made.

* * *

**Critical Success** You gain 2 RP.

**Success** You gain 1 RP.

**Critical Failure** You make a false discovery and lose 1 RP.
