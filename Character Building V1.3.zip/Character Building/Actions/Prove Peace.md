---
title: "Prove Peace"
noteType: ":luggage:"
aliases: "Prove Peace"
foundryId: Item.45ZgyTGgds3ht76V
tags:
  - Item
---

# Prove Peace `pf2:2`

**Requirements** You know the conflict that created a specific siege shard, and the siege shard is [[Immobilized]].

* * *

You touch the siege shard, establish a mental connection, and relay facts of the conflict's resolution.

Attempt a check to [[Recall Knowledge]] about the conflict that created the shard, using the siege shard's Will DC. If you succeed, you prove the conflict's end, and the siege shard reverts to ordinary stone. On a critical failure, images of the past conflict overwhelm you, and you are [[Confused]] until the end of your next turn.
