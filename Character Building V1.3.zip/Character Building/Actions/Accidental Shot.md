---
title: "Accidental Shot"
noteType: ":luggage:"
aliases: "Accidental Shot"
foundryId: Item.PpFg5D0MvW9Nwuqq
tags:
  - Item
---

# Accidental Shot `pf2:2`

**Frequency** once per day

* * *

**Effect** You make a Strike with a ranged weapon, rolling the attack and damage twice and using the better results for each. The attack ignores circumstance penalties to the attack roll and any flat check required due to the target being [[Concealed]] or [[Hidden]].
