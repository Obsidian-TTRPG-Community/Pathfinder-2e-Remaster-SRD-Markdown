---
title: "Dueling Counter"
noteType: ":luggage:"
aliases: "Dueling Counter"
foundryId: Item.NKhp1OFnC2j0IAgk
tags:
  - Item
---

# Dueling Counter `pf2:r`

**Trigger** Your opponent Casts a Spell from the same tradition as your tradition focus.

**Requirements** You are in a duel and have a tradition focus.

* * *

Expend a prepared spell or spell slot. You then attempt to counteract the triggering spell with the expended spell.
