---
title: "Mount"
noteType: ":luggage:"
aliases: "Mount"
foundryId: Item.QTxUEOYFKcRI3ZdH
tags:
  - Item
---

# Mount `pf2:1`

**Requirements** You are adjacent to a creature that is at least one size larger than you and is willing to be your mount.

* * *

You move onto the creature and ride it. If you're already mounted, you can instead use this action to dismount, moving off the mount into a space adjacent to it.
