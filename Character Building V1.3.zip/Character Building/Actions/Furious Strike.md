---
title: "Furious Strike"
noteType: ":luggage:"
aliases: "Furious Strike"
foundryId: Item.VLEqtxmF9K8DkaiK
tags:
  - Item
---

# Furious Strike `pf2:2`

Your eidolon channels its anger into a furious attack. It makes a melee Strike. This counts as two attacks when calculating your multiple attack penalty. If this Strike hits, your eidolon deals an extra die of weapon damage and gains a +1 circumstance bonus to the damage roll.

If you're at least 10th level, increase this to two extra dice with a +2 circumstance bonus, and if you're at least 18th level, increase it to three extra dice with a +3 circumstance bonus.
