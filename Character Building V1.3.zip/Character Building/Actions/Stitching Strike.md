---
title: "Stitching Strike"
noteType: ":luggage:"
aliases: "Stitching Strike"
foundryId: Item.bc2a7U4lZs4Z8zx8
tags:
  - Item
---

# Stitching Strike `pf2:2`

**Frequency** once per 10 minutes

* * *

**Effect** Your familiar unravels into magical fibers that encompass an enemy within 30 feet and deal 6d6 slashing damage, with a Basic Reflex save against your spell DC. On a failure, the target is also Immobilized for 1 round or until it Escapes against your spell DC. Your familiar then re-forms in its original square. At 9th level, and every 2 levels thereafter, the attack deals an additional 2d6 damage.

