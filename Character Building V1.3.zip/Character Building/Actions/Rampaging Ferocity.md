---
title: "Rampaging Ferocity"
noteType: ":luggage:"
aliases: "Rampaging Ferocity"
foundryId: Item.PKGfuQ0lsLzCjWRT
tags:
  - Item
---

# Rampaging Ferocity `pf2:0`

**Trigger** You use [[Orc Ferocity]]

* * *

You lash out viciously even as you fend off death. Make a single melee Strike. If this Strike brings a foe to 0 Hit Points, this activation of Orc Ferocity doesn't count against its frequency.
