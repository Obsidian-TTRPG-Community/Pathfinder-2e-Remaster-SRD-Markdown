---
title: "Tendril Strike"
noteType: ":luggage:"
aliases: "Tendril Strike"
foundryId: Item.ZM0bhYK2bqjb2OOm
tags:
  - Item
---

# Tendril Strike `pf2:1`

Stretching to extend its body to its limits, your eidolon attacks a foe that would normally be beyond its reach. Your eidolon makes a melee unarmed Strike, increasing its reach by 5 feet for that Strike.

If the unarmed attack has the disarm, shove, or trip trait, the eidolon can use the corresponding action instead of a Strike.
