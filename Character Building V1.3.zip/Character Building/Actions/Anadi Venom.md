---
title: "Anadi Venom"
noteType: ":luggage:"
aliases: "Anadi Venom"
foundryId: Item.Lui3P5wS5MRUmKRY
tags:
  - Item
---

# Anadi Venom
![[icons-skills-melee-blade-tip-energy-green.webp|150]]

**Frequency** a number of times per day equal to your level

* * *

You envenom your fangs. If the next fangs Strike you make before the end of your turn hits and deals damage, the Strike deals an additional 1d6 poison damage. On a critical failure, the poison is wasted as normal. At 12th level, this poison damage increases to 2d6.
