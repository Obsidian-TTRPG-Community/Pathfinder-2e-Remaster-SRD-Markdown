---
title: "Manifest Soulforged Armament"
noteType: ":luggage:"
aliases: "Manifest Soulforged Armament"
foundryId: Item.Uu0GwFdM28eJDn3b
tags:
  - Item
---

# Manifest Soulforged Armament `pf2:1`

**Requirements** If summoning a weapon or shield, you have the hands free to wield it; if summoning armor, you aren't wearing any armor

* * *

**Effect** You immediately wield or wear the soulforged armament bound to you. The soulforged armament remains manifested until you Dismiss this effect.

Once per day when you use this ability, you can manifest the armament's essence form. You gain the armament's essence power until it's Dismissed. After 1 minute, the essence form armament is automatically Dismissed.
