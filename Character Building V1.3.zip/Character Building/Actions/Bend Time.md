---
title: "Bend Time"
noteType: ":luggage:"
aliases: "Bend Time"
foundryId: Item.FrK0gcApDLiSd79I
tags:
  - Item
---

# Bend Time `pf2:0`

**Frequency** once per day

**Trigger** Your turn begins

* * *

**Effect** You are [[Quickened]] this turn. You can use your extra action to Stride.
