---
title: "Map the Area"
noteType: ":luggage:"
aliases: "Map the Area"
foundryId: Item.Zct4whOjyedOo6G0
tags:
  - Item
---

# Map the Area
![[systems-pf2e-icons-actions-Passive.webp|150]]

As long as your group has successfully Reconnoitered the hex, you can use this activity to create an accurate map of the hex with a successful Survival check (typically at a trained or expert DC). When you have an accurate map of the hex, the DC of any check to navigate that hex is reduced by 2.
