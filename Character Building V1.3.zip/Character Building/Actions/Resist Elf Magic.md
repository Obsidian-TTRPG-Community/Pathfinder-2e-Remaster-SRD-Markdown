---
title: "Resist Elf Magic"
noteType: ":luggage:"
aliases: "Resist Elf Magic"
foundryId: Item.g26Z5GPs0ELbkam0
tags:
  - Item
---

# Resist Elf Magic `pf2:r`

**Trigger** You attempt a saving throw against a magical effect but haven't rolled yet

* * *

Your ancestral resistance to magic protects you. You gain a +1 circumstance bonus to the triggering saving throw. If the triggering effect is arcane, you gain a +2 circumstance bonus instead.
