---
title: "De-Animating Gestures (True)"
noteType: ":luggage:"
aliases: "De-Animating Gestures (True)"
foundryId: Item.Dk3pOPecan13chwE
tags:
  - Item
---

# De-Animating Gestures (True) `pf2:1`

You designate a single construct within 30 feet that you can see or hear. The construct is [[Slowed]] for 1 minute.
