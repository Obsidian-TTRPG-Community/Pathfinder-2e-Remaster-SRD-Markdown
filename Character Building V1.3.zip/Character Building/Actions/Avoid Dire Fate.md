---
title: "Avoid Dire Fate"
noteType: ":luggage:"
aliases: "Avoid Dire Fate"
foundryId: Item.wqvJTq4htQc2u5qZ
tags:
  - Item
---

# Avoid Dire Fate `pf2:r`

**Requirements** you have an active harrow omen

**Trigger** you fail or critically fail a check associated with your harrow omen's suit

* * *

**Effect** Treat the failure as a success or a critical failure as a failure. You no longer have an active harrow omen.
