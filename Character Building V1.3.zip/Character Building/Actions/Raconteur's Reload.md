---
title: "Raconteur's Reload"
noteType: ":luggage:"
aliases: "Raconteur's Reload"
foundryId: Item.PjJf3U8OBztAI7AC
tags:
  - Item
---

# Raconteur's Reload `pf2:1`

Your rapid or forceful words draw the enemy's attention away from your hands long enough to chamber another bullet. Interact to reload and then attempt a Deception check to [[Create a Diversion]] or an Intimidation check to [[Demoralize]].
