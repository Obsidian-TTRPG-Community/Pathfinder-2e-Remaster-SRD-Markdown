---
title: "Patron's Claim"
noteType: ":luggage:"
aliases: "Patron's Claim"
foundryId: Item.3571sYE8ZBzEbkpp
tags:
  - Item
---

# Patron's Claim `pf2:2`

**Frequency** once per hour

* * *

**Effect** Your familiar's mouth opens impossibly wide before your patron's grasping limb stretches forth from it at a creature within 30 feet, dealing 10d10 spirit damage with a basic Fortitude save against your spell DC. If the creature fails its save and takes damage, it is also [[Drained 1|Drained 2]] (or [[Drained 1|Drained 4]] on a critical failure) and you regain 1 Focus Point, up to your usual maximum, as your patron grants you additional magic in exchange for your gift of your opponent's spirit.
