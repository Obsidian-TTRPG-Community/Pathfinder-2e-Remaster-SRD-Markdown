---
title: "Arrest a Fall"
noteType: ":luggage:"
aliases: "Arrest a Fall"
foundryId: Item.qibCJgHpUrpwyFBU
tags:
  - Item
---

# Arrest a Fall `pf2:r`

**Trigger** You fall.

**Requirements** You have a fly Speed.

* * *

You attempt an Acrobatics check or Reflex save to slow your fall. The DC is typically 15, but it might be higher due to air turbulence or other circumstances.

* * *

**Success** You take no damage from the fall.
