---
title: "Living Fortification"
noteType: ":luggage:"
aliases: "Living Fortification"
foundryId: Item.IZZYOAB8OqhGXnGh
tags:
  - Item
---

# Living Fortification `pf2:0`

**Trigger** You roll initiative.

* * *

You can posture defensively with firearms or crossbows, acting like a walking tower. Interact to draw a firearm or crossbow. You then position that weapon defensively, gaining a +1 circumstance bonus to AC until the start of your first turn, or a +2 circumstance bonus if the chosen weapon has the parry trait.


