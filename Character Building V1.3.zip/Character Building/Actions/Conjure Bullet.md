---
title: "Conjure Bullet"
noteType: ":luggage:"
aliases: "Conjure Bullet"
foundryId: Item.WAILZH0PiUp0SADI
tags:
  - Item
---

# Conjure Bullet `pf2:1`

**Frequency** once per round

* * *

**Effect** You conjure an ordinary level-0 bolt or bullet out of thin air and then immediately Interact to load it into your weapon. If the bolt or bullet isn't fired before the end of your turn, the effect is wasted.
