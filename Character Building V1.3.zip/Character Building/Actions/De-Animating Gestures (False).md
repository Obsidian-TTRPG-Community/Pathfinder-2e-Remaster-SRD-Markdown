---
title: "De-Animating Gestures (False)"
noteType: ":luggage:"
aliases: "De-Animating Gestures (False)"
foundryId: Item.N8K2veWNriHGBwwL
tags:
  - Item
---

# De-Animating Gestures (False) `pf2:1`

You designate a single construct within 30 feet that you can see or hear. The construct becomes [[Quickened|Quickened 1]] for 1 minute and is temporarily immune to this ability for 24 hours. It can use its additional action only to Stride or Strike.
