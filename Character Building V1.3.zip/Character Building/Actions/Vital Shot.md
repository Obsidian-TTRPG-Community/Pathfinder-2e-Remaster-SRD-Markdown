---
title: "Vital Shot"
noteType: ":luggage:"
aliases: "Vital Shot"
foundryId: Item.V8U89hsGnbHx3PdX
tags:
  - Item
---

# Vital Shot `pf2:2`

Your careful shot against an unsuspecting opponent pierces a vital artery or organ. Make a ranged Strike. If the target is [[Off-Guard]], the Strike deals an extra die of weapon damage, and the foe takes persistent bleed damage equal to the amount of precision damage from your One Shot, One Kill.
