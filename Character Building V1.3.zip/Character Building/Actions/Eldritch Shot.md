---
title: "Eldritch Shot"
noteType: ":luggage:"
aliases: "Eldritch Shot"
foundryId: Item.n099yewsIe3oyB9O
tags:
  - Item
---

# Eldritch Shot `pf2:3`

**Requirements** You are wielding a bow

* * *

You [[Cast a Spell]] that takes 1 or 2 actions to cast and requires a spell attack roll. The effects of the spell do not occur immediately but are imbued into the bow you're wielding.

Make a Strike with that bow. Your spell flies with the ammunition, using your attack roll result to determine the effects of both the Strike and the spell. This counts as two attacks for your multiple attack penalty, but you don't apply the penalty until after you've completed both attacks.
