---
title: "Secure Disguises"
noteType: ":luggage:"
aliases: "Secure Disguises"
foundryId: Item.1XPE8xISoBkRzVrZ
tags:
  - Item
---

# Secure Disguises
![[systems-pf2e-icons-actions-Passive.webp|150]]

You seek to procure or create disguises. Attempt a normal, hard, or very hard Crafting, Deception, Performance, or Society check.

* * *

**Success** You procure or creates disguises, gaining 1 EP that can be used only to maintain a cover identity.

**Failure** Your efforts result in an unusable disguise.
