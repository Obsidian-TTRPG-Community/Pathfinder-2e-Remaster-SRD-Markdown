---
title: "Steel Your Resolve"
noteType: ":luggage:"
aliases: "Steel Your Resolve"
foundryId: Item.Ytn4XYKDmx1NZ6Ze
tags:
  - Item
---

# Steel Your Resolve `pf2:1`

**Cost** 1 Resolve Point

* * *

Regain Stamina Points equal to half your maximum.
