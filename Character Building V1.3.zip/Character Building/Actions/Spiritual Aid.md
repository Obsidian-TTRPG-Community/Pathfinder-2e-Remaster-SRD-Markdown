---
title: "Spiritual Aid"
noteType: ":luggage:"
aliases: "Spiritual Aid"
foundryId: Item.6UzQgXZ2vfLZNIZU
tags:
  - Item
---

# Spiritual Aid `pf2:r`

**Trigger** You fail a Reflex or Will saving throw

* * *

**Effect** You reroll the triggering saving throw. You must use the second result, even if it's worse. If you roll a success, you get a critical success instead.
