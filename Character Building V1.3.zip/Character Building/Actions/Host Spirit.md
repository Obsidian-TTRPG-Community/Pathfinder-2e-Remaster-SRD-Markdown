---
title: "Host Spirit"
noteType: ":luggage:"
aliases: "Host Spirit"
foundryId: Item.38TM2tMheZ4vpxmo
tags:
  - Item
---

# Host Spirit
![[systems-pf2e-icons-actions-Passive.webp|150]]

**Frequency** once per day

* * *

**Effect** You attempt one skill check to perform an exploration activity, even if it normally requires you to be trained to do so. You're trained in the skill just long enough to make that single check (to a maximum of 10 minutes).

Whether or not the check succeeds, in the next 24 hours you must perform a minor favor to appease the spirit who aided you, determined by the GM (usually something sensation related, such as tasting a certain food, listening to a specific song, or smoking a pipe). You can't Host Spirit again until you've performed the favor. If you haven't completed it after 24 hours, you're [[Fatigued]] until the obligation is fulfilled.
