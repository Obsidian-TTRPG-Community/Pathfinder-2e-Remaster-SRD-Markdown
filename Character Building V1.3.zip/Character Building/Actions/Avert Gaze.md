---
title: "Avert Gaze"
noteType: ":luggage:"
aliases: "Avert Gaze"
foundryId: Item.gWnAMO04MS4ysNWT
tags:
  - Item
---

# Avert Gaze `pf2:1`

You avert your gaze from danger, such as a medusa's gaze. You gain a +2 circumstance bonus to saves against visual abilities that require you to look at a creature or object, such as a medusa's petrifying gaze. Your gaze remains averted until the start of your next turn.
