---
title: "Shed Spirit"
noteType: ":luggage:"
aliases: "Shed Spirit"
foundryId: Item.fUo1CO0031G6N1pg
tags:
  - Item
---

# Shed Spirit `pf2:2`

**Frequency** once per 10 minutes

* * *

**Effect** Your familiar's spirit exits its body, leaving its empty shell behind, before flying at an enemy within 20 feet and dealing 6d6 spirit damage, with a Basic Will save against your spell DC. If the familiar dealt damage, it then flies to an ally within 30 feet of the enemy, restoring Hit Points equal to half the damage dealt. Your familiar then re-forms in its original square. At 9th level, and every 2 levels thereafter, the attack deals an additional 2d6 damage.
