---
title: "Energy Shot"
noteType: ":luggage:"
aliases: "Energy Shot"
foundryId: Item.l0qdhqtx01EFpNoy
tags:
  - Item
---

# Energy Shot `pf2:0`

**Trigger** You roll initiative.

* * *

You unleash a small surge of magical energy into your weapon, shrouding the bullet with potential energy and granting it the ability to deal energy damage to your foes to exploit their weaknesses. You can Interact to draw a ranged weapon. On your first three Strikes of this encounter with a firearm or crossbow, you deal an additional 1 acid, cold, fire or electricity damage. You choose which damage type to deal as part of making each Strike.


