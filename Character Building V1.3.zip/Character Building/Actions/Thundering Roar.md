---
title: "Thundering Roar"
noteType: ":luggage:"
aliases: "Thundering Roar"
foundryId: Item.6OU0OTXcFCCB8DsG
tags:
  - Item
---

# Thundering Roar `pf2:1`

The target unleashes a powerful vocalization. Each enemy in a 10- foot emanation takes 4d8 sonic damage with a basic Will save against your spell DC. A creature that fails its Will save is also [[Frightened|Frightened 1]].

* * *

**Heightened (+2)** The damage from the roar increases by 2d8.
