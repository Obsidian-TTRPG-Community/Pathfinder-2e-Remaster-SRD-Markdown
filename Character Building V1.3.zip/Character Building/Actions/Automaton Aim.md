---
title: "Automaton Aim"
noteType: ":luggage:"
aliases: "Automaton Aim"
foundryId: Item.GdW9GiP4D1ntxD3D
tags:
  - Item
---

# Automaton Aim `pf2:1`

You steady your body and observe the events of the battlefield to maximize the range of your next shot. You reduce the penalty for firing into your weapon's second range increment from -2 to 0 for the next ranged attack you make this turn. You can use this action a second time in the same turn to reduce the penalty from firing into your weapon's third range increment from -4 to 0 for the next ranged attack you make this turn.
