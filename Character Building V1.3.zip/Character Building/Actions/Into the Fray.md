---
title: "Into the Fray"
noteType: ":luggage:"
aliases: "Into the Fray"
foundryId: Item.x8ufFAt3atnC4I6f
tags:
  - Item
---

# Into the Fray `pf2:0`

**Trigger** You roll initiative.

* * *

You know trouble can lurk around every corner, and your hands never stray far from your holsters. You can Interact to draw a one-handed ranged weapon and can then Interact to draw a one-handed melee weapon. As your first action on your first turn, you can Stride as a free action toward an enemy you can perceive. If you can't perceive any enemies or can't end your movement closer to one, you can't use this Stride.
