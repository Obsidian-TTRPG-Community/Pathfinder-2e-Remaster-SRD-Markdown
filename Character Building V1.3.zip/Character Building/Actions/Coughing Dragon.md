---
title: "Coughing Dragon"
noteType: ":luggage:"
aliases: "Coughing Dragon"
foundryId: Item.nGm8wSEu3Ni4hHbn
tags:
  - Item
---

# Coughing Dragon `pf2:2`

**Cost** 2 batches of infused reagents

* * *

**Effect** Choose either auditory or visual effects. The display gains that trait, and you attempt to counteract one or more effects within 60 feet that have this trait. On a success, the effect is suppressed until the start of your next turn, rather than ending entirely. Use your Fireworks Lore modifier as your counteract modifier, and your counteract level is equal to half your advanced alchemy level (rounded up). A coughing dragon costs 2 batches of infused reagents rather than 1, but you can increase the cost to 3 batches and spend an additional action to create an even bigger coughing dragon display that attempts to counteract both auditory and visual effects at the same time.
