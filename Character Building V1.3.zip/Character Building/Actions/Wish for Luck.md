---
title: "Wish for Luck"
noteType: ":luggage:"
aliases: "Wish for Luck"
foundryId: Item.Z0xdYORDASRg7peD
tags:
  - Item
---

# Wish for Luck `pf2:0`

**Frequency** once per day

**Trigger** You are about to roll an attack roll, saving throw, or skill check

* * *

**Effect** You wish aloud for success. Roll the check twice and take the higher result.
