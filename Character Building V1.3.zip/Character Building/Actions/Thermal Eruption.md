---
title: "Thermal Eruption"
noteType: ":luggage:"
aliases: "Thermal Eruption"
foundryId: Item.tkz1HOIRr6y9ZDvo
tags:
  - Item
---

# Thermal Eruption `pf2:2`

**Frequency** once per day

* * *

**Effect** You concentrate your thermal energy and explode it outward. All creatures in a 20 foot emanation take 14d6 fire damage with a basic Reflex save. Afterward, you lose all effects of the Dormant Eruption feat until your next daily preparations.
