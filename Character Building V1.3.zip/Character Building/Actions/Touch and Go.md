---
title: "Touch and Go"
noteType: ":luggage:"
aliases: "Touch and Go"
foundryId: Item.qkiDqjXXPzFQ6Q1O
tags:
  - Item
---

# Touch and Go `pf2:1`

**Requirements** You're wielding a combination weapon.

* * *

Your body's shadows mask your hands' steel. You can Step toward an enemy, you can Interact to change your weapon between melee or ranged modes, and you then Interact to reload.
