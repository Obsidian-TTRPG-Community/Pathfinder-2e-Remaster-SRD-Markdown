---
title: "Dragon Breath"
noteType: ":luggage:"
aliases: "Dragon Breath"
foundryId: Item.i7N5OhWrqM0FAdWp
tags:
  - Item
---

# Dragon Breath `pf2:2`

**Frequency** once per hour

* * *

**Effect** You breathe deeply and exhale a line or cone of powerful breath, much like the dragon with which you made the pact. If the dragon had a cone-shaped breath weapon, your breath weapon is a 30 foot cone. If they had a line-shaped breath weapon, your breath weapon is a 60 foot line. If they had a burst-shaped breath weapon, your breath weapon is a 10 foot burst within 60 feet. No matter the shape, it deals 1d6 damage per level, of the same damage type as the dragon's Breath Weapon, with a DC resolve reflex save, using the higher of your class DC or spell DC. This action has the same traits as the breath weapon of the dragon you made the pact with.
