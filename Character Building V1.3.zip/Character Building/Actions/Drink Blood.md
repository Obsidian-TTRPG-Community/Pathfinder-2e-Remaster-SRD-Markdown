---
title: "Drink Blood"
noteType: ":luggage:"
aliases: "Drink Blood"
foundryId: Item.yDbZeX0PESAVuZgR
tags:
  - Item
---

# Drink Blood `pf2:1`

**Requirements** A [[Grabbed]], [[Paralyzed]], [[Restrained]], [[Unconscious]], or willing creature is within your reach

* * *

**Effect** You sink your fangs into that creature and drink its blood. This requires an athletics check against the victim's Fortitude DC if the victim is grabbed, and automatically succeeds for any of the other conditions. If you succeed, the creature becomes [[Drained 1]], and you gain temporary HP equal to the target's level that last for 10 minutes. Further uses against the target don't increase the drained condition or grant you more temporary HP.
