---
title: "Settle Emotions"
noteType: ":luggage:"
aliases: "Settle Emotions"
foundryId: Item.lNlec312LdFnU18L
tags:
  - Item
---

# Settle Emotions
![[systems-pf2e-icons-actions-Passive.webp|150]]

You spend 10 minutes using techniques you've developed to calm your emotions and bring them back under control. This allows you to access your [[Catharsis]] again.
