---
title: "Mighty Rage"
noteType: ":luggage:"
aliases: "Mighty Rage"
foundryId: Item.kVZegwcm6f1aENZ2
tags:
  - Item
---

# Mighty Rage `pf2:0`

**Trigger** You use the [[Rage]] action on your turn

* * *

Use an action that has the rage trait. Alternatively, you can increase the actions of the triggering Rage to 2 to instead use a 2-action activity with the rage trait.
