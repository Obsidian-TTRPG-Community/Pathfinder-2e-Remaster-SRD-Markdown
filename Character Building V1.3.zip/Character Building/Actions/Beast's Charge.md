---
title: "Beast's Charge"
noteType: ":luggage:"
aliases: "Beast's Charge"
foundryId: Item.YLNuRRH5vpoCAize
tags:
  - Item
---

# Beast's Charge `pf2:2`

Your eidolon rushes forward, using its momentum to increase the power of its attack. Your eidolon Strides twice and then Strikes. If the eidolon moved at least 20 feet away from its starting position and moved entirely in a straight line, it gains a +1 circumstance bonus to this attack roll.
