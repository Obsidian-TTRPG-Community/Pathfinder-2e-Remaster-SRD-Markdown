---
title: "Amulet's Abeyance"
noteType: ":luggage:"
aliases: "Amulet's Abeyance"
foundryId: Item.0wQPMaH2uIuvZTig
tags:
  - Item
---

# Amulet's Abeyance `pf2:r`

**Trigger** The target of your Exploit Vulnerability would damage you or an ally within 15 feet of you.

**Requirements** You're holding your amulet implement and are benefiting from Exploit Vulnerability.

* * *

You forcefully present your amulet to turn away harm. You or a target ally within 15 feet gain resistance to all damage against the triggering damage. The resistance is equal to 2 + your level.
