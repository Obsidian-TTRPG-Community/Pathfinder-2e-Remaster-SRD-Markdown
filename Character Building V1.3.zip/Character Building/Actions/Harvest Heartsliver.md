---
title: "Harvest Heartsliver"
noteType: ":luggage:"
aliases: "Harvest Heartsliver"
foundryId: Item.96ijmRWUWyWeOwQ3
tags:
  - Item
---

# Harvest Heartsliver `pf2:r`

**Requirements** You're inside Kothogaz's body.

* * *

You attempt to steal a section of Kothogaz's heart. Attempt an attack roll or a DC 40 acrobatics check.

* * *

**Critical Success** You steal a small disharmonic heartsliver, stow it on your person, and can exit Kothogaz's body.

**Success** As critical success, but you can't exit.

**Failure** You take Kothogaz's Swallow Whole damage.

**Critical Failure** You take double Kothogaz's Swallow Whole damage and are [[Deafened]] by its heartbeat for 1 minute.
