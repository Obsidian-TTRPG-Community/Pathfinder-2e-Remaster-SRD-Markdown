---
title: "Glimpse of Redemption"
noteType: ":luggage:"
aliases: "Glimpse of Redemption"
foundryId: Item.7nwAtdWw3guxJT1s
tags:
  - Item
---

# Glimpse of Redemption `pf2:r`

**Trigger** An enemy damages your ally, and both are within 15 feet of you

* * *

Your foe hesitates under the weight of sin as visions of redemption play in their mind's eye. The foe must choose one of the following options:

*   The ally is unharmed by the triggering damage.
*   The ally gains resistance to all damage against the triggering damage equal to 2 + your level. After the damaging effect is applied, the enemy becomes [[Enfeebled 1|Enfeebled 2]] until the end of its next turn.


