---
title: "Seething Frenzy"
noteType: ":luggage:"
aliases: "Seething Frenzy"
foundryId: Item.MMuT9U5zGVNIaOCW
tags:
  - Item
---

# Seething Frenzy `pf2:1`

Your eidolon's fury boils over into a reckless, out-of-control frenzy. While frenzied, your eidolon is affected by _boost eidolon_ and gains temporary Hit Points equal to your level, but it takes a -2 penalty to AC. Your eidolon can't voluntarily end the frenzy or start another frenzy while in the frenzy.

The frenzy lasts for 1 minute, after which it's [[Fatigued]] for 1 minute and can't start another frenzy for 1 minute.
