---
title: "Shake It Off"
noteType: ":luggage:"
aliases: "Shake It Off"
foundryId: Item.dlnKce8sdZH6ZPTP
tags:
  - Item
---

# Shake It Off `pf2:r`

**Frequency** once per day

**Trigger** You fail or critically fail a saving throw against a condition or adverse effect (such as _[[Cursed Metamorphosis]]_)

* * *

**Effect** You reroll the triggering save and use the better result.
