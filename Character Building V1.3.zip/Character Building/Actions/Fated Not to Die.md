---
title: "Fated Not to Die"
noteType: ":luggage:"
aliases: "Fated Not to Die"
foundryId: Item.x7JaZktgBop9fm5A
tags:
  - Item
---

# Fated Not to Die `pf2:0`

**Trigger** You are dying

**Frequency** once per day

* * *

**Effect** Draw a harrow card, and you automatically lose the dying condition, though you remain [[Unconscious]] at 0 Hit Points. If the card you drew was from the suit of Shields, you awaken and have an amount of Hit Points restored to you equal to 1d6 + your level.
