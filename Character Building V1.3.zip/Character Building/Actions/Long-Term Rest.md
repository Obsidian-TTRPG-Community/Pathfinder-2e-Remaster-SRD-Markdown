---
title: "Long-Term Rest"
noteType: ":luggage:"
aliases: "Long-Term Rest"
foundryId: Item.cO077pbolt332hG0
tags:
  - Item
---

# Long-Term Rest
![[systems-pf2e-icons-actions-Passive.webp|150]]

You can spend an entire day and night resting during downtime to recover Hit Points equal to your Constitution modifier (minimum 1) multiplied by twice your level.
