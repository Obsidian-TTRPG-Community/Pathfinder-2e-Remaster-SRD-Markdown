---
title: "Call to Axis"
noteType: ":luggage:"
aliases: "Call to Axis"
foundryId: Item.G7Hwo2DwYRfWCgtF
tags:
  - Item
---

# Call to Axis `pf2:0`

Given by Rite of Knowing

**Frequency** once per day

**Requirements** You are about to attempt a check to Recall Knowledge. You call upon the knowledge of Axis to ensure the accuracy of your information. You roll a second time and use the higher result. If you roll a critical failure, you get a failure instead. If you roll a success, you get a critical success instead.
