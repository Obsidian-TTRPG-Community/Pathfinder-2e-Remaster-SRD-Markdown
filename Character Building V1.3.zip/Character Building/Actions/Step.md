---
title: "Step"
noteType: ":luggage:"
aliases: "Step"
foundryId: Item.ri8pd4MBBRgp9sBV
tags:
  - Item
---

# Step `pf2:1`

**Requirements** Your Speed is at least 10 feet.

* * *

You carefully move 5 feet. Unlike most types of movement, Stepping doesn't trigger reactions, such as [[Reactive Strike]], that can be triggered by move actions or upon leaving or entering a square.

You can't Step into difficult terrain, and you can't Step using a Speed other than your land Speed.
