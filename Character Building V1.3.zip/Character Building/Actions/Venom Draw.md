---
title: "Venom Draw"
noteType: ":luggage:"
aliases: "Venom Draw"
foundryId: Item.Y5SIdhoyX1AjLSbK
tags:
  - Item
---

# Venom Draw `pf2:1`

**Requirements** Your [[Envenom]] action hasn't been expended.

* * *

You quickly envenom poisonous saliva on your weapon as you draw it. Interact to draw a weapon, and then Envenom it. This uses up your daily use of Envenom.
