---
title: "Trip"
noteType: ":luggage:"
aliases: "Trip"
foundryId: Item.M9JfU1xmL3emdZX7
tags:
  - Item
---

# Trip `pf2:1`

**Requirements** You have at least one hand free. Your target can't be more than one size larger than you

* * *

You try to knock a creature to the ground. Attempt an Athletics check against the target's Reflex DC.

* * *

**Critical Success** The target falls and lands [[Prone]] and takes 1d6 bludgeoning damage.

**Success** The target falls and lands prone.

**Critical Failure** You lose your balance and fall and land prone.
