---
title: "Swim"
noteType: ":luggage:"
aliases: "Swim"
foundryId: Item.EcBIG716AyApVnSv
tags:
  - Item
---

# Swim
![[icons-magic-water-pseudopod-swirl-blue.webp|150]]

Azarketi get a base Swim speed of 30.
