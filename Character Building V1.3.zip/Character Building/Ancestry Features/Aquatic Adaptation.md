---
title: "Aquatic Adaptation"
noteType: ":luggage:"
aliases: "Aquatic Adaptation"
foundryId: Item.CFSQo7aOXZvqQSuW
tags:
  - Item
---

# Aquatic Adaptation
![[systems-pf2e-icons-features-ancestry--aquatic-adaptation.webp|150]]

Your reptilian biology allows you to hold your breath for a long time. You gain the [[Breath Control]] general feat as a bonus feat.
