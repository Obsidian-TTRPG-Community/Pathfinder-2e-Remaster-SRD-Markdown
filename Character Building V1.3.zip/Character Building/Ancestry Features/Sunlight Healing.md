---
title: "Sunlight Healing"
noteType: ":luggage:"
aliases: "Sunlight Healing"
foundryId: Item.PmdJKNuRGALUaN1G
tags:
  - Item
---

# Sunlight Healing
![[icons-magic-light-explosion-beam-impact-silhouette.webp|150]]

A conrasu can enter a meditative, healing state as a 10-minute activity when exposed to direct sunlight, in which case they recover 1d8 Hit Points. At 3rd level, and every 2 levels thereafter, this healing increases by 1d8. 
Once a conrasu has recovered Hit Points in this way, they are temporarily immune to further uses of Sunlight Healing for 1 day.
