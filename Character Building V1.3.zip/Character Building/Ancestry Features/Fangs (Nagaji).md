---
title: "Fangs (Nagaji)"
noteType: ":luggage:"
aliases: "Fangs (Nagaji)"
foundryId: Item.HG173LxIOo3OK5xi
tags:
  - Item
---

# Fangs (Nagaji)
![[systems-pf2e-icons-unarmed-attacks-fangs.webp|150]]

Your mouth contains either rows of hooked, needle-sharp teeth or a pair of vicious serpent fangs. You gain a fangs unarmed attack that deals 1d6 piercing damage. Your fangs are in the brawling group and have the finesse and unarmed traits.
