---
title: "Change Shape (Anadi)"
noteType: ":luggage:"
aliases: "Change Shape (Anadi)"
foundryId: Item.6EqrRetjaxuo19bo
tags:
  - Item
---

# Change Shape (Anadi)
![[icons-creatures-invertebrates-tick-cross-glowing-purple.webp|150]]

As a anadi, you gain the [[Change Shape (Anadi)]] ability.
