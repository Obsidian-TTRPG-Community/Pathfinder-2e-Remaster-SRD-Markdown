---
title: "Low-Light Vision"
noteType: ":luggage:"
aliases: "Low-Light Vision"
foundryId: Item.vhqmqPhkFBVPiE93
tags:
  - Item
---

# Low-Light Vision
![[systems-pf2e-icons-features-ancestry-low-light-vision.webp|150]]

A creature with low-light vision can see in dim light as though it were bright light, so it ignores the [[Concealed]] condition due to dim light.
