---
title: "Prehensile Tail"
noteType: ":luggage:"
aliases: "Prehensile Tail"
foundryId: Item.pE4kax5fC1yfmpm9
tags:
  - Item
---

# Prehensile Tail
![[systems-pf2e-icons-default-icons-feat.svg|150]]

You can use your long, flexible tail to perform Interact actions requiring a free hand, even if both hands are otherwise occupied. Your tail can't perform actions that require fingers or significant manual dexterity, including any action that would require a check to accomplish, and you can't use it to hold items.
