---
title: "Unusual Anatomy"
noteType: ":luggage:"
aliases: "Unusual Anatomy"
foundryId: Item.GzBXpIroJpWI31Ly
tags:
  - Item
---

# Unusual Anatomy
![[systems-pf2e-icons-features-ancestry-unusual-anatomy.webp|150]]

Your unorthodox body resists physical afflictions meant for other creatures. You gain a +1 circumstance bonus to saves against diseases and poisons.
