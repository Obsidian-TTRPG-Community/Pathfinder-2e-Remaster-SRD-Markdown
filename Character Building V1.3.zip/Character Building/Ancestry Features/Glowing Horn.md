---
title: "Glowing Horn"
noteType: ":luggage:"
aliases: "Glowing Horn"
foundryId: Item.QKNxsiDoo1CgOZoN
tags:
  - Item
---

# Glowing Horn
![[systems-pf2e-icons-spells-searing-light.webp|150]]

Your horn reacts to psychic energy by softly glowing. The horn emanates dim light in a 10 foot emanation until the start of your next turn whenever you use an occult action you gained from an ancestry feat, cast an innate occult spell, or Cast a Spell that has the mental trait.
