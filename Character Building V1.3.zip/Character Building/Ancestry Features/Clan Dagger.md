---
title: "Clan Dagger"
noteType: ":luggage:"
aliases: "Clan Dagger"
foundryId: Item.n9fUl1BDlZZUAjqp
tags:
  - Item
---

# Clan Dagger
![[systems-pf2e-icons-equipment-weapons-clan-dagger.webp|150]]

You get one [[Clan Dagger|clan dagger]] of your clan for free, as it was given to you at birth. Selling this dagger is a terrible taboo and earns you the disdain of other dwarves.
