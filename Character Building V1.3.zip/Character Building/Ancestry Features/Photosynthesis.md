---
title: "Photosynthesis"
noteType: ":luggage:"
aliases: "Photosynthesis"
foundryId: Item.lMULosqV4yf6DMty
tags:
  - Item
---

# Photosynthesis
![[icons-magic-nature-root-vine-beanstolk-green.webp|150]]

You gain nourishment from photosynthesis. You typically don't need to pay for food. If you go without sunlight for 1 week, you begin to starve. You can derive nourishment from specially formulated bottles of alchemical sunlight instead of natural sunlight, but these bottles cost 10 times as much as standard rations (40 sp).
