---
title: "Sharp Beak"
noteType: ":luggage:"
aliases: "Sharp Beak"
foundryId: Item.OkhjfDOAArTpgTeL
tags:
  - Item
---

# Sharp Beak
![[systems-pf2e-icons-features-ancestry-sharp-beak.webp|150]]

With your Sharp Beak, you are never without a weapon. You have a beak unarmed attack that deals 1d6 piercing damage. Your beak is in the brawling weapon group and has the finesse and unarmed traits.
