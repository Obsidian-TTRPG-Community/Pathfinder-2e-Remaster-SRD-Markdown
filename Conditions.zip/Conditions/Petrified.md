---
title: "Petrified"
icon: ":luggage:"
aliases: "Petrified"
foundryId: Item.29bVgZfr89zyQ4h7
tags:
  - Item
---

# Petrified
![[systems-pf2e-icons-conditions-petrified.webp|150 lp right]]

You have been turned to stone. You can't act, nor can you sense anything. You become an object with a Bulk double your normal Bulk (typically 12 for a petrified Medium creature or 6 for a petrified Small creature), AC 9, Hardness 8, and the same current Hit Points you had when alive. You don't have a Broken Threshold. When you're turned back into flesh, you have the same number of Hit Points you had as a statue. If the statue is destroyed, you immediately die. While petrified, your mind and body are in stasis, so you don't age or notice the passing of time.


