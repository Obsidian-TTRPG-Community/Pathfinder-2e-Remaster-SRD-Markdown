---
title: "Doomed 1"
icon: ":luggage:"
aliases: "Doomed 1"
foundryId: Item.eXsORiPkldtGRWp6
tags:
  - Item
---

# Doomed 1
![[systems-pf2e-icons-conditions-doomed.webp|150 lp right]]

A powerful force has gripped your soul, calling you closer to death. Doomed always includes a value. The [[Dying 1|Dying]] value at which you die is reduced by your doomed value. If your maximum dying value is reduced to 0, you instantly die. When you die, you're no longer doomed.

Your doomed value decreases by 1 each time you get a full night's rest.


