---
title: "Immobilized"
icon: ":luggage:"
aliases: "Immobilized"
foundryId: Item.cQOu8j36aAVm6KjL
tags:
  - Item
---

# Immobilized
![[systems-pf2e-icons-conditions-immobilized.webp|150 lp right]]

You can't use any action with the move trait. If you're immobilized by something holding you in place and an external force would move you out of your space, the force must succeed at a check against either the DC of the effect holding you in place or the relevant defense (usually Fortitude DC) of the monster holding you in place.


