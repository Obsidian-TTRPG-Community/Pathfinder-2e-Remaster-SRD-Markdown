---
title: "Fatigued"
icon: ":luggage:"
aliases: "Fatigued"
foundryId: Item.ZvlXeeno0lyaNUg9
tags:
  - Item
---

# Fatigued
![[systems-pf2e-icons-conditions-fatigued.webp|150 lp right]]

You're tired and can't summon much energy. You take a -1 status penalty to AC and saving throws. While exploring, you can't choose an exploration activity.

You recover from fatigue after a full night's rest.


