---
title: "Frightened 1"
icon: ":luggage:"
aliases: "Frightened 1"
foundryId: Item.sFDafu44xyDgf0rg
tags:
  - Item
---

# Frightened 1
![[systems-pf2e-icons-conditions-frightened.webp|150 lp right]]

You're gripped by fear and struggle to control your nerves. The frightened condition always includes a value. You take a status penalty equal to this value to all your checks and DCs. Unless specified otherwise, at the end of each of your turns, the value of your frightened condition decreases by 1.


