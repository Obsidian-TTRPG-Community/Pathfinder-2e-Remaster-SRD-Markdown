---
title: "Dazzled"
icon: ":luggage:"
aliases: "Dazzled"
foundryId: Item.h6ohwa66Y1cVZf1t
tags:
  - Item
---

# Dazzled
![[systems-pf2e-icons-conditions-dazzled.webp|150 lp right]]

Your eyes are overstimulated. If vision is your only precise sense, all creatures and objects are [[Concealed]] from you.


