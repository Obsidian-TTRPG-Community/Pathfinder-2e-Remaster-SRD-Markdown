---
title: "Stupefied 1"
icon: ":luggage:"
aliases: "Stupefied 1"
foundryId: Item.qWxlWsdrAnUANFLI
tags:
  - Item
---

# Stupefied 1
![[systems-pf2e-icons-conditions-stupefied.webp|150 lp right]]

Your thoughts and instincts are clouded. Stupefied always includes a value. You take a status penalty equal to this value on Intelligence-, Wisdom-, and Charisma-based checks and DCs, including Will saving throws, spell attack rolls, spell DCs, and skill checks that use these ability scores. Any time you attempt to [[Cast a Spell]] while stupefied, the spell is disrupted unless you succeed at a flat check with a DC equal to 5 + your stupefied value.


