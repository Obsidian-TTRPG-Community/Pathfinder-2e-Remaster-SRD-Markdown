---
title: "Wounded 1"
icon: ":luggage:"
aliases: "Wounded 1"
foundryId: Item.LiTTuxizvjY5zjWa
tags:
  - Item
---

# Wounded 1
![[systems-pf2e-icons-conditions-wounded.webp|150 lp right]]

You have been seriously injured. If you lose the [[Dying 1|Dying]] condition and do not already have the wounded condition, you become wounded 1. If you already have the wounded condition when you lose the dying condition, your wounded condition value increases by 1. If you gain the dying condition while wounded, increase your dying condition value by your wounded value.

The wounded condition ends if someone successfully restores Hit Points to you with [[Treat Wounds]], or if you are restored to full Hit Points and rest for 10 minutes.


