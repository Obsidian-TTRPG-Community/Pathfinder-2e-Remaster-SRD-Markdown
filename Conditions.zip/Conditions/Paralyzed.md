---
title: "Paralyzed"
icon: ":luggage:"
aliases: "Paralyzed"
foundryId: Item.8Vk0UKs12lw7y0Yk
tags:
  - Item
---

# Paralyzed
![[systems-pf2e-icons-conditions-paralyzed.webp|150 lp right]]

Your body is frozen in place. You have the [[Off-Guard]] condition and can't act except to [[Recall Knowledge]] and use actions that require only the use of your mind (as determined by the GM). Your senses still function, but only in the areas you can perceive without moving your body, so you can't [[Seek]] while paralyzed.


