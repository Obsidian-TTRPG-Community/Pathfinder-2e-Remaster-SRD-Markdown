---
title: "Slowed 1"
icon: ":luggage:"
aliases: "Slowed 1"
foundryId: Item.3nNYy2uW4Q9TYft7
tags:
  - Item
---

# Slowed 1
![[systems-pf2e-icons-conditions-slowed.webp|150 lp right]]

You have fewer actions. Slowed always includes a value. When you regain your actions at the start of your turn, reduce the number of actions you regain by your slowed value. Because slowed has its effect at the start of your turn, you don't immediately lose actions if you become slowed during your turn.


