---
title: "Blinded"
icon: ":luggage:"
aliases: "Blinded"
foundryId: Item.kSXpwZ03cqJnLLJG
tags:
  - Item
---

# Blinded
![[systems-pf2e-icons-conditions-blinded.webp|150 lp right]]

You can't see. All normal terrain is difficult terrain to you. You can't detect anything using vision. You automatically critically fail Perception checks that require you to be able to see, and if vision is your only precise sense, you take a -4 status penalty to Perception checks. You are immune to visual effects. Blinded overrides [[Dazzled]].


