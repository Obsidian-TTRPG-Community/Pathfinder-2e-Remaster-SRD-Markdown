---
title: "Restrained"
icon: ":luggage:"
aliases: "Restrained"
foundryId: Item.U5nzqRmvmKqw2mt2
tags:
  - Item
---

# Restrained
![[systems-pf2e-icons-conditions-restrained.webp|150 lp right]]

You're tied up and can barely move, or a creature has you pinned. You have the [[Off-Guard]] and [[Immobilized]] conditions, and you can't use any actions with the attack or manipulate traits except to attempt to [[Escape]] or [[Force Open]] your bonds. Restrained overrides [[Grabbed]].


