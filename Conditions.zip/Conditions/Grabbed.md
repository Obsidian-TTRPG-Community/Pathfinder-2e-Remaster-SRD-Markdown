---
title: "Grabbed"
icon: ":luggage:"
aliases: "Grabbed"
foundryId: Item.RwKPTvkw7BAvFb0x
tags:
  - Item
---

# Grabbed
![[systems-pf2e-icons-conditions-grabbed.webp|150 lp right]]

You're held in place by another creature, giving you the [[Off-Guard]] and [[Immobilized]] conditions. If you attempt a manipulate action while grabbed, you must succeed at a DC 5 flat check or it is lost; roll the check after spending the action, but before any effects are applied.


