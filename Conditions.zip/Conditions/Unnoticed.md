---
title: "Unnoticed"
icon: ":luggage:"
aliases: "Unnoticed"
foundryId: Item.mthCSfu0kVLVhsjh
tags:
  - Item
---

# Unnoticed
![[systems-pf2e-icons-conditions-unnoticed.webp|150 lp right]]

If you are unnoticed by a creature, that creature has no idea you are present at all. When you're unnoticed, you're also [[Undetected]] by the creature. This condition matters for abilities that can be used only against targets totally unaware of your presence.


