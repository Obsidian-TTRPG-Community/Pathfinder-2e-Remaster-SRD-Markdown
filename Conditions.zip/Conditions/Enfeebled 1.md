---
title: "Enfeebled 1"
icon: ":luggage:"
aliases: "Enfeebled 1"
foundryId: Item.YnxkoZNkQkIBR6wG
tags:
  - Item
---

# Enfeebled 1
![[systems-pf2e-icons-conditions-enfeebled.webp|150 lp right]]

You're physically weakened. Enfeebled always includes a value. When you are enfeebled, you take a status penalty equal to the condition value to Strength-based rolls and DCs, including Strength-based melee attack rolls, Strength-based damage rolls, and Athletics checks.


