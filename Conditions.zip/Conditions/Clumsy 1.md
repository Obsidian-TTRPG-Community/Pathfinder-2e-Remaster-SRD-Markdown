---
title: "Clumsy 1"
icon: ":luggage:"
aliases: "Clumsy 1"
foundryId: Item.YgdTY2YnIg6ab9N4
tags:
  - Item
---

# Clumsy 1
![[systems-pf2e-icons-conditions-clumsy.webp|150 lp right]]

Your movements become clumsy and inexact. Clumsy always includes a value. You take a status penalty equal to the condition value to Dexterity-based checks and DCs, including AC, Reflex saves, ranged attack rolls, and skill checks using Acrobatics, Stealth, and Thievery.


