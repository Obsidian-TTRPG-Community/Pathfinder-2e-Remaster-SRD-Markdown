---
title: "Controlled"
icon: ":luggage:"
aliases: "Controlled"
foundryId: Item.oslJeC7KzsJV9Mw8
tags:
  - Item
---

# Controlled
![[systems-pf2e-icons-conditions-controlled.webp|150 lp right]]

Someone else is making your decisions for you, usually because you're being commanded or magically dominated. The controller dictates how you act and can make you use any of your actions, including attacks, reactions, or even [[Delay]]. The controller usually does not have to spend their own actions when controlling you.


