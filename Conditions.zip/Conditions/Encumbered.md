---
title: "Encumbered"
icon: ":luggage:"
aliases: "Encumbered"
foundryId: Item.3gYNWyTHJ7cLVqfn
tags:
  - Item
---

# Encumbered
![[systems-pf2e-icons-conditions-encumbered.webp|150 lp right]]

You are carrying more weight than you can manage. While you're encumbered, you're [[Clumsy 1]] and take a 10-foot penalty to all your Speeds. As with all penalties to your Speed, this can't reduce your Speed below 5 feet.


