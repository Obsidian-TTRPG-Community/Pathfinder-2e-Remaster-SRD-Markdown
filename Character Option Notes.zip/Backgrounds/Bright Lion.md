---
title: "Bright Lion"
icon: ":luggage:"
aliases: "Bright Lion"
foundryId: Item.B36XCNfSlmR71DYw
tags:
  - Item
---

# Bright Lion
![[systems-pf2e-icons-default-icons-background.svg|150]]

**Prerequisite** Region - Mwangi Expanse

* * *

You are a member of the Bright Lions and seek to overthrow the tyrannical reign of Walkena and free Mzali from his cruel whims. You're experienced operating undercover and have had to be cautious of what you say and who you trust, lest you fall afoul of the god-king's terrible punishments.

Choose two ability boosts. One must be to **Strength** or **Charisma**, and one is a free ability boost.

You're trained in the Deception skill and the Mzali Lore skill. You gain the [[Lie to Me|Lie To Me]] skill feat.


