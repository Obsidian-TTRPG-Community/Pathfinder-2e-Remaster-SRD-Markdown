---
title: "Animal Whisperer"
icon: ":luggage:"
aliases: "Animal Whisperer"
foundryId: Item.RObYT5txXbuoYiqq
tags:
  - Item
---

# Animal Whisperer
![[systems-pf2e-icons-default-icons-background.svg|150]]

You have always felt a connection to animals, and it was only a small leap to learn to train them. As you travel, you continuously encounter different creatures, befriending them along the way.

Choose two attribute boosts. One must be to **Wisdom** or **Charisma**, and one is a free attribute boost.

You're trained in the Nature skill and a Lore skill related to one terrain inhabited by animals you like (such as Plains Lore or Swamp Lore). You gain the [[Train Animal]] skill feat.


