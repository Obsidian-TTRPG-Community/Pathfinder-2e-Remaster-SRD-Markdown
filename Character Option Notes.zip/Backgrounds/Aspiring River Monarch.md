---
title: "Aspiring River Monarch"
icon: ":luggage:"
aliases: "Aspiring River Monarch"
foundryId: Item.E9DjYzdWZcQmLskA
tags:
  - Item
---

# Aspiring River Monarch
![[systems-pf2e-icons-default-icons-background.svg|150]]

**Prerequisite** Region - Broken Lands

* * *

New realms rise constantly in the River Kingdoms, and you intend to lead one of them. Making your reign last, however, will require both strength and grace.

Choose two ability boosts. One must be to **Wisdom** or **Charisma**, and one is a free ability boost.

You're trained in the Society skill and the Politics Lore skill. You gain the [[Courtly Graces]] skill feat.


