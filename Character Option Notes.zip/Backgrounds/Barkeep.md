---
title: "Barkeep"
icon: ":luggage:"
aliases: "Barkeep"
foundryId: Item.a4zo1znfYiyh1Hpf
tags:
  - Item
---

# Barkeep
![[systems-pf2e-icons-default-icons-background.svg|150]]

You have five specialties: hefting barrels, drinking, polishing steins, drinking, and drinking. You worked in a bar, where you learned how to hold your liquor and rowdily socialize.

Choose two attribute boosts. One must be to **Constitution** or **Charisma**, and one is a free attribute boost.

You're trained in the Diplomacy skill and the Alcohol Lore skill. You gain the [[Hobnobber]] skill feat.


