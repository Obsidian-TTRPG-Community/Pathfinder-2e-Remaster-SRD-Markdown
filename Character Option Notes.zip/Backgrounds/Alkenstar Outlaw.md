---
title: "Alkenstar Outlaw"
icon: ":luggage:"
aliases: "Alkenstar Outlaw"
foundryId: Item.vWFQYx8OwtStgIrF
tags:
  - Item
---

# Alkenstar Outlaw
![[systems-pf2e-icons-default-icons-background.svg|150]]

You're an outlaw whose first crime was stealing the guns from Alkenstar's Gunworks which allowed you to commence a crime spree of epic proportions. You don't know where your road ends, but it's probably going to be a bloody affair. The life of an adventurer might even be a relief compared to a life forever on the run from Alkenstar authorities and their allies.

Choose two ability boosts. One boost must be to **Dexterity** or **Constitution**, and one is a free ability boost.

You're trained in Thievery and Underworld Lore. You gain the [[Subtle Theft]] skill feat.


