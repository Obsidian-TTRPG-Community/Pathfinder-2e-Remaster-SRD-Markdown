---
title: "Bellflower Agent"
icon: ":luggage:"
aliases: "Bellflower Agent"
foundryId: Item.aimzPA317Jpp9WnR
tags:
  - Item
---

# Bellflower Agent
![[systems-pf2e-icons-default-icons-background.svg|150]]

**Prerequisite** Region - Old Cheliax

* * *

You joined a secret society dedicated to freeing halfling slaves, most likely from the cruelty of Chelish reign. You know how to smuggle people in and out of countries.

Choose two ability boosts. One must be to **Dexterity** or **Charisma**, and one is a free ability boost.

You're trained in the Stealth skill and the Underworld Lore skill. You gain the [[Experienced Smuggler]] skill feat.


