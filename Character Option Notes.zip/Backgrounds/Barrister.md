---
title: "Barrister"
icon: ":luggage:"
aliases: "Barrister"
foundryId: Item.Exkz8iKsAA9U0VCL
tags:
  - Item
---

# Barrister
![[systems-pf2e-icons-default-icons-background.svg|150]]

Piles of legal manuals, stern teachers, and experience in the courtroom have instructed you in legal matters. You're capable of mounting a prosecution or defense in court, and you tend to keep abreast of local laws, as you never can tell when you might need to know them on short notice.

Choose two attribute boosts. One must be to **Intelligence** or **Charisma**, and one is a free attribute boost.

You're trained in the Diplomacy skill and the Legal Lore skill. You gain the [[Group Impression]] skill feat.


