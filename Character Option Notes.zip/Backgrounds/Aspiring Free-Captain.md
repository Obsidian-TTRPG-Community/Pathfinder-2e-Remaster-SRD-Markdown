---
title: "Aspiring Free-Captain"
icon: ":luggage:"
aliases: "Aspiring Free-Captain"
foundryId: Item.fhn2cstipMKp96XG
tags:
  - Item
---

# Aspiring Free-Captain
![[systems-pf2e-icons-default-icons-background.svg|150]]

**Prerequisite** Region - High Seas

* * *

You seek to join the Free Captains of the Shackles and have learned everything you need to know about sailing and bossing people around. Now you just need a crew and a ship.

Choose two ability boosts. One must be to **Wisdom** or **Charisma**, and one is a free ability boost.

You're trained in the Intimidation skill and the Sailing Lore skill. You gain the [[Group Coercion]] skill feat.


