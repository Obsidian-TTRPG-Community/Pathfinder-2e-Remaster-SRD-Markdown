---
title: "Alkenstar Tinker"
icon: ":luggage:"
aliases: "Alkenstar Tinker"
foundryId: Item.EeoFKJKKToJFan8D
tags:
  - Item
---

# Alkenstar Tinker
![[systems-pf2e-icons-default-icons-background.svg|150]]

**Prerequisite** Region - Impossible Lands

* * *

Your dedication to the scientific inquiry of your native Alkenstar provides great insight into mechanical and chemical innovation.

Choose two ability boosts. One must be to **Dexterity** or **Intelligence**, and one is a free ability boost.

You're trained in the Crafting skill and the Engineering Lore skill. You gain the [[Alchemical Crafting]] skill feat.


