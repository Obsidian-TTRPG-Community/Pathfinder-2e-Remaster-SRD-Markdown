---
title: "Chelish Rebel"
icon: ":luggage:"
aliases: "Chelish Rebel"
foundryId: Item.RLD7ZmKO4IUPgOdX
tags:
  - Item
---

# Chelish Rebel
![[systems-pf2e-icons-default-icons-background.svg|150]]

**Prerequisite** Region - Old Cheliax

* * *

You joined the fight against House Thrune. You may have helped liberate the nation of Ravounel, or you might be involved in another rebellion, such as Pezzack's, that studied Ravounel's successes.

Choose two ability boosts. One must be to **Dexterity** or **Charisma**, and one is a free ability boost.

You're trained in the Society skill and the Kintargo Lore skill. You gain the [[Streetwise]] skill feat.


