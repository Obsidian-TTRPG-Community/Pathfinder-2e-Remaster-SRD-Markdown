---
title: "Acolyte"
icon: ":luggage:"
aliases: "Acolyte"
foundryId: Item.XVQptPwfpjaEVSvs
tags:
  - Item
---

# Acolyte
![[systems-pf2e-icons-default-icons-background.svg|150]]

You spent your early days in a religious monastery or cloister. You may have traveled out into the world to spread the message of your religion or because you cast away the teachings of your faith, but deep down, you'll always carry within you the lessons you learned.

Choose two attribute boosts. One must be to **Intelligence** or **Wisdom**, and one is a free attribute boost.

You're trained in the Religion skill and the Scribing Lore skill. You gain the [[Student of the Canon]] skill feat.


