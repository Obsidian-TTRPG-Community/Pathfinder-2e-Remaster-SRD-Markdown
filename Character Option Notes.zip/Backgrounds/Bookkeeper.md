---
title: "Bookkeeper"
icon: ":luggage:"
aliases: "Bookkeeper"
foundryId: Item.iCWGGLXiBIBNhgXE
tags:
  - Item
---

# Bookkeeper
![[systems-pf2e-icons-default-icons-background.svg|150]]

You ran the numbers on a large farm, for a merchant's endeavors, or with a major guild in the city. You kept track of expenses, payroll, profits, and anything else that had to do with money, for better or worse. If better, you might be adventuring to learn how others ply this trade. If worse, you may be fleeing from impending consequences, in the hope that no one finds you.

Choose two ability boosts. One must be to **Intelligence** or **Wisdom**, and one is a free ability boost.

You're trained in the Society skill and the Accounting Lore skill. You gain the [[Eye For Numbers]] skill feat.


