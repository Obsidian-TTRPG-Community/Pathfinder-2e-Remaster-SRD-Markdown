---
title: "Black Market Smuggler"
icon: ":luggage:"
aliases: "Black Market Smuggler"
foundryId: Item.SSJOuSm4AO02yDfu
tags:
  - Item
---

# Black Market Smuggler
![[systems-pf2e-icons-default-icons-background.svg|150]]

**Prerequisite** Region - Golden Road

* * *

You know how to work the less-than-legal side of the region's markets and know how to slip contraband past the authorities.

Choose two ability boosts. One must be to **Wisdom** or **Charisma**, and one is a free ability boost.

You're trained in the Stealth skill and the Underworld Lore skill. You gain the [[Experienced Smuggler]] skill feat.


