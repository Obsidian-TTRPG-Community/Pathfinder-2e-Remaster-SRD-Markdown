---
title: "Anti-Tech Activist"
icon: ":luggage:"
aliases: "Anti-Tech Activist"
foundryId: Item.Dp0hG8fsF63RZRh2
tags:
  - Item
---

# Anti-Tech Activist
![[systems-pf2e-icons-default-icons-background.svg|150]]

You've seen the sorts of things that technology brings- polluted environments, workers put out of their jobs or horribly injured, and the slow erosion of society-and you've vowed to inform the larger world of these ills. You do so with long, impassioned speeches on street corners and village squares and by talking personally with the heads of various guilds. Adventuring into the wider world could help spread your message even farther.

Choose two ability boosts. One must be to **Constitution** or **Charisma**, and one is a free ability boost.

You're trained in the Intimidation skill and the Guild Lore skill. You gain the [[Group Coercion]] skill feat.


