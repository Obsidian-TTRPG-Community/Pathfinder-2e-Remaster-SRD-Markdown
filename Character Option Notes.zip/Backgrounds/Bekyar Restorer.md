---
title: "Bekyar Restorer"
icon: ":luggage:"
aliases: "Bekyar Restorer"
foundryId: Item.xDi4PGxk8lNFRKwL
tags:
  - Item
---

# Bekyar Restorer
![[systems-pf2e-icons-default-icons-background.svg|150]]

**Prerequisite** Region - Mwangi Expanse

* * *

Though many Bekyars worship demons, you seek to pave a different path for yourself and your kindred, while also attempting to change other Mwangi's treatment of your culture.

Choose two ability boosts. One must be to **Wisdom** or **Charisma**, and one is a free ability boost.

You're trained in the Diplomacy skill and the Abyss Lore skill. You gain the [[Group Impression]] skill feat.


