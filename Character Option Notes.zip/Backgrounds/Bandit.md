---
title: "Bandit"
icon: ":luggage:"
aliases: "Bandit"
foundryId: Item.XDlvagupuYmg4dYj
tags:
  - Item
---

# Bandit
![[systems-pf2e-icons-default-icons-background.svg|150]]

Your past includes no small amount of rural banditry, robbing travelers on the road and scraping by. Whether your robbery was sanctioned by a local noble or you did so of your own accord, you eventually got caught up in the adventuring life.

Choose two attribute boosts. One must be to **Dexterity** or **Charisma**, and one is a free attribute boost.

You're trained in the Intimidation skill and a Lore skill related to the terrain you worked in (such as Desert Lore or Plains Lore). You gain the [[Group Coercion]] skill feat.


