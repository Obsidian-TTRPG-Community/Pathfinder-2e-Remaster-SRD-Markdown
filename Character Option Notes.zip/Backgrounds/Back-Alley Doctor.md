---
title: "Back-Alley Doctor"
icon: ":luggage:"
aliases: "Back-Alley Doctor"
foundryId: Item.jMxAjyuTpiXDx6bL
tags:
  - Item
---

# Back-Alley Doctor
![[systems-pf2e-icons-default-icons-background.svg|150]]

You're the medic many turn to when a more official clinic or healer might not be available. You may specialize in stitching up bullet wounds or have a standing, confidential deal with a criminal syndicate to provide your services any time of day or night. In either case, you've perhaps turned to the adventuring life because a former client is unhappy with your work or members of the local constabulary have been asking too many questions.

Choose two ability boosts. One must be to **Constitution** or **Wisdom**, and one is a free ability boost.

You're trained in the Medicine skill and the Underworld Lore skill. You gain the [[Risky Surgery]] skill feat.


