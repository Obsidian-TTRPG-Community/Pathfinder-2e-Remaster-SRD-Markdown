---
title: "Blood Feast"
icon: ":luggage:"
aliases: "Blood Feast"
foundryId: Item.kfpIsPTwJr7BEpFl
tags:
  - Item
---

# Blood Feast `pf2:2`

Your vampiric animal companion attacks a bleeding foe and drinks its blood. Your companion attempts a Strike against a creature currently taking persistent bleed damage. The Strike deals 2d8 additional. If the Strike hits and deals damage, your vampiric animal companion gains temporary Hit Points equal to half your level that last for up to 1 minute.


