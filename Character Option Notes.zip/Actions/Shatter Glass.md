---
title: "Shatter Glass"
icon: ":luggage:"
aliases: "Shatter Glass"
foundryId: Item.5Yy85K3UDtUwJiHT
tags:
  - Item
---

# Shatter Glass `pf2:r`

**Trigger** An adjacent creature Strikes you with a melee weapon or unarmed attack and deals damage

**Requirements** Your innate _[[Mountain Resilience]]_ from [[Glass Skin]] is active

* * *

**Effect** You shatter some of the glass on your skin to damage your attacker. The attacker takes 3d10 slashing damage and the duration of the stoneskin decreases by 1 minute. At 14th level, the damage increases to 4d10 slashing damage, and at 18th level, the damage increases to 5d10 slashing damage.


