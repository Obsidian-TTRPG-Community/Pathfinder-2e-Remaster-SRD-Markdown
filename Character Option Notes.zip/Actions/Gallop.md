---
title: "Gallop"
icon: ":luggage:"
aliases: "Gallop"
foundryId: Item.4qfDx0yCPApu0kFQ
tags:
  - Item
---

# Gallop `pf2:2`

The skeletal mount Strides twice, with a +10-foot circumstance bonus to its Speed.


