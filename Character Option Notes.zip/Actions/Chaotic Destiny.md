---
title: "Chaotic Destiny"
icon: ":luggage:"
aliases: "Chaotic Destiny"
foundryId: Item.l06EGPjDWQFnzoPy
tags:
  - Item
---

# Chaotic Destiny `pf2:0`

**Trigger** You fail a saving throw during a combat

**Frequency** once per day

* * *

**Effect** Chaos intervenes on your behalf at the last instant as you fail a saving throw. Draw a harrow card and reroll the saving throw you failed. You must take the result of the reroll, but if you drew a card from the suit of Crowns, improve the result by one degree of success.


