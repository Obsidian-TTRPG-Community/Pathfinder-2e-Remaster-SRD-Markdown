---
title: "Telekinetic Assault"
icon: ":luggage:"
aliases: "Telekinetic Assault"
foundryId: Item.DDJd2ZjOkD5D331i
tags:
  - Item
---

# Telekinetic Assault `pf2:2`

Your ghost unleashes a flurry of emotions, causing small objects and debris to fly about in a 20 foot emanation, dealing 1d6 bludgeoning for every 2 levels the ghost has (basic Reflex save). This uses a trained DC using the ghost's Charisma modifier or an expert DC if the ghost is specialized.


