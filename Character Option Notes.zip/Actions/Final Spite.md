---
title: "Final Spite"
icon: ":luggage:"
aliases: "Final Spite"
foundryId: Item.xzDkmw5UZtadi3If
tags:
  - Item
---

# Final Spite `pf2:r`

**Frequency** once per day

**Trigger** You're reduced to 0 Hit Points

* * *

**Effect** You make a Strike before falling [[Unconscious]].


