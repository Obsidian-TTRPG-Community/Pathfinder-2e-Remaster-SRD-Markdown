---
title: "Reclaim Destiny"
icon: ":luggage:"
aliases: "Reclaim Destiny"
foundryId: Item.QgsZW5xaMBcYDpBO
tags:
  - Item
---

# Reclaim Destiny `pf2:0`

**Frequency** once per day;

**Trigger** You are about to attempt a check and are affected by a fortune or misfortune effect that modifies the triggering check;

**Effect** You break the influence over your fortunes and claim a stable hold over your fate. You ignore the fortune or misfortune effect and can roll the triggering roll normally.


