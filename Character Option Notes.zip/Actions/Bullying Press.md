---
title: "Bullying Press"
icon: ":luggage:"
aliases: "Bullying Press"
foundryId: Item.Hlc3Gb3ntVKfsBPp
tags:
  - Item
---

# Bullying Press `pf2:r`

**Trigger** You attempt a melee Strike against your opponent, but haven't rolled yet.

**Requirements** You're in a duel, you're trained in Intimidation, and you rolled an Intimidation check for initiative this round.

* * *

If you hit, your opponent becomes [[Frightened 1]]. If your opponent is using Perception for initiative when this ability is used, they become [[Frightened 1|Frightened 2]] instead.


