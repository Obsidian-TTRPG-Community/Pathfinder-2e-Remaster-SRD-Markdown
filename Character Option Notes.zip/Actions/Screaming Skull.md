---
title: "Screaming Skull"
icon: ":luggage:"
aliases: "Screaming Skull"
foundryId: Item.CGIhQFrafVizkDof
tags:
  - Item
---

# Screaming Skull `pf2:2`

The skeleton removes its skull and throws it, making a jaws Strike with a range of 20 feet. Regardless of whether it hits, the target and all enemies within 10 feet must attempt a Will save or be [[Frightened 1]], or [[Frightened 1|Frightened 2]] on a critical failure. This uses a trained DC using the skeleton's Charisma modifier or an expert DC if the skeleton is specialized. At the start of the skeleton's next turn, the head bounces, rolls, or flies back to reattach. The skeleton is blind while its head is away.


