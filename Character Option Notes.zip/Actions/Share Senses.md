---
title: "Share Senses"
icon: ":luggage:"
aliases: "Share Senses"
foundryId: Item.MKtowX1sf8NTS3U3
tags:
  - Item
---

# Share Senses `pf2:1`

**Requirements** Your eidolon is manifested.

You project your senses into your eidolon, allowing you to perceive through it. When you do, you lose all sensory information from your own body, but can sense through your eidolon's body for up to 1 minute. You can [[Dismiss]] this effect.

* * *

**Special** This action has the trait matching your eidolon's tradition (arcane, divine, occult, or primal). Your eidolon can also use this ability. When it does, it projects its senses into your body.


