---
title: "Drain Life"
icon: ":luggage:"
aliases: "Drain Life"
foundryId: Item.nDSHGnSms3iJ89Qg
tags:
  - Item
---

# Drain Life `pf2:2`

Your eidolon attacks a living creature and drains some of the creature's life force to feed your shared link. Your eidolon Strikes a living enemy. If the Strike hits and deals damage, the target must attempt a Fortitude save, with the following effects. On a critical hit, the enemy uses the result one degree worse than it rolled.

**Critical Success** No effect.

**Success** Your eidolon drains a small amount of life force. The enemy takes additional void damage equal to half your level.

**Failure** Your eidolon drains enough life force to satisfy itself. The enemy takes additional void damage equal to half your level and is [[Drained 1]]. Your eidolon gains temporary Hit Points equal to the enemy's level, which last for 1 minute.

**Critical Failure** Your eidolon drains an incredible amount of life force and is thoroughly glutted with energy. As failure, but the enemy is [[Drained 1|Drained 2]] and the temporary Hit Points are equal to double the enemy's level.


