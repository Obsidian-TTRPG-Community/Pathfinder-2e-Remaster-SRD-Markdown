---
title: "Restore the Mind"
icon: ":luggage:"
aliases: "Restore the Mind"
foundryId: Item.T9uOTIOv8QQP9yqF
tags:
  - Item
---

# Restore the Mind `pf2:1`

Your unleashed psyche gives you closer connections to the emotions of your allies, letting you project reassurance and strength that replenishes their mind and body. Choose one of the two benefits to grant one ally within 30 feet that you can see. That ally is then temporarily immune for 10 minutes.

*   The ally gains a +1 status bonus to saving throws against mental effects until your psyche ends.
*   The ally regains Hit Points equal to 2 + double your level.


