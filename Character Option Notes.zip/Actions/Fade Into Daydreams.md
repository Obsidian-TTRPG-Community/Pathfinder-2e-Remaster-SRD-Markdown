---
title: "Fade Into Daydreams"
icon: ":luggage:"
aliases: "Fade Into Daydreams"
foundryId: Item.jpPDr78aAe0vk4Nr
tags:
  - Item
---

# Fade Into Daydreams `pf2:1`

Your flights of imagination spill into the real world, causing you to become indistinct, hazy, or cloaked in figments. You become [[Concealed]] until the start of your next turn. This concealment can't be used to Hide, as normal for concealing effects that leave your location obvious.


