---
title: "That's My Number"
icon: ":luggage:"
aliases: "That's My Number"
foundryId: Item.65mF0yXz6kAyfkKN
tags:
  - Item
---

# That's My Number `pf2:r`

**Trigger** You roll your lucky number as your d20 result on a non-secret attack roll, saving throw, or skill check

* * *

**Effect** You call upon the fortune stored within your lucky number and reroll the triggering check. However, pushing your luck has a price: if your result on the reroll is the same number again, you critically fail, regardless of what degree of success you ordinarily would have received.


