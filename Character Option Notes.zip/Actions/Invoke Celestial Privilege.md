---
title: "Invoke Celestial Privilege"
icon: ":luggage:"
aliases: "Invoke Celestial Privilege"
foundryId: Item.9Rr4ZcLpoi5aQyon
tags:
  - Item
---

# Invoke Celestial Privilege `pf2:r`

**Trigger** You attempt a saving throw against a divine effect, but you haven't rolled yet.

* * *

You rise above the triggering effect, refusing to be harmed by it. You gain a +1 circumstance bonus to the triggering saving throw and to any other saving throws you attempt against divine effects until the start of your next turn.


