---
title: "Raise a Shield"
icon: ":luggage:"
aliases: "Raise a Shield"
foundryId: Item.VJgxkKeAS8LXTPRt
tags:
  - Item
---

# Raise a Shield
![[systems-pf2e-icons-actions-raise-a-shield.webp|150 lp right]]

**Requirements** You are wielding a shield.

* * *

You position your shield to protect yourself. When you have Raised a Shield, you gain its listed circumstance bonus to AC. Your shield remains raised until the start of your next turn.


