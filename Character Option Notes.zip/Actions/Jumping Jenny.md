---
title: "Jumping Jenny"
icon: ":luggage:"
aliases: "Jumping Jenny"
foundryId: Item.GjxQSSyySzBo1KGA
tags:
  - Item
---

# Jumping Jenny `pf2:1`

**Cost** 2 batches of infused reagents

* * *

**Effect** Target a flying creature within 60 feet. Until the start of your next turn, each time that creature attempts to Fly, they must succeed at an Acrobatics check to Maneuver in Flight against the DC of your fireworks display, or the Fly action is disrupted. If all the creature's attempts to Fly are disrupted, at the end of its turn, it falls harmlessly to the ground below. A jumping jenny costs 2 batches of infused reagents, rather than 1.


