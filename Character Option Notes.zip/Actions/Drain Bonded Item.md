---
title: "Drain Bonded Item"
icon: ":luggage:"
aliases: "Drain Bonded Item"
foundryId: Item.B4kNDO0Qf7zL9VV8
tags:
  - Item
---

# Drain Bonded Item `pf2:0`

**Frequency** once per day

**Requirements** Your bonded item is on your person.

* * *

You expend the magical power stored in your bonded item. During the current turn, you can cast one spell you prepared today and already cast, without spending a spell slot. You must still Cast the Spell and meet the spell's other requirements.


