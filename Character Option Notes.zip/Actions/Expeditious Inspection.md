---
title: "Expeditious Inspection"
icon: ":luggage:"
aliases: "Expeditious Inspection"
foundryId: Item.StUyTUWNk43KHQZg
tags:
  - Item
---

# Expeditious Inspection `pf2:0`

**Frequency** once per 10 minutes

* * *

You observe and assess your surroundings with great speed. You [[Recall Knowledge]], [[Seek]], or [[Sense Motive]].


