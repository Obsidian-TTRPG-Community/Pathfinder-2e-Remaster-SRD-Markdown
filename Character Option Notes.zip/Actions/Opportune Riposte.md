---
title: "Opportune Riposte"
icon: ":luggage:"
aliases: "Opportune Riposte"
foundryId: Item.xMyOaZ6LXc5qpBHy
tags:
  - Item
---

# Opportune Riposte `pf2:r`

**Trigger** A foe within your reach critically fails a Strike against you

* * *

You take advantage of an opening from your enemy's fumbled attack. You either make a melee Strike against the triggering foe or attempt to [[Disarm]] it of the weapon it used for the Strike.


