---
title: "Spinning Crush"
icon: ":luggage:"
aliases: "Spinning Crush"
foundryId: Item.EuBuH7PAGso29zE1
tags:
  - Item
---

# Spinning Crush `pf2:3`

**Requirements** You're wielding a loaded firearm or loaded crossbow.

* * *

You go into a vicious spin, smashing your weapon into those nearby and increasing your momentum by firing. All creatures adjacent to you take 4d6 if it has a major striking rune. This ability does not apply other effects that increase damage with your firearm Strikes such as weapon specialization. Creatures affected by this attack must attempt a DC resolve reflex save. A creature that fails its save is also pushed 5 feet directly away from you.


