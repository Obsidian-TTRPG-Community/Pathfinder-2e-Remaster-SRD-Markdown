---
title: "Drifter's Wake"
icon: ":luggage:"
aliases: "Drifter's Wake"
foundryId: Item.bmqYtdqDYed4cXBt
tags:
  - Item
---

# Drifter's Wake `pf2:3`

You drift across the battlefield, striking down foes as you go. You Stride, and you can Strike up to three times at any points during your movement. Each attack must target a different enemy and must be made with a one-handed firearm, crossbow, melee weapon, or unarmed attack. Each attack counts toward your multiple attack penalty, but your multiple attack penalty doesn't increase until you've made all your attacks. Your movement doesn't trigger reactions.


