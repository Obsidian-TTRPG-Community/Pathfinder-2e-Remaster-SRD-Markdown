---
title: "Scout"
icon: ":luggage:"
aliases: "Scout"
foundryId: Item.TiLHL0kxEmm00cRl
tags:
  - Item
---

# Scout
![[systems-pf2e-icons-actions-Passive.webp|150 lp right]]

You scout ahead and behind the group to watch danger, moving at half speed. At the start of the next encounter, every creature in your party gains a +1 circumstance bonus to their initiative rolls.

[[Effect\_ Scouting|Effect: Scouting]]


