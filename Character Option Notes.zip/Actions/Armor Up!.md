---
title: "Armor Up!"
icon: ":luggage:"
aliases: "Armor Up!"
foundryId: Item.rUaTexkNre9cC3Nf
tags:
  - Item
---

# Armor Up! `pf2:1`

**Effect** You snap your fingers. The armor returns to your body.


