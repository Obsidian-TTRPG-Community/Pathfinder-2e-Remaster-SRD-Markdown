---
title: "Lucky Break"
icon: ":luggage:"
aliases: "Lucky Break"
foundryId: Item.OwyhaXaoLx8LRFGx
tags:
  - Item
---

# Lucky Break `pf2:0`

**Trigger** You attempt a skill check during Exploration or Downtime

**Frequency** once per day

* * *

**Effect** Draw a harrow card, then reroll the skill check. If you draw a card from the suit of Keys, add a +4 status bonus to the original roll and your reroll, then take the result you prefer as your actual result. If you drew any other card, you gain no bonus and must take the result of the rerolled skill check.


