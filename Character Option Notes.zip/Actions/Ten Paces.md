---
title: "Ten Paces"
icon: ":luggage:"
aliases: "Ten Paces"
foundryId: Item.8P8W2TqyDby0nDCT
tags:
  - Item
---

# Ten Paces `pf2:0`

**Trigger** You roll initiative.

* * *

You react to trouble with lightning speed, positioning yourself just right. You gain a +2 circumstance bonus to your initiative roll, and you can Interact to draw a one-handed firearm or one-handed crossbow. As your first action on your first turn, you can Step up to 10 feet as a free action.


