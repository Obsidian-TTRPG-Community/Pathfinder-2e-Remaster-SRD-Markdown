---
title: "Patron's Presence"
icon: ":luggage:"
aliases: "Patron's Presence"
foundryId: Item.77ENoZAi9SExZnKp
tags:
  - Item
---

# Patron's Presence `pf2:2`

**Frequency** once per hour

* * *

**Effect** A palpable weight extends from your familiar in a 15 foot emanation. Enemies who enter or start their turn within the aura must succeed at a Will save against your spell DC or become [[Stupefied 1|Stupefied 2]] as long as they remain within the aura, or [[Stupefied 1|Stupefied 3]] on a critical failure. The aura lasts until the end of your next turn, but the familiar can Sustain it up to 1 minute.


