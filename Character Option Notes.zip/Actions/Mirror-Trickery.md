---
title: "Mirror-Trickery"
icon: ":luggage:"
aliases: "Mirror-Trickery"
foundryId: Item.K9zot3P9KtE1O2ph
tags:
  - Item
---

# Mirror-Trickery `pf2:r`

**Frequency** once per day

**Trigger** You would be hit by a Strike

* * *

**Effect** You create an illusory duplicate at the last instant and attempt to trick your foe into striking it instead of you. The attacker attempts a DC 11 flat; on a failure, the attack hits the duplicate, changing the result from a critical success to a success or a success to a failure.


