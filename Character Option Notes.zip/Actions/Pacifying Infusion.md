---
title: "Pacifying Infusion"
icon: ":luggage:"
aliases: "Pacifying Infusion"
foundryId: Item.4TPAE05hL7aKqmYe
tags:
  - Item
---

# Pacifying Infusion `pf2:1`

If your next action is an impulse, it gains the nonlethal trait. If it has an area, you can exclude creatures you've designated with Safe Elements from its effects.


