---
title: "Harrow the Fiend"
icon: ":luggage:"
aliases: "Harrow the Fiend"
foundryId: Item.fl8JU5yJV0Ustle5
tags:
  - Item
---

# Harrow the Fiend `pf2:0`

**Trigger** You start your turn in combat against a foe or foes you recognize to be fiends

**Frequency** once per day

* * *

**Effect** You gain a +1 status bonus on all Strikes or spell attack rolls against fiends for the duration of combat. Once during combat, you can draw a harrow card after you determine if a Strike or spell attack on a fiend hits but before you determine damage or effects caused to the fiend. If you draw a card from the suit of Hammers, increase the degree of success of your Strike or spell attack by one.

[[Effect\_ Harrow the Fiend|Effect: Harrow the Fiend]]


