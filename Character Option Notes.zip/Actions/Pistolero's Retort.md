---
title: "Pistolero's Retort"
icon: ":luggage:"
aliases: "Pistolero's Retort"
foundryId: Item.ITXMRBkAHzjrFxvD
tags:
  - Item
---

# Pistolero's Retort `pf2:r`

**Requirements** You're wielding a one-handed firearm or one-handed crossbow.

**Trigger** A foe within the first range increment of the one-handed firearm or one-handed crossbow you're wielding critically fails an attack roll against you.

* * *

You punish your foe's failure with a shot. Make a Strike against the triggering foe with a one-handed firearm or one-handed crossbow.


