---
title: "Salt Wound"
icon: ":luggage:"
aliases: "Salt Wound"
foundryId: Item.Og9xlmLd6JwXIv88
tags:
  - Item
---

# Salt Wound `pf2:r`

**Frequency** once per day

**Trigger** A creature that has blood and is not at its maximum Hit Points hits you with a melee Strike

* * *

**Effect** You channel salt and brine from your blood into the creature's wounds. The creature must attempt a DC resolve fortitude using your class DC or spell DC, whichever is higher. On a failure, the creature takes 1d6 persistent,acid damage and is [[Sickened 1]] by the pain. On a critical failure, it instead takes 2d6 persistent,acid damage and is [[Sickened 1|Sickened 2]].


