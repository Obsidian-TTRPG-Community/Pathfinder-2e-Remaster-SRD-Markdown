---
title: "Cast a Spell"
icon: ":luggage:"
aliases: "Cast a Spell"
foundryId: Item.giVR7ZHwo9Dq5Q9P
tags:
  - Item
---

# Cast a Spell
![[systems-pf2e-icons-actions-Passive.webp|150 lp right]]

You cast a spell you have prepared or in your repertoire. Casting a Spell is a special activity that takes a variable number of actions depending on the spell, as listed in each spell's stat block. As soon as the spellcasting actions are complete, the spell effect occurs.

Some spells are cast as a reaction or free action. In those cases, you Cast the Spell as a reaction or free action (as appropriate) instead of as an activity. Such cases will be noted in the spell's stat block-for example, "\[reaction\] verbal."

**Long Casting** Times Some spells take minutes or hours to cast. The Cast a Spell activity for these spells includes a mix of the listed spell components, but it's not necessary to break down which one you're providing at a given time. You can't use other actions or reactions while casting such a spell, though at the GM's discretion, you might be able to speak a few sentences. As with other activities that take a long time, these spells have the exploration trait, and you can't cast them in an encounter. If combat breaks out while you're casting one, your spell is disrupted.

**Spell Components** Each spell lists the spell components required to cast it after the action icons or text, such as "\[three-actions\] material, somatic, verbal." The spell components, described in detail below, add traits and requirements to the Cast a Spell activity. If you can't provide the components, you fail to Cast the Spell.

*   Material (manipulate)
*   Somatic (manipulate)
*   Verbal (concentrate)
*   Focus (manipulate)

**Disrupted and Lost Spells** Some abilities and spells can disrupt a spell, causing it to have no effect and be lost. When you lose a spell, you've already expended the spell slot, spent the spell's costs and actions, and used the Cast a Spell activity. If a spell is disrupted during a [[Sustain|Sustain a Spell]] action, the spell immediately ends.


