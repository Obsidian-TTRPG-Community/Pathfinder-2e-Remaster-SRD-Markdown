---
title: "Clue In"
icon: ":luggage:"
aliases: "Clue In"
foundryId: Item.GzVLApgjkxv4skRj
tags:
  - Item
---

# Clue In `pf2:r`

**Frequency** once per 10 minutes

**Trigger** Another creature attempts a check to investigate a lead you're pursuing

* * *

You share information with the triggering creature.

They gain a circumstance bonus to their check equal to your circumstance bonus to checks investigating your subject from [[Pursue a Lead]]. The GM can add any relevant traits to this reaction depending on the situation, such as auditory and linguistic if you're conveying information verbally.

[[Effect\_ Clue In|Effect: Clue In]]


