---
title: "Spring the Trap"
icon: ":luggage:"
aliases: "Spring the Trap"
foundryId: Item.uze7zREofOcfJIIy
tags:
  - Item
---

# Spring the Trap `pf2:0`

**Trigger** You roll initiative.

* * *

You can Interact to draw a combination weapon and set it to melee or ranged mode. On your first turn, your movement and ranged attacks don't trigger reactions that are normally triggered by movement or a ranged attack (such as Attack of Opportunity).


