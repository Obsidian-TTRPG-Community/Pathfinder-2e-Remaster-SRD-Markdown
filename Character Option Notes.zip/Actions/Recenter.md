---
title: "Recenter"
icon: ":luggage:"
aliases: "Recenter"
foundryId: Item.exFVaGpzhx5ETIyU
tags:
  - Item
---

# Recenter `pf2:1`

**Requirements** You're in a psychic duel and are trained in the skill matching the psychic center you are changing to.

* * *

You adopt the psychic center matching the emotion of your choice. If you were already psychically centered, you lose your old psychic center when you adopt the new one.


