---
title: "Conduct Energy"
icon: ":luggage:"
aliases: "Conduct Energy"
foundryId: Item.FO6jurx4C7ydry6T
tags:
  - Item
---

# Conduct Energy `pf2:0`

**Requirements** Your last action or spell this turn had the acid, cold, electricity, fire, or sonic trait.

* * *

You channel energy into your weapon. The weapon deals 1 additional damage per weapon damage die until the start of your next turn. This damage type matches the trait of the triggering action or spell. If your triggering action or spell had multiple eligible traits, you select one of those traits.

[[Effect\_ Conduct Energy|Effect: Conduct Energy]]


