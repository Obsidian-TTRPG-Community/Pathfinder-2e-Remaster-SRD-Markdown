---
title: "One Shot, One Kill"
icon: ":luggage:"
aliases: "One Shot, One Kill"
foundryId: Item.8YBdu3KWC2PjN0TD
tags:
  - Item
---

# One Shot, One Kill `pf2:0`

**Trigger** You roll Stealth for initiative.

* * *

Your first shot is the deadliest. Interact to draw a firearm or crossbow. On your first turn, your first Strike with that weapon deals an additional 1d6 precision damage. This precision damage increases to 2d6 at 9th level and 3d6 at 15th level.


