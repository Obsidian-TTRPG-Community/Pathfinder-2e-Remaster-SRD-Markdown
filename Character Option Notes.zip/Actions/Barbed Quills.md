---
title: "Barbed Quills"
icon: ":luggage:"
aliases: "Barbed Quills"
foundryId: Item.z07sdZOZ0M5shalT
tags:
  - Item
---

# Barbed Quills `pf2:r`

**Frequency** once per day

**Trigger** You are hit with an unarmed strike or a strike with a non-reach melee weapon.

* * *

You break off quills in your attacker's flesh. You deal 1d8 piercing damage to the triggering creature (DC resolve reflex save using your class DC or spell DC, whichever is higher.) On a critical failure, the creature also takes 1d4 bleed as your quills hook into its flesh. At 3rd level, and every 2 levels thereafter, this damage increases by 1d8 and the persistent piercing damage increases by 1.


