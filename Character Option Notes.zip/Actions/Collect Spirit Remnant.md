---
title: "Collect Spirit Remnant"
icon: ":luggage:"
aliases: "Collect Spirit Remnant"
foundryId: Item.iMKHK0hR7N3b9uVZ
tags:
  - Item
---

# Collect Spirit Remnant `pf2:3`

**Requirements** You're holding your spirit dwelling

* * *

**Effect** You brandish your spirit dwelling at the location where a haunt, ghost, or other incorporeal undead was destroyed within the last minute and pray or recite ritual incantations. You coax the spirit remnant into your spirit dwelling.


