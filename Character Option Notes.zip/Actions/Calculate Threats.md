---
title: "Calculate Threats"
icon: ":luggage:"
aliases: "Calculate Threats"
foundryId: Item.fgRxngGqp3xkhHKV
tags:
  - Item
---

# Calculate Threats `pf2:1`

Your subconscious automatically calculates vectors and forces when your mind is unleashed, showing you the likely path of incoming attacks to avoid. You gain a +2 circumstance bonus to AC and Reflex saves until the beginning of your next turn.

[[Effect\_ Calculate Threats|Effect: Calculate Threats]]


