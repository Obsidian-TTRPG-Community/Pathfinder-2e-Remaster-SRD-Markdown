---
title: "Stellar Misfortune"
icon: ":luggage:"
aliases: "Stellar Misfortune"
foundryId: Item.FNgpIHJl0z2Qk2I6
tags:
  - Item
---

# Stellar Misfortune `pf2:0`

**Frequency** once per day;

**Trigger** A creature you can see is about to attempt a saving throw, attack roll, or skill check;

**Requirements** You must be under the night sky with the stars visible;

**Effect** You call upon the power of a dooming star, exacerbating the target's bad luck. The target must roll the triggering check twice and take the worse result.


