---
title: "Slayer's Identification"
icon: ":luggage:"
aliases: "Slayer's Identification"
foundryId: Item.1yyObFQmnKVHbdj2
tags:
  - Item
---

# Slayer's Identification `pf2:0`

**Trigger** You roll initiative and can observe a creature you know is undead

* * *

You attempt to Recall Knowledge to identify the undead creature with a +1 circumstance bonus. If you're a master in the skill you're using to Recall Knowledge, you gain a +2 circumstance bonus instead.


