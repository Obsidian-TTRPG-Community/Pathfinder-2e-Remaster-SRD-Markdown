---
title: "Breath Weapon (Acid) (Line)"
icon: ":luggage:"
aliases: "Breath Weapon (Acid) (Line)"
foundryId: Item.Sd1O3Rg4whl6NB88
tags:
  - Item
---

# Breath Weapon (Acid) (Line) `pf2:2`

Your eidolon exhales a blast of destructive energy. Your eidolon deals 1d6 acid damage to all creatures in a 60 foot line, with a basic Reflex save against your spell DC.

Your eidolon then can't use their Breath Weapon again for the next 1d4 rounds.

At 3rd level and every 2 levels thereafter, the damage increases by 1d6. 


