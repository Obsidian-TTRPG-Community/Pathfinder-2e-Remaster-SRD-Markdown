---
title: "Affix a Fulu"
icon: ":luggage:"
aliases: "Affix a Fulu"
foundryId: Item.JfQYOjIA9yQPIPAZ
tags:
  - Item
---

# Affix a Fulu `pf2:1`

You affix a fulu to an armor, weapon, shield, creature, or structure that's beside or in the same square as you. A creature can remove a fulu from itself or an unattended object in its reach with a single action.


