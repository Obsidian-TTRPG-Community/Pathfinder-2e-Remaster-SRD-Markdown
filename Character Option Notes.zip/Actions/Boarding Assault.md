---
title: "Boarding Assault"
icon: ":luggage:"
aliases: "Boarding Assault"
foundryId: Item.pFkj76vE0OsOiKBV
tags:
  - Item
---

# Boarding Assault `pf2:2`

Either Stride twice or attempt an Acrobatics check (DC determined by the GM, but usually DC 20) to swing on a rope up to twice your Speed.

If you boarded or disembarked from a boat or similar vehicle during this movement, you can make a melee Strike that deals one additional weapon damage die.


