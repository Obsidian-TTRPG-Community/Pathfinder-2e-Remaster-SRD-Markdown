---
title: "Cover Tracks"
icon: ":luggage:"
aliases: "Cover Tracks"
foundryId: Item.29sPvfY09C6TC4V3
tags:
  - Item
---

# Cover Tracks
![[systems-pf2e-icons-actions-Passive.webp|150 lp right]]

You cover your tracks, moving up to half your travel speed. You don't need to attempt a Survival check to cover your tracks, but anyone tracking you must succeed at a Survival check against your Survival DC if it is higher than the normal DC to [[Track]].

In some cases, you might Cover Tracks in an encounter. In this case, Cover Tracks is a single action and doesn't have the exploration trait.


