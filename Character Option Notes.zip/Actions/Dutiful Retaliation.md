---
title: "Dutiful Retaliation"
icon: ":luggage:"
aliases: "Dutiful Retaliation"
foundryId: Item.ceGClZQk3fEgKQaI
tags:
  - Item
---

# Dutiful Retaliation `pf2:r`

**Trigger** An enemy within 15 feet of you hits you with a Strike and deals damage to you.

**Requirements** Your eidolon is within 15 feet of you.

Your eidolon instinctively flashes with ectoplasmic energy, allowing them to strike back against an enemy who dares to harm you. Your eidolon makes a melee unarmed Strike against the triggering enemy, even if that enemy isn't within your eidolon's reach.


