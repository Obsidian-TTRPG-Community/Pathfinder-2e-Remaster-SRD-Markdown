---
title: "Ghost Shot"
icon: ":luggage:"
aliases: "Ghost Shot"
foundryId: Item.2AtrTns6oajepHH7
tags:
  - Item
---

# Ghost Shot `pf2:1`

Make a firearm or crossbow Strike. If you're [[Hidden]] from or undetected by the target, the Strike adds the additional precision damage from One Shot, One Kill; if you would already receive that additional damage on the Strike, the effects aren't cumulative. If you were undetected or unnoticed by any creatures, you're now hidden from them instead, as the origin of the attack is clear.


