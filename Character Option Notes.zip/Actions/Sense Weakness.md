---
title: "Sense Weakness"
icon: ":luggage:"
aliases: "Sense Weakness"
foundryId: Item.2k8HHbdApD0OlYwh
tags:
  - Item
---

# Sense Weakness `pf2:r`

**Trigger** You attempt a melee Strike against your opponent, but haven't rolled yet.

**Requirements** You're in a duel, you're trained in Perception, and you rolled a Perception check for initiative this round.

* * *

You pick a precise moment to attack, giving you an edge. Your opponent is [[Off-Guard]] against the attack. If your opponent is using Deception for initiative when this ability is used, they are instead off-guard until the start of their next turn.


