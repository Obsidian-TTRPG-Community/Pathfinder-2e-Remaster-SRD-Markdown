---
title: "Toxic Touch"
icon: ":luggage:"
aliases: "Toxic Touch"
foundryId: Item.dpWtxbaOSMOnyZ7y
tags:
  - Item
---

# Toxic Touch `pf2:1`

**Frequency** once per day

**Requirements** Your most recent action was to [[Tumble Through]], and you successfully moved through an enemy's space

* * *

**Effect** Make a melee unarmed Strike against the enemy whose space you moved through. On a hit, the target takes 1d6 persistent,poison damage and is [[Sickened 1]] (or takes 2d6 persistent,poison and is [[Sickened 1|Sickened 2]] on a critical hit).


