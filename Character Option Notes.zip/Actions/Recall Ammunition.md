---
title: "Recall Ammunition"
icon: ":luggage:"
aliases: "Recall Ammunition"
foundryId: Item.AdtATgmHXDsaGEzn
tags:
  - Item
---

# Recall Ammunition `pf2:r`

**Trigger** You miss with a firearm or crossbow Strike while using an ordinary level-0 bolt or bullet

* * *

You amplify the connection between bullet and firearm, calling your missed shot back into your gun. The ammunition you just fired is reloaded back into your gun and immediately ready to fire again.


