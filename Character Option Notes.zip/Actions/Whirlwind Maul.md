---
title: "Whirlwind Maul"
icon: ":luggage:"
aliases: "Whirlwind Maul"
foundryId: Item.BuFaraZkRGJWJnC1
tags:
  - Item
---

# Whirlwind Maul `pf2:2`

Your eidolon lashes out in all directions. It makes a melee unarmed Strike against up to four enemies within reach. It can choose different unarmed attacks for each enemy. Each attack counts toward your multiple attack penalty, but you don't increase your penalty until the eidolon has made all its attacks.


