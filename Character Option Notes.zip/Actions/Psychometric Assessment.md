---
title: "Psychometric Assessment"
icon: ":luggage:"
aliases: "Psychometric Assessment"
foundryId: Item.WASLuErOeH7TnJU0
tags:
  - Item
---

# Psychometric Assessment
![[systems-pf2e-icons-actions-Passive.webp|150 lp right]]

**Requirements** Your bare hands are touching an object in which you detected psychometric resonance

* * *

**Effect** You spend 1 minute concentrating on the object to get a vision of the face of the person who imbued the item with such emotion in the first place. If the associated emotion is painfully negative, you might take 1d6 mental damage, as determined by the GM.


