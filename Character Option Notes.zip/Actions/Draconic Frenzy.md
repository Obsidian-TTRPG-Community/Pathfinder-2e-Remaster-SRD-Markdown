---
title: "Draconic Frenzy"
icon: ":luggage:"
aliases: "Draconic Frenzy"
foundryId: Item.yo06Pem9rvUnka68
tags:
  - Item
---

# Draconic Frenzy `pf2:2`

Your eidolon makes one Strike with their primary unarmed attack and two Strikes with their secondary unarmed attack (in any order). If any of these attacks critically hits an enemy, your eidolon instantly recovers the use of their Breath Weapon.


