---
title: "Energy Emanation (Fire)"
icon: ":luggage:"
aliases: "Energy Emanation (Fire)"
foundryId: Item.Ol4bMlI9RYEozQwa
tags:
  - Item
---

# Energy Emanation (Fire) `pf2:2`

**Frequency** once per day

* * *

Energy bursts forth from your body. You deal 1d6 fire damage to all adjacent creatures (DC resolve reflex save using your class DC or spell DC, whichever is higher). At 3rd level, and every 2 levels thereafter, this damage increases by 1d6 damage.



