---
title: "Threatening Approach"
icon: ":luggage:"
aliases: "Threatening Approach"
foundryId: Item.ofAhckayZAnJrQB6
tags:
  - Item
---

# Threatening Approach `pf2:2`

You Stride to be adjacent to a foe and [[Demoralize]] that foe. If you succeed, the foe is [[Frightened 1|Frightened 2]] instead of frightened 1.


