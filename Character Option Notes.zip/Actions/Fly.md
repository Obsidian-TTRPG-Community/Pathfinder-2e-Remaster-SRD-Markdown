---
title: "Fly"
icon: ":luggage:"
aliases: "Fly"
foundryId: Item.0bbQp0Ntrgc8ySsD
tags:
  - Item
---

# Fly `pf2:1`

**Requirements** You have a fly Speed.

* * *

You move through the air up to your fly Speed. Moving upward (straight up or diagonally) uses the rules for moving through difficult terrain. You can move straight down 10 feet for every 5 feet of movement you spend. If you Fly to the ground, you don't take falling damage. You can use an action to Fly 0 feet to hover in place. If you're airborne at the end of your turn and didn't use a Fly action this round, you fall.


