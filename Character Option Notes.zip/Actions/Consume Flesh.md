---
title: "Consume Flesh"
icon: ":luggage:"
aliases: "Consume Flesh"
foundryId: Item.Z2p6rA1kf0A4edFn
tags:
  - Item
---

# Consume Flesh `pf2:1`

**Requirements** You are adjacent to the corpse of a Small or larger creature that died in the last hour

* * *

You devour a chunk of the corpse. You become satiated for 1 hour.


