---
title: "Fortify Camp"
icon: ":luggage:"
aliases: "Fortify Camp"
foundryId: Item.QMpJELPDPygSgXnH
tags:
  - Item
---

# Fortify Camp
![[systems-pf2e-icons-actions-Passive.webp|150 lp right]]

You can spend time fortifying your camp for defense with a successful Crafting check (typically at a trained or expert DC). Anyone keeping watch or defending the camp gains a +2 circumstance bonus to initiative rolls and Perception checks to Seek creatures attempting to sneak up on the camp.


