---
title: "Confident Finisher"
icon: ":luggage:"
aliases: "Confident Finisher"
foundryId: Item.5C9RNhVU3YPHoORJ
tags:
  - Item
---

# Confident Finisher `pf2:1`

You make an incredibly graceful attack, piercing your foe's defenses. Make a Strike with a weapon or unarmed attack that would apply your precise strike damage, with the following failure effect.

* * *

**Failure** You deal half your [[Precise Strike]] damage to the target. This damage type is that of the weapon or unarmed attack you used for the Strike.


