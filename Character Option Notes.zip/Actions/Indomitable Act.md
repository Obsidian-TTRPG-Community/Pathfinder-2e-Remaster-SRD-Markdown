---
title: "Indomitable Act"
icon: ":luggage:"
aliases: "Indomitable Act"
foundryId: Item.V9pThdqe95v9Sszl
tags:
  - Item
---

# Indomitable Act `pf2:r`

**Frequency** once per day

**Trigger** You are about to attempt a check

**Requirements** You are [[Frightened 1|Frightened]]

* * *

**Effect** You lean into your fear, using it to embolden you. You can roll the triggering check twice and take the higher result. This is a fortune effect.


