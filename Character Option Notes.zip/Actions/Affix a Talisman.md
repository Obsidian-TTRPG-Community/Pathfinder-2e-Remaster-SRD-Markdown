---
title: "Affix a Talisman"
icon: ":luggage:"
aliases: "Affix a Talisman"
foundryId: Item.zlcPJ8cqSptqG8fO
tags:
  - Item
---

# Affix a Talisman
![[systems-pf2e-icons-actions-Passive.webp|150 lp right]]

**Requirements** You must use a [[Repair Toolkit]]

* * *

You spend 10 minutes affixing a talisman to an item, placing the item on a stable surface and using the repair kit with both hands. You can also use this activity to remove a talisman. If more than one talisman is affixed to an item, the talismans are suppressed; none of them can be activated.


