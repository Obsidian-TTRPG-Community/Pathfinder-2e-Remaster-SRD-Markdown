---
title: "Defend"
icon: ":luggage:"
aliases: "Defend"
foundryId: Item.eD616pGMiIKcy3VI
tags:
  - Item
---

# Defend
![[systems-pf2e-icons-actions-Passive.webp|150 lp right]]

You move at half your travel speed with your shield raised. If combat breaks out, you gain the benefits of [[Raise a Shield|Raising a Shield]] before your first turn begins.


