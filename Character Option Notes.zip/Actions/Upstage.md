---
title: "Upstage"
icon: ":luggage:"
aliases: "Upstage"
foundryId: Item.9mZRzuqTNym6tyWa
tags:
  - Item
---

# Upstage `pf2:r`

**Trigger** A foe attempts a skill check and doesn't get a critical success

* * *

After your foe has tried their best, you show everyone how it's really done. Attempt a check using the same skill that triggered this reaction.

* * *

**Critical Success** You gain a +1 status bonus to attack rolls, Perception checks, saving throws, and skill checks until the end of your next turn.

**Success** As critical success, except you gain the benefits only if the triggering creature failed their skill check.


