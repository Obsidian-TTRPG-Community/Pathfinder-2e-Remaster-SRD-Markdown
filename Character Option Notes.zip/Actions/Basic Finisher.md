---
title: "Basic Finisher"
icon: ":luggage:"
aliases: "Basic Finisher"
foundryId: Item.yR9CJDNmd7WVCSBC
tags:
  - Item
---

# Basic Finisher `pf2:1`

You make a graceful, deadly attack. Make a Strike; if you hit and your weapon qualifies for [[Precise Strike]], you deal the full 1d6 damage from precise strike.


