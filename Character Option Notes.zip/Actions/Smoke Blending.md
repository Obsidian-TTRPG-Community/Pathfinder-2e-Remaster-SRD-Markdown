---
title: "Smoke Blending"
icon: ":luggage:"
aliases: "Smoke Blending"
foundryId: Item.slqE7hagnVu3fLgr
tags:
  - Item
---

# Smoke Blending `pf2:r`

**Trigger** A creature attempts a flat check to target you because you're [[Concealed]] or [[Hidden]] due to fog, haze, mist, or smoke

* * *

**Effect** You shroud yourself in smoke, making it harder for your foe to hit you. If you're concealed, the DC of the flat check increases from 5 to DC 7 flat.


