---
title: "Selfish Shield"
icon: ":luggage:"
aliases: "Selfish Shield"
foundryId: Item.0I2iw9pbHLqAJawa
tags:
  - Item
---

# Selfish Shield `pf2:r`

**Trigger** An enemy within 15 feet damages you

* * *

Your self-interest keeps you safe. You gain resistance against the triggering damage equal to 2 + half your level, regardless of damage type.

In addition, your Strikes against the triggering creature deal 1 extra damage until the end of your next turn. You choose whether this extra damage is spirit or void each time you use this reaction. This extra damage increases to 2 at 9th level and 3 at 16th level.


