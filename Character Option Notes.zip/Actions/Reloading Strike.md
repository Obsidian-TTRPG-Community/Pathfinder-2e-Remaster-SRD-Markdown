---
title: "Reloading Strike"
icon: ":luggage:"
aliases: "Reloading Strike"
foundryId: Item.BEKArmif9kmcou7W
tags:
  - Item
---

# Reloading Strike `pf2:1`

**Requirements** You're wielding a firearm or crossbow in one hand, and your other hand either wields a one-handed melee weapon or is empty.

* * *

You make a melee attack and then reload your gun in one fluid movement. Strike an opponent within reach with your one-handed melee weapon (or, if your other hand is empty, with an unarmed attack), and then Interact to reload. You don't need a free hand to reload in this way.


