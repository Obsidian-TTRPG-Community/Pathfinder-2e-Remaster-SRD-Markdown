---
title: "Board"
icon: ":luggage:"
aliases: "Board"
foundryId: Item.FPDNZusXMtilwCkT
tags:
  - Item
---

# Board `pf2:1`

**Requirements** You are adjacent to a point of entry on the vehicle you are attempting to board.

You board a vehicle through an open top, a door, a portal, or a hatch; if you're already on board, you can instead use this action to disembark into an empty space adjacent to the vehicle's point of entry. Using this action while the vehicle is in motion is challenging, requiring a successful Acrobatics or Athletics check with a DC equal to the vehicle's AC.


