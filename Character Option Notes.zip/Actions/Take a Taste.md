---
title: "Take a Taste"
icon: ":luggage:"
aliases: "Take a Taste"
foundryId: Item.ytQty31bLXRc40kp
tags:
  - Item
---

# Take a Taste `pf2:1`

**Requirements** The zombie has a creature [[Grabbed]] or [[Restrained]].

* * *

The zombie tries to grasp and bite a creature. The zombie makes a jaws Strike against the creature. This Strike uses the same statistics as its normal melee Strike, except its damage die is 1d10 and it deals piercing damage.


