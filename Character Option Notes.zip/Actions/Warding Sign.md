---
title: "Warding Sign"
icon: ":luggage:"
aliases: "Warding Sign"
foundryId: Item.dZBLLUxTTLeQ77qL
tags:
  - Item
---

# Warding Sign `pf2:r`

**Frequency** once per minute

**Trigger** You attempt a saving throw against a magical effect, but you haven't rolled yet

* * *

**Effect** You call on the power of a personal, eldritch sign of protection, which flares brightly before slowly fading. You gain a +2 circumstance bonus to the triggering saving throw, or a +3 circumstance bonus if the effect is a curse.


