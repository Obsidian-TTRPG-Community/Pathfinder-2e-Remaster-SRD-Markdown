---
title: "Interact"
icon: ":luggage:"
aliases: "Interact"
foundryId: Item.GmckuRSI8YQdzv87
tags:
  - Item
---

# Interact `pf2:1`

You use your hand or hands to manipulate an object or the terrain. You can grab an unattended or stored object, draw a weapon, swap a held item for another, open a door, or achieve a similar effect. On rare occasions, you might have to attempt a skill check to determine if your Interact action was successful.


