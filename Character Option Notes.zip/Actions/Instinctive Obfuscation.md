---
title: "Instinctive Obfuscation"
icon: ":luggage:"
aliases: "Instinctive Obfuscation"
foundryId: Item.rUCxVncPNeJfiVOx
tags:
  - Item
---

# Instinctive Obfuscation `pf2:r`

**Prerequisites** At least one arcane or occult innate spell gained from a gnome heritage or gnome ancestry feat

**Frequency** Once per day

**Trigger** You are attacked by a foe

* * *

The magic within you manifests as a natural reaction to threats. You gain the effects of _[[Mirror Image]]_ but with two images instead of three. The tradition of this action matches the tradition of your gnome ancestry options.


