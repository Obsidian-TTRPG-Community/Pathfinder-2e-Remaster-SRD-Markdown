---
title: "Change Shape (Kitsune)"
icon: ":luggage:"
aliases: "Change Shape (Kitsune)"
foundryId: Item.TKL5rKC8AF5noHSR
tags:
  - Item
---

# Change Shape (Kitsune)
![[systems-pf2e-icons-spells-fey-disapperance.webp|150 lp right]]

As a kitsune, you gain the [[Change Shape (Kitsune)]] ability.


