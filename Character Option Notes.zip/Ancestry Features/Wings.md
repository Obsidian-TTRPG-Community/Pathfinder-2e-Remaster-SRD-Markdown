---
title: "Wings"
icon: ":luggage:"
aliases: "Wings"
foundryId: Item.eplKVTlZsX7Q6a15
tags:
  - Item
---

# Wings
![[systems-pf2e-icons-spells-unfettered-pack.webp|150 lp right]]

All strix possess powerful wings. While not all strix focus on honing their flying skills, a strong flap of their wings allows strix to travel longer distances when jumping.

When Leaping horizontally, you move an additional 5 feet. You don't automatically fail your checks to High Jump or Long Jump if you don't Stride at least 10 feet first. In addition, when you make a Long Jump, you can jump a distance up to 10 feet further than your Athletics check result, though still with the normal maximum of your Speed.


