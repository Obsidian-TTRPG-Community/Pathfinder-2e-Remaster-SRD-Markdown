---
title: "Automaton Core"
icon: ":luggage:"
aliases: "Automaton Core"
foundryId: Item.bgcBvWLRUNQ2hcmg
tags:
  - Item
---

# Automaton Core
![[icons-commodities-tech-cog-brass.webp|150 lp right]]

Your body contains an automaton core infused with planar quintessence that grants you power to perform various tasks and houses your soul and life energy. This life energy flows through you much like the blood of humanoids. As a result, you are a living creature. You don't have the typical construct immunities, can be affected by effects that target a living creature, and can recover Hit Points normally via vitality energy. Additionally, you are not destroyed when reduced to 0 Hit Points. Instead, your life energy attempts to keep you active even in dire straits; you are knocked out and begin dying when reduced to 0 Hit Points.


