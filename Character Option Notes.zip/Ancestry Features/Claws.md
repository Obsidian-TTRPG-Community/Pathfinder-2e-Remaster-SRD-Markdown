---
title: "Claws"
icon: ":luggage:"
aliases: "Claws"
foundryId: Item.ZSbooha5mMjQneie
tags:
  - Item
---

# Claws
![[systems-pf2e-icons-features-ancestry-claws.webp|150 lp right]]

Your sharp claws offer an alternative to the fists other humanoids bring to a fight. You have a claw unarmed attack that deals 1d4 slashing damage and has the agile and finesse traits.


