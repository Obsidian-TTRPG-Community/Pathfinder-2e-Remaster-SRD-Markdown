---
title: "Revulsion"
icon: ":luggage:"
aliases: "Revulsion"
foundryId: Item.S6aurDy3piwHQ4K5
tags:
  - Item
---

# Revulsion
![[systems-pf2e-icons-spells-hideous-laughter.webp|150 lp right]]

You can't voluntarily come within 10 feet of brandished garlic or a religious symbol of a non-evil deity. A creature must Interact to brandish garlic or a religious symbol for 1 round (similar to Raising a Shield). If you involuntarily come within 10 feet of an object of your revulsion, you gain the [[Fleeing]] condition, running from the subject of your revulsion until you end an action beyond 10 feet of it. After 1 round of being exposed to the subject of your revulsion, you can attempt a DC 25 will save as a single action, which has the concentrate trait. On a success, you overcome your revulsions for 1d6 rounds, or 1 hour on a critical success.


