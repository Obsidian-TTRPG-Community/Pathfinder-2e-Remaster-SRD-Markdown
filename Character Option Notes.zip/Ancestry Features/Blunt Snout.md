---
title: "Blunt Snout"
icon: ":luggage:"
aliases: "Blunt Snout"
foundryId: Item.LoQgpibRIN6qVj0f
tags:
  - Item
---

# Blunt Snout
![[systems-pf2e-icons-features-ancestry-fishseeker-shoony.webp|150 lp right]]

Your small, blunt snout and labyrinthine sinus system make you resistant to phenomena that assail the nose. When you roll a saving throw against inhaled threats (such as inhaled poisons) and olfactory effects (such as xulgath stench), you get the outcome one degree of success better than the result of your roll.


