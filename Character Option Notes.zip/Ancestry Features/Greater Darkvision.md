---
title: "Greater Darkvision"
icon: ":luggage:"
aliases: "Greater Darkvision"
foundryId: Item.cCqovO2ibyrr9o6k
tags:
  - Item
---

# Greater Darkvision
![[systems-pf2e-icons-features-classes-vigilant-senses.webp|150 lp right]]

You can see in darkness and dim light just as well as you can see in bright light, though your vision in darkness is in black and white. Some forms of magical darkness, such as a 4th-level _[[Darkness]]_ spell, block normal [[Darkvision]]. You, however, can see through even these forms of magical darkness.


