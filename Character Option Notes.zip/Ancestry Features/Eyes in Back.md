---
title: "Eyes in Back"
icon: ":luggage:"
aliases: "Eyes in Back"
foundryId: Item.Ipk8ZIhLXfbyvB2r
tags:
  - Item
---

# Eyes in Back
![[systems-pf2e-icons-spells-prying-eye.webp|150 lp right]]

You have eyes that point in several different directions and instinctively notice movement in the peripheries of your vision. When you use the Seek basic action, you can look for creatures in two areas instead of one. If precision is necessary, you can select two 30 foot cones or 15 foot bursts within line of sight instead of one.


