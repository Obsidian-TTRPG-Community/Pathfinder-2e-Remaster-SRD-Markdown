---
title: "Sunlight"
icon: ":luggage:"
aliases: "Sunlight"
foundryId: Item.VoGYlMBdG0Cuq9jo
tags:
  - Item
---

# Sunlight
![[systems-pf2e-icons-spells-bless.webp|150 lp right]]

If exposed to direct sunlight, you immediately become [[Slowed 1]]. The slowed value increases by 1 each time you end your turn in sunlight. If you lose all your actions in this way, you are destroyed. Due to your supernatural aversion to light, you don't cast shadows or show a reflection in mirrors.


