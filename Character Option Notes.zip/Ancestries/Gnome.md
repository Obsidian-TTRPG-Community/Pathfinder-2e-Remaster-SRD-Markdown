---
title: "Gnome"
icon: ":luggage:"
aliases: "Gnome"
foundryId: Item.sSwjg9VVmG2l3kkF
tags:
  - Item
---

# Gnome
![[systems-pf2e-icons-default-icons-alternatives-ancestries-gnome.svg|150]]

_Long ago, early gnome ancestors emigrated from the First World, realm of the fey. While it's unclear why the first gnomes wandered to Golarion, this lineage manifests in modern gnomes as bizarre reasoning, eccentricity, obsessive tendencies, and what some see as naivete. These qualities are further reflected in their physical characteristics, such as spindly limbs, brightly colored hair, and childlike and extremely expressive facial features that further reflect their otherworldly origins._

_[[Gnome]]_


