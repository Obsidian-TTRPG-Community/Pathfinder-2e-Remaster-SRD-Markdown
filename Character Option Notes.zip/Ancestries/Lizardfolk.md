---
title: "Lizardfolk"
icon: ":luggage:"
aliases: "Lizardfolk"
foundryId: Item.VDK4uaDhexTrtOHy
tags:
  - Item
---

# Lizardfolk
![[systems-pf2e-icons-default-icons-alternatives-ancestries-lizardfolk.svg|150]]

_Lizardfolk are consummate survivors, heirs to empires considered ancient even by the elves._

_[[Lizardfolk]]_


