---
title: "Skeleton"
icon: ":luggage:"
aliases: "Skeleton"
foundryId: Item.7evfBQM2rzIEI83u
tags:
  - Item
---

# Skeleton
![[systems-pf2e-icons-default-icons-alternatives-ancestries-skeleton.svg|150]]

_Skeletons are considered among the lowest types of undead. They're typically mindless creatures, lacking many of the abilities that make other undead a serious threat. However, the animated bones of dragons, giants, and other great beasts make for dangerous foes. Powerful living creatures can retain some of their might and intellect upon returning as a skeleton. Some necromancers turn their strongest enemies into skeletal undead servants, assuming they can keep control of them._

_[[Skeleton]]_


