---
title: "Poppet"
icon: ":luggage:"
aliases: "Poppet"
foundryId: Item.Zqf1SBKiXRowHyT8
tags:
  - Item
---

# Poppet
![[systems-pf2e-icons-default-icons-alternatives-ancestries-poppet.svg|150]]

_Poppets are small, basic constructs that typically help their owners with simple tasks. Occasionally, poppets gain sapience, independence, and a spark of life. Elevated beyond mere helpers or playthings, these poppets are free to chart their own destinies._

_[[Poppet]]_


