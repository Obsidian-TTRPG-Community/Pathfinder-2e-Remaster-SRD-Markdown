---
title: "Tengu"
icon: ":luggage:"
aliases: "Tengu"
foundryId: Item.P5Cv7uAOcPIXRfZH
tags:
  - Item
---

# Tengu
![[systems-pf2e-icons-default-icons-alternatives-ancestries-tengu.svg|150]]

_Tengus are a gregarious and resourceful people that have spread far and wide from their ancestral home in Tian Xia, collecting and combining whatever innovations and traditions they happen across with those from their own long history._

_[[Tengu]]_


