---
title: "Kitsune"
icon: ":luggage:"
aliases: "Kitsune"
foundryId: Item.V2uuBpZsG534swg4
tags:
  - Item
---

# Kitsune
![[systems-pf2e-icons-default-icons-alternatives-ancestries-kitsune.svg|150]]

_Kitsune are a charismatic and witty people with a connection to the spiritual that grants them many magical abilities, chiefly the power to shapechange into other forms. Whether they pass unseen among other peoples or hold their tails high, kitsune are clever observers of the societies around them._

[[Kitsune]]


