---
title: "Anadi"
icon: ":luggage:"
aliases: "Anadi"
foundryId: Item.JLp064ZfWpCMkWCf
tags:
  - Item
---

# Anadi
![[systems-pf2e-icons-default-icons-alternatives-ancestries-anadi.svg|150]]

_Anadi people are reclusive, sapient spiders who hail from the jungles of southern Garund. Though they act in many ways like natural-born shapeshifters, their twin forms actually stem from carefully developed magic._

_[[Anadi]]_


