---
title: "Orc"
icon: ":luggage:"
aliases: "Orc"
foundryId: Item.cmNVpANZtlBt869U
tags:
  - Item
---

# Orc
![[systems-pf2e-icons-default-icons-alternatives-ancestries-orc.svg|150]]

_Orcs are forged in the fires of violence and conflict, often from the moment they are born. As they live lives that are frequently cut brutally short, orcs revel in testing their strength against worthy foes, whether by challenging a higher-ranking member of their community for dominance or raiding a neighboring settlement. Many orcs seek glory as soon as they can walk and carry a blade or club, taming wild beasts or hunting deadly monsters._

_[[Orc]]_


