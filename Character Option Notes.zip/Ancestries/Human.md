---
title: "Human"
icon: ":luggage:"
aliases: "Human"
foundryId: Item.3k6pgM4EDde4iTZj
tags:
  - Item
---

# Human
![[systems-pf2e-icons-default-icons-alternatives-ancestries-human.svg|150]]

_As unpredictable and varied as any of Golarion's peoples, humans have exceptional drive and the capacity to endure and expand. Though many civilizations thrived before humanity rose to prominence, humans have built some of the greatest and the most terrible societies throughout the course of history, and today they are the most populous people in the realms around the Inner Sea._

_[[Human]]_


