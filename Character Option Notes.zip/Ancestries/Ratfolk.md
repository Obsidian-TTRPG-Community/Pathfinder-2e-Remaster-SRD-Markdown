---
title: "Ratfolk"
icon: ":luggage:"
aliases: "Ratfolk"
foundryId: Item.Rz95c9KvVqXbjQaD
tags:
  - Item
---

# Ratfolk
![[systems-pf2e-icons-default-icons-alternatives-ancestries-ratfolk.svg|150]]

_Ysoki—as ratfolk call themselves—are a clever, adaptable, and fastidious ancestry who happily crowd their large families into the smallest of living spaces._

_[[Ratfolk]]_


