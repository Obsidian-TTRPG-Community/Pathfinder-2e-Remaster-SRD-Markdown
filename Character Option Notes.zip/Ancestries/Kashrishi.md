---
title: "Kashrishi"
icon: ":luggage:"
aliases: "Kashrishi"
foundryId: Item.vY5UZTuCi12jbRuX
tags:
  - Item
---

# Kashrishi
![[systems-pf2e-icons-default-icons-alternatives-ancestries-kashrishi.svg|150]]

Kashrishi make their homes in remote areas of the world. These quiet beings have stout, durable frames and distinctive crystalline horns. Their inherent psychic abilities make them natural empaths but also occasionally burden them with the unceasing thoughts of their neighbors.

[[Kashrishi]]


