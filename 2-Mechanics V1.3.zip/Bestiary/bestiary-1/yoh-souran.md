---
aliases: 
tags: 
obsidianUIMode: preview
---
```statblock
columns: 2
forcecolumns: true
layout: Basic Pathfinder 2e Layout

source: Pathfinder
name: "Yoh Souran"

ac: 38
armorclass:
  - name: AC
    desc: "38;  (42 while piloting Solar Jian II); __Fort__: +26 (1d20+26); __Ref__: +28 (1d20+28); __Will__: +23 (1d20+23);"


```
